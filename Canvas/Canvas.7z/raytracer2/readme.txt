This raytracer is written by Milo Yip
This software can be redistributed and used freely.

E-mail: miloyip@gmail.com
Twitter: http://www.twitter.com/miloyip
http://www.cnblogs.com/miloyip/
