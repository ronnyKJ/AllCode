LightSample = function(oppositeDirection, irradiance) {
    this.oppositeDirection = oppositeDirection;//光源反方向
    this.irradiance = irradiance;//光的颜色
};