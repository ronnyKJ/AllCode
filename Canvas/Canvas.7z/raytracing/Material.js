Material = function(attrs) {
    this.attrs = attrs;
};

Material.prototype = {

};

Material.mirror = new Material({
    reflect : 0.8
});