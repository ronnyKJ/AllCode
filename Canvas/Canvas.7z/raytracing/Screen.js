var Screen = function(position, width, height, canvas){
    this.position = position;
    this.width = width;
    this.height = height;
    this.canvas = canvas;
}