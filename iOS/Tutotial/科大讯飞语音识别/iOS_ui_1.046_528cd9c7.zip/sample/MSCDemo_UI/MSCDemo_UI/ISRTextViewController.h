//
//  ISRTextViewController.h
//  MSC
//
//  Created by iflytek on 13-4-7.
//  Copyright (c) 2013年 iflytek. All rights reserved.
//

#import "ISRTextView.h"

@interface ISRTextViewController : UIViewController
{
    ISRTextView         *_isrTextView;
}

@end
