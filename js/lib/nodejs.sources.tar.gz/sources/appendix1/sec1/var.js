if (true) {
  var somevar = 'value';
}
console.log(somevar); // 輸出 value
