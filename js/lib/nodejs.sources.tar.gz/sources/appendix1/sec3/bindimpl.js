someuser.func.bind = function(self) {
  return this.call(self);
};
