var obj1 = {
  ref: null
};

var obj2 = {
  ref: obj1
};

obj1.ref = obj2;