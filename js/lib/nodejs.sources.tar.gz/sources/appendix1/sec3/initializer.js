var foo = {
  'prop1': 'bar',
  prop2: 'false',
  prop3: function (){
    return 'hello world';
  }
};
