var someuser = new User('byvoid', 'http://www.byvoid.com');
