var some_prop = 'prop2';
foo[some_prop] = false;
