//consolelog.js

console.log('%s: %d', 'Hello', 25);
