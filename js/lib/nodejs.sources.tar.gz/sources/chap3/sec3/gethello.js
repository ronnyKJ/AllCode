//gethello.js

var Hello = require('./hello');

hello = new Hello();
hello.setName('BYVoid');
hello.sayHello();