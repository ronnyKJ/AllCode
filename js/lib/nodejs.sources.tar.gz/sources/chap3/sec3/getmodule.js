//getmodule.js

var myModule = require('./module');

myModule.setName('BYVoid');
myModule.sayHello();
