//getpackage.js

var somePackage = require('./somepackage');

somePackage.hello();
