//somepackage/index.js

exports.hello = function() {
  console.log('Hello.');
};
