console.log('Hello world');
console.log('byvoid%diovyb');
console.log('byvoid%diovyb', 1991);

