echo $_POST['title'];
echo $_POST['text'];
