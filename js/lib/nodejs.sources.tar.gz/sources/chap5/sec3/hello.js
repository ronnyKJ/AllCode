app.get('/hello', routes.hello);
