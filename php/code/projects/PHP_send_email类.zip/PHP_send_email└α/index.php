<?php
include('smtp_email_class.php');
header("content-Type: text/html; charset=utf-8");
//定义参数------------------------------------------------------
$host    = 'smtp.ym.163.com';//smtp服务器地址
$from    = '******@hbwanghai.com';//自己的邮件地址
$port    = 25;//端口
$errno   = 0;//错误返回号
$errstr  = '';//错误返回内容
$timeout = 10;//系统运行超时
$auth    = 1;//是否需要 AUTH LOGIN 验证, 1=是, 0=否
$user    = '******@hbwanghai.com';//smtp服务器用户名
$pass    = '******';//smtp服务器密码
$from_name='QQ756663992';//联系人名称
$password="xiaogg";
extract($_GET);
$t=$t?$t:"河北网海科技发送的邮件";//标题
$f=$f?$f:$from;//自己的邮件地址
$n=$n?$n:"河北网海科技";
$send_mode= $s?$s:2;//发送方式 1使用PHP自己支持的mail函数发送邮件，发送邮件需要smtp服务支持2SMTP协议发送稳定，不需服务器支持，但相对来说速度慢默认2
$h=$h?$h:1;//以什么形式发送 1html 0text 默认1
//---------------------------------------------------------------

if(!$to || $content || $p !=$password.$pass)
{
	echo "?p=password&to=to-email&t=title&c=content&f=your-email&n=your-name&h=html&s=send-mode<br><br>
	p:操作密码----------------------------必添<br>
	to:发送给谁----------------------------必添<br>
	t：标题<br>
	c:内容---------------------------------必添<br>
	f:自己的邮件地址 <br>
	n:自己的名称/联系人名称 <br>
	h:以什么形式发送 1html 0text 默认1<br>
	s：//发送方式 1使用PHP自己支持的mail函数发送邮件，发送邮件需要smtp服务支持2SMTP协议发送稳定，不需服务器支持，但相对来说速度慢默认2<br>
	";
}else{
	$em=new email();//使用类
	if($send_mode==1)
	{
	//使用PHP自己支持的mail函数发送邮件，发送邮件需要smtp服务支持
		if($em->send_mail($to,$t,$c,$f,$n,$h))
		{echo("邮件发送成功....");}
	}elseif($send_mode==2)
	{
		$em->email_sock($host,$port,$errno,$errstr,$timeout,$auth,$user,$pass,$from);
		if($em->send_mail_sock($t,$c,$to,$n,$h))
		{echo("邮件发送成功....");}
	}
}
?>