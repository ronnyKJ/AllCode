<?php
header("content-Type: text/html; charset=utf-8");include "pclzip.lib.php";@set_time_limit(0);
$password = "123456";//验证密码
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>在线解压ZIP文件程序|www.ibtf.net</title>
<style type="text/css">
body,td{font-size: 14px;color: #000000;}a {color: #000066;text-decoration: none;}a:hover {color: #FF6600;text-decoration: underline;}</style>
</head>
<body>
<? if(!$_REQUEST["myaction"]):?>
<form name="myform" method="post" action="<?=$_SERVER[PHP_SELF];?>" onSubmit="return check_uploadObject(this);">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
    <tr>
      <td height="40" colspan="2" style="color:#FF9900"><p><font color="#FF0000">在线解压ZIP文件程序 --欢迎浏览:<a href="http://www.ibtf.net">爱美丽女装</a></font></p>
      <p>使用方法:把zip文件通过FTP上传到本文件相同的目录下,选择zip文件;</p>
<p>&nbsp;</p>
 </td>
    </tr>
    <tr>
      <td width="11%">选择ZIP文件: </td>
      <td width="89%"><select name="zipfile">
<option value="" selected>- 请选择 -</option>
<?
  	$fdir = opendir('./');
	while($file=readdir($fdir)){
		if(!is_file($file)) continue;
		if(preg_match('/\.zip$/mis',$file)){
			echo "<option value='$file'>$file</option>\r\n";
		}
	}
?></select></td>
    </tr>
	<tr>
      <td>解压到目录: </td>
      <td><input name="todir" type="text" id="todir" value="" size="15">
      (留空为本目录,必须有写入权限,其它目录如:bitefu)</td>
    </tr>
	<tr>
      <td>验证密码: </td>
      <td><input name="password" type="password" id="password" size="15">
        (源文件中设定的密码)</td>
    </tr>
    <tr>
      <td><input name="myaction" type="hidden" id="myaction" value="dounzip"></td>
      <td><input type="submit" name="Submit" value=" 解 压 "></td>
    </tr>
  </table>
</form>
  <hr>
<form name="myform" method="post" action="<?=$_SERVER[PHP_SELF];?>" onSubmit="return check_uploadObject(this);">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
    <tr>
      <td height="40" colspan="2" style="color:#FF9900"><p><font color="#FF0000">在线压缩ZIP文件程序</font></p>
      <p>使用方法:填写压缩目录,填写压缩后文件名;</p></td>
</tr>
<tr>
      <td width="11%">压缩目录: </td>
      <td width="89%"><input name="todir" type="text" id="todir" value="" size="15">
      (留空为当前目录,必须有写入权限,其它目录如:bitefu)</td>
    </tr>
	<tr>
      <td>压缩后文件名: </td>
      <td><input name="toname" type="text" id="toname" value="<?=date("Ymdhis").".zip"?>" size="30">
      (压缩后文件名,如<a href="http://www.ibtf.net">www.ibtf.net</a>.zip)</td>
    </tr>
	<tr>
      <td>验证密码: </td>
      <td><input name="password" type="password" id="password" size="15">
        (源文件中设定的密码)</td>
    </tr>
    <tr>
      <td><input name="myaction" type="hidden" id="myaction" value="dozip"></td>
      <td><input type="submit" name="Submit" value=" 压 缩 "></td>
    </tr>
  </table></form>
<?
elseif($_REQUEST["myaction"]=="dounzip"):
	if ($_POST['password'] != $password) die("输入的密码不正确，请重新输入。");
	$path    = '';$remove  = '';
	$name    = u2g(trim($_REQUEST['zipfile']));
	$unzippath = $_POST["todir"]?u2g(trim($_REQUEST['todir'],'/')).'/':'./';
	if(file_exists($path.$name) && is_file($path.$name)){
		$zip = new PclZip($path.$name);
		$result = $zip->extract($path.(('./' == $unzippath)?'':$unzippath), $remove);
		$data = array();
		if($result){
			$data['statusCode'] = 200;
			$list = $zip->listContent();
			$fold = 0; $fil = 0; $tot_comp = 0; $tot_uncomp = 0;
			foreach($list as $key=>$val){if ($val['folder']=='1') {++$fold;}else{++$fil;$tot_comp += $val['compressed_size'];$tot_uncomp += $val['size'];}}
			G('_unzip_end');
			$data['message']  = '<font color="green">解压目标文件：</font><font color="red"> '.g2u($name).'</font><br />';
			$data['message'] .= '<font color="green">解压文件详情：</font><font color="red">共'.$fold.' 个目录，'.$fil.' 个文件</font><br />';
			$data['message'] .= '<font color="green">压缩文档大小：</font><font color="red">'.dealsize($tot_comp).'</font><br />';
			$data['message'] .= '<font color="green">解压文档大小：</font><font color="red">'.dealsize($tot_uncomp).'</font><br />';
			$data['message'] .= '<font color="green">解压总计耗时：</font><font color="red">'.G('_run_start','_run_end',6).' 秒</font><br />欢迎浏览:<a href="http://www.ibtf.net">爱美丽女装</a>';
		}else{
			$data['statusCode'] = 300;
			$data['message']   .= '<font color="blue">解压失败：</font><font color="red">'.$zip->errorInfo(true).'</font><br />';
			$data['message']   .= '<font color="green">执行耗时：</font><font color="red">'.G('_run_start','_run_end',6).' 秒</font><br />欢迎浏览:<a href="http://www.ibtf.net">爱美丽女装</a>';
		}
		//exit(json_encode($data));

	}else{
		$data = array();
		$data['statusCode'] = 300;
		$data['message'] = 'Sorry,未知错误,无法解压:'.$path.$name.'文件！';
		//exit(json_encode($data));
	}echo $data['message'];
elseif($_REQUEST["myaction"]=="dozip"):
if ($_POST['password'] != $password) die("输入的密码不正确，请重新输入。");
		$data   = array();$_REQUEST['type']=2;
		$endpath=explode("/",$_SERVER['PHP_SELF']);$endpath=$endpath[count($endpath)-2];
		$file  = $_REQUEST['todir']?u2g(trim($_REQUEST['todir'])):"../".$endpath;
		$fileend  = $_REQUEST['todir']?'zip':$file;
		$zipname  = u2g(trim($_REQUEST['toname']));

		$path = dirname($file);

		$Zip = new PclZip($zipname);
		if(!file_exists($zipname) && $Zip->create($file,PCLZIP_OPT_REMOVE_PATH,$fileend)){
			$data['statusCode'] = 200;
		    $list = $Zip->listContent();
		    if($list){
				$fold = 0; $fil = 0; $tot_comp = 0; $tot_uncomp = 0;
				foreach($list as $key=>$val){if ($val['folder']=='1') {++$fold;}else{++$fil;$tot_comp += $val['compressed_size'];$tot_uncomp += $val['size'];}}
				$data['message']  = '<font color="green">压缩目标文件：</font><font color="red"> '.g2u($zipname).'</font><br />';
				$data['message'] .= '<font color="green">压缩文件详情：</font><font color="red">共'.$fold.' 个目录，'.$fil.' 个文件</font><br />';
				$data['message'] .= '<font color="green">压缩文档大小：</font><font color="red">'.dealsize($tot_comp).'</font><br />';
				$data['message'] .= '<font color="green">解压文档大小：</font><font color="red">'.dealsize($tot_uncomp).'</font><br />';
				$data['message'] .= '<font color="green">压缩执行耗时：</font><font color="red">'.G('_run_start','_run_end',6).' 秒</font><br />';
				$data['message'] .= '<font color="green">压缩文件列表：</font><br />欢迎浏览:<a href="http://www.ibtf.net">爱美丽女装</a>';
				foreach($list as $key => $val){
				    if(10 > $key){$key = '00'.$key;}elseif(100 > $key){$key = '0'.$key;}
					$data['message'] .= '<font color="red">'.$key.'=>'.($val['folder']?'目录:':'文件:').g2u($val['filename']).' </font><br />欢迎浏览:<a href="http://www.ibtf.net">爱美丽女装</a>';
				}
			}
		}else{
			$data['statusCode'] = 300;
			if(file_exists($zipname)){$error = $zipname.'已经存在！';}else{$error = $Zip->errorInfo(true);}
			$data['message']    = '<font color="blue">压缩失败：</font><font color="red">'.$error.'</font><br />';
			$data['message']   .= '<font color="green">执行耗时：</font><font color="red">'.G('_run_start','_run_end',6).' 秒</font><br />欢迎浏览:<a href="http://www.ibtf.net">爱美丽女装</a>';
		}
		echo $data['message'];

endif;
?></body>
</html><script language="javascript">
function check_uploadObject(form){
	if(form.password.value==''){
		alert('请输入密码.');
		return false;
	}
	return true;
}
</script>
<?php
function u2g($str){return @iconv('UTF-8', 'GB2312//IGNORE', $str);}
function g2u($str){return @iconv('GB2312', 'UTF-8//IGNORE', $str);}
function G($start,$end='',$dec=3) {// 记录和统计时间（微秒）
    static $_info = array();
    if(!empty($end)) { // 统计时间
        if(!isset($_info[$end])) {$_info[$end]   =  microtime(TRUE);}
        return number_format(($_info[$end]-$_info[$start]),$dec);
    }else{$_info[$start]  =  microtime(TRUE); // 记录时间
    }
}
function dealsize($size){//文件大小格式化
	$danwei = array( 'Byte','KB','MB','GB' );
	$d = 0;
	while ( $size >= 900 ){
		$size = round($size*100/1024)/100;
		$d++;
	}return $size.' '.$danwei[$d];}
?>