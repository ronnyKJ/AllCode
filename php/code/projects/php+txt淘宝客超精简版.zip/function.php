<?php
function curl_file_get_contents($durl,$type='0'){
	if($type==1){return file_get_contents($durl);}else{
	if(function_exists('curl_setopt')){
	   $ch = curl_init();
	   curl_setopt($ch, CURLOPT_URL, $durl);
	   curl_setopt($ch, CURLOPT_TIMEOUT, 5);
	   curl_setopt($ch, CURLOPT_USERAGENT, _USERAGENT_);
	   curl_setopt($ch, CURLOPT_REFERER,_REFERER_);
	   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	   $r = curl_exec($ch);
	   curl_close($ch);
	}else if(function_exists('file_get_contents')){
		$r=file_get_contents($durl);
	}else if(function_exists('file')){
		$r=file($durl);$r = implode('', $r);
	}else{
		$r="��ȡ����ʧ��";
	}
   return $r;
   }
}
/**
* �ַ������ܡ����ܺ���
*
*
* @param	string	$txt		�ַ���
* @param	string	$operation	ENCODEΪ���ܣ�DECODEΪ���ܣ���ѡ������Ĭ��ΪENCODE��
* @param	string	$key		��Կ�����֡���ĸ���»���
* @param	string	$expiry		����ʱ��
* @return	string
*/
function sys_auth($string, $operation = 'ENCODE', $key = '', $expiry = 0) {
	$key_length = 4;
	$key = md5($key != '' ? $key : "bitefu");
	$fixedkey = md5($key);
	$egiskeys = md5(substr($fixedkey, 16, 16));
	$runtokey = $key_length ? ($operation == 'ENCODE' ? substr(md5(microtime(true)), -$key_length) : substr($string, 0, $key_length)) : '';
	$keys = md5(substr($runtokey, 0, 16) . substr($fixedkey, 0, 16) . substr($runtokey, 16) . substr($fixedkey, 16));
	$string = $operation == 'ENCODE' ? sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$egiskeys), 0, 16) . $string : base64_decode(substr($string, $key_length));

	$i = 0; $result = '';
	$string_length = strlen($string);
	for ($i = 0; $i < $string_length; $i++){
		$result .= chr(ord($string{$i}) ^ ord($keys{$i % 32}));
	}
	if($operation == 'ENCODE') {
		return $runtokey . str_replace('=', '', base64_encode($result));
	} else {
		if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$egiskeys), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	}
}
//������: compress_html  
//����: $string  
//����ֵ: ѹ�����$string  
function compress_html($string) {  
    $string = str_replace("\r\n", '', $string); //������з�  
    $string = str_replace("\n", '', $string); //������з�  
    $string = str_replace("\t", '', $string); //����Ʊ���  
    $pattern = array (  
                    "/> *([^ ]*) *</", //ȥ��ע�ͱ��  
                    "/[\s]+/",  
                    "/<!--[^!]*-->/",  
                    "/\" /",  
                    "/ \"/",  
                    "'/\*[^*]*\*/'"  
                    );  
    $replace = array (  
                    ">\\1<",  
                    " ",  
                    "",  
                    "\"",  
                    "\"",  
                    ""  
                    );  
    return preg_replace($pattern, $replace, $string);  
}
?>