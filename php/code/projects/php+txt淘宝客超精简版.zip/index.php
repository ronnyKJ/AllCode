<?php
include('common.php');
include('function.php');
$urlhead=file("urlhead.txt");
if(URL_END){
	$cacheurl='cache/'.md5(URL_END).".txt";	$nowtype=substr(URL_END,5,1);
	$mailurl=trim($urlhead[$nowtype]).str_replace('/html'.$nowtype."/",'',URL_END);
}else{
	$cacheurl='cache/'.md5("index").".txt";
	$mailurl=INDEX_URL;
}
if(!file_exists($cacheurl) || (filemtime($cacheurl) + CACHE_DATA) < time() ){
	$index_content=curl_file_get_contents($mailurl,1);
	//����滻
	foreach($urlhead as $key =>$v)
	{	$str_qian[]=trim($v);
		$str_hou[]=WEB_PATH."index.php/html".$key."/";
	}
	$body=str_replace($str_qian,$str_hou,$index_content);
	$strqian=array('</title>','mm_0_','</body>','</html>','http://s.click.taobao.com/');
	$strqhou=array(WEB_TITLE.'</title>','mm_16329643_','','<div style="display:none"><script language="javascript" type="text/javascript" src="http://js.users.51.la/3729735.js"></script></div></html>',WEB_PATH."html/index.php/");
	$body=str_replace($strqian,$strqhou,$body);
	if(CACHE_YASUO){$body=gzcompress($body);}
	//����滻
	file_put_contents($cacheurl,$body);
}
$html=file_get_contents($cacheurl);
if(CACHE_YASUO){echo gzuncompress($html);}else{echo $html;}
?>