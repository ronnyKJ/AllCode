<?php
function curl_file_get_contents($durl){
	 $f = new SaeFetchurl();
	  $content = $f->fetch($durl);
	  if($f->errno() == 0)  $r=$content;
	  else $r=$f->errmsg();
   return $r;

}
?>