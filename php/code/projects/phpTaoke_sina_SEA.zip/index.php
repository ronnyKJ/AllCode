<?php
include('common.php');
include('function.php');
$urlhead=file("urlhead.txt");
if(URL_END){
	$cacheurl='cache/'.md5(URL_END).".txt";
	$nowtype=substr(URL_END,5,1);
	$newheader=explode("|",trim($urlhead[$nowtype]));
	$mailurl=$newheader[0].str_replace("bitefu=net","&pid=mm_".ALIMAMA_KEY."_0_0",str_replace('/html'.$nowtype."/",'',URL_END));
}else{
	$cacheurl='cache/'.md5("index").".txt";
	$mailurl=INDEX_URL;
}
if(!file_exists($cacheurl) || (filemtime($cacheurl) + CACHE_DATA) < time() ){
	$index_content=curl_file_get_contents($mailurl);
	//����滻
	foreach($urlhead as $key =>$v)
	{
		$strarr=explode("|",trim($v));
		$str_qian[]=$strarr[0];
		if($strarr[1]){$str_hou[]=WEB_PATH."u/?bitefutype=".$key."&";}else{
		$str_hou[]=WEB_PATH."index.php/html".$key."/";
		}
	}
	$body=str_replace($str_qian,$str_hou,$index_content);
	$strqian=array('pid=mm_'.ALIMAMA_KEY.'_0_0','</title>','mm_0_','</body>','</html>');
	$strqhou=array('bitefu=net',WEB_TITLE.'</title>','mm_'.ALIMAMA_KEY.'_','','<div style="display:none"><script language="javascript" type="text/javascript" src="http://js.users.51.la/3729735.js"></script></div></html>');
	$body=str_replace($strqian,$strqhou,$body);
	if(CACHE_YASUO){$body=gzcompress($body);}
//����滻
	file_put_contents("saemc://".$cacheurl,$body);
}
$html=file_get_contents("saemc://".$cacheurl);
if(CACHE_YASUO){echo gzuncompress($html);}else{echo $html;}
?>