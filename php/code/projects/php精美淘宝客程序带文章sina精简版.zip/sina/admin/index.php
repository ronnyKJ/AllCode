<?php
@date_default_timezone_set('PRC');//定义时区，校正时间为北京时间

//定义CanPHP框架目录
define('CP_PATH',dirname(__FILE__).'/../include/');//注意目录后面加“/”

require(dirname(__FILE__).'/../config.php');//加载配置

require(CP_PATH.'core/cpApp.class.php');//加载应用控制类
$config['DB_CACHE_ON']=false;			//后台不生成数据库缓存
$config['HTML_CACHE_ON']=false;			//后台不生成静态页面
$config['TPL_CACHE_ON']=false;			//后台不生成模版缓存
$config['URL_REWRITE_ON']=false;		//后台不启用伪静态
$app=new cpApp($config);//实例化单一入口应用控制类
//执行项目
$app->run();
?>