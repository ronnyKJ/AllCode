<?php
class cacheMod extends commonMod
{
	public function cache()
	{
		//遍历风格读取配置参数
		$dir		= '../cache';
		$list = @scandir($dir);
        if($list)
        {
            foreach($list as $file)
            {
                $file_location=$dir."/".$file;
                if(is_dir($file_location) && $file!="." &&$file!="..")
                {
                    $arr_file1[] = $file;
                }
            }
        }
		$this->assign('list',	$arr_file1);
		$this->display('cache/cache');
	}
	
	public function clear()
	{
		$cachedir	= in(isset($_GET['0']) ? trim($_GET['0']) :'');
		del_dir("../cache/".$cachedir);
		$this->success('清除缓存成功！','/cache');
	}
}

?>