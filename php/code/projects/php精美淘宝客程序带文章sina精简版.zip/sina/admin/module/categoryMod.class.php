<?php
class categoryMod extends commonMod
{
	//信息栏目列表
	public function get_list()
	{
		$order		= in(isset($_GET[0]) ? trim($_GET[0]) :'show_order');
		$url		= __URL__.'/get_list-'.$order.'-page-{page}.html';
		$list_rows	= 10;
		$page		= new Page();
		$cur_page	= $page->getCurPage();		
		$count		= $this->model->table('category')->count();
		$this->assign('list',$this->condition_list($list_rows,$cur_page,'',$order));
		$this->assign('page',$page->show($url,$count,$list_rows));
		$this->display('category/list');
	}
	
	//查询列表
	public function condition_list($list_rows,$cur_page,$where,$order)
	{
		$limit_start = ($cur_page-1)*$list_rows;
		$limit		 = $limit_start.','.$list_rows;
		$list		 = $this->getCat(0,$where,$order);
		if($list)
		{
			foreach($list as $key=>$val)
			{
				if($key<($limit_start+$list_rows)&&$key>=$limit_start)
				{
					$list[$key] = $val;
				}
				else
				{
					unset($list[$key]);
				}
			}
			return $list;
		}
	}
		
	//添加信息栏目
	public function add()
	{
		if(empty($_POST['do']))
		{
			$pid = intval($_GET['0']);
			$this->assign('pid',$pid);
			$this->assign('list',$this->condition_list('100','1','','show_order'));
			$this->display('category/add');
			return;
		}
		//数据验证
		$msg = Check::rule(array(
							array(check::must($_POST['title']),'标题不可为空！'),
						   )); 
         //如果数据验证通不过，返回错误信息						   
		if($msg!==true)
		{                
			$this->error($msg);
		}
		
		$data=array();
		$data['title']		= in($_POST['title']);				//信息栏目标题
		$data['keywords']	= in($_POST['keywords']);			//关键词
		$data['description']= in($_POST['description']);		//信息栏目摘要
		$data['pid']		= intval($_POST['pid']);
		$data['module']		= intval($_POST['module']);
		$data['template']	= in($_POST['template']);
		$data['show_order']	= intval($_POST['show_order']);

		
		//添加数据
		if($this->model->table('category')->data($data)->insert())
		{
			$this->success('添加成功！','/get_list');
		}
		else
		{
			$this->error('添加失败！');
		}
	}
		
	//修改信息栏目
	public function edit()
	{
		if(empty($_POST['do']))
		{
			$id = intval($_GET['0']);
			$this->assign('info',$this->info($id));
			$this->assign('list',$this->condition_list('100','1','pid!='.$id.' AND id!='.$id,'show_order'));
			$this->display('category/edit');
			return;
		}
		//数据验证
		$msg = Check::rule(array(
							array(check::must($_POST['title']),'标题不可为空！'),
						   )); 
        //如果数据验证通不过，返回错误信息						   
		if($msg!==true)
		{                
			$this->error($msg);
		}
		
		$data=array();
		$data['title']		= in($_POST['title']);				//信息栏目标题
		$data['keywords']	= in($_POST['keywords']);			//关键词
		$data['description']= in($_POST['description']);		//信息栏目摘要
		$data['pid']	= intval($_POST['pid']);
		$data['template']	= in($_POST['template']);
		$data['show_order']	= intval($_POST['show_order']);
		
		//修改数据
		$condition['id'] = intval($_POST['id']);
		if($this->model->table('category')->data($data)->where($condition)->update())
		{
			$this->success('修改成功！','/get_list');
		}
		else
		{
			$this->error('修改失败！');
		}
	}
		
	//读取信息
	public function info($id)
	{
		$condition['id'] = $id;
		$info = $this->model->table('category')->where($condition)->find();
		if($info)
		{
			return $info;
		}
		else
		{
			$this->error('不存在此信息！');
		}
	}
	
	//删除信息
	public function del()
	{
		$condition['id'] = intval($_GET['0']);
		$act = $this->info(intval($_GET['0']));
		if(!$this->model->table('category')->where('pid='.intval($_GET['0']))->count())
		{
			if($this->model->table('category')->where($condition)->delete())
			{
				$this->success('删除成功！','/get_list');
			}
			else
			{
				$this->error('删除失败！');
			}
		}
		else
		{
			$this->error('此栏目下存有子栏目！');
		}
	}
	
	//删除选中
	public function all_del()
	{
		$id		= $_POST['id'];
		$new_id = substr($id,0,strlen($id)-1);
		if(!$this->model->table('category')->where('pid in ('.$new_id.')')->count())
		{
			if($this->model->table('category')->where('id in ('.$new_id.')')->delete())
			{
				echo 1;
			}
			else
			{
				echo 0;
			}
		}
	}
	
	//设置排序
	public function set_sort()
	{
		$id		= explode(',',substr($_POST['id'],0,strlen($_POST['id'])-1));
		$order	= explode(',',substr($_POST['order'],0,strlen($_POST['order'])-1));
		$num	= 0;
		for($i=0;$i<count($id);$i++)
		{
			$condition['id'] = $id[$i];
			if($this->model->table('category')->data("show_order='".$order[$i]."'")->where($condition)->update());
			{
				$num++;
			}
		}
		if(count($id)==$num)
		{
			echo "1";
		}
		else
		{
			echo "0";
		}
	}
	
	//获取分类树，$id，分类id,$id=0，获取所有分类结构树
	public function getCat($id,$where,$order)
	{
		require(CP_PATH.'lib/Category.class.php');					//导入Category.class.php无限分类
		//查询分类信息
		$data = $this->model->field('id,pid,title,template,show_order')->table('category')->where($where)->order($order.' DESC,id DESC')->select();
		//array('id','pid','name','cname'),字段映射，格式化后的分类名次问cname
		$cat  = new Category(array('id','pid','title'));		//初始化无限分类
		
		return $cat->getTree($data,$id);							//获取分类数据树结构
	}
}
?>