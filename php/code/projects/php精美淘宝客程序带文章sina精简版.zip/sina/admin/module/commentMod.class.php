<?php
class commentMod extends commonMod
{
	//点评列表
	public function get_list()
	{
		$isval		= in(isset($_GET['0']) ? trim($_GET['0']) :'0');
		$order		= in(isset($_GET['1']) ? trim($_GET['1']) :'id');
		$where		= 'is_validated='.$isval;
		$url		= __URL__.'/get_list-'.$isval.'-'.$order.'-page-{page}.html';
		$list_rows	= 10;
		$page		= new Page();
		$cur_page	= $page->getCurPage();		
		$count		= $this->model->table('comment')->where($where)->count();
		$this->assign('list',$this->condition_list($list_rows,$cur_page,$where,$order));
		$this->assign('page',$page->show($url,$count,$list_rows));
		$this->display('comment/list');
	}
	
	//查询列表
	public function condition_list($list_rows,$cur_page,$where,$order)
	{
		$limit_start = ($cur_page-1)*$list_rows;
		$limit		 = $limit_start.','.$list_rows;
		$list		 = $this->model->field('id,username,email,content,pid,is_validated')->table('comment')->where($where)->order($order.' DESC,id DESC')->limit($limit)->select();
		if($list)
		{
			foreach($list as & $val)
			{
				$val['validated'] = __URL__.'/validated-'.$val['id'].'.html';
				$val['del']	 = __URL__.'/del-'.$val['id'].'.html';
			}
			return $list;
		}
	}
		
	//审核点评
	public function validated()
	{
		
		$data['is_validated']	= 1;
		$condition['id'] 		= intval($_GET['0']);
		if($this->model->table('comment')->data($data)->where($condition)->update())
		{
			$this->success('审核成功！','/get_list');
		}
		else
		{
			$this->error('审核失败！');
		}

	}
		
	//读取信息
	public function info($id)
	{
		$condition['id'] = $id;
		$info = $this->model->table('comment')->where($condition)->find();
		if($info)
		{
			$info['content']  = html_out($info['content']);
			$info['add_time'] = date('y-m-d h:i:s',$info['add_time']);
			return $info;
		}
		else
		{
			$this->error('不存在此信息！');
		}
	}
	
	//删除信息
	public function del()
	{
		$condition['id'] = intval($_GET['0']);
		if($this->model->table('comment')->where($condition)->delete())
		{
			$this->success('删除成功！','/get_list');
		}
		else
		{
			$this->error('删除失败！');
		}
	}
	
	//删除选中
	public function all_del()
	{
		$id		= $_POST['id'];
		$new_id = substr($id,0,strlen($id)-1); 
		$data	= explode(',',$new_id);
		if($this->model->table('comment')->where('id in ('.$new_id.')')->delete())
		{
			echo 1;
		}
		else
		{
			echo 0;
		}
	}
	//全部审核
	public function all_validated()
	{
		$id=$_POST['id'];
		$new_id = substr($id,0,strlen($id)-1);
		if($this->model->table('comment')->data('is_validated=1')->where('id in ('.$new_id.')')->update())
		{
			echo 1;
		}
		else
		{
			echo 0;
		}
	}
	 
}
?>