<?php
class dbbackMod extends commonMod
{
	//显示备份
	public function get_table()
	{
		$db		= new Dbbak($this->config['DB_HOST'],$this->config['DB_USER'],$this->config['DB_PWD'],$this->config['DB_NAME'],'utf8','../data/dbback/');
		$table	= $db->getTables($this->config['DB_NAME']);
		$this->assign('list',$this->getFileName());
		$this->assign('dbname',date("Ymd",time()));
		$this->assign('table' ,$table);
		$this->display('dbback/back');
	}
	
	//备份数据	
	public function backup()
	{
		@set_time_limit(0);
		$db		 = new Dbbak($this->config['DB_HOST'],$this->config['DB_USER'],$this->config['DB_PWD'],$this->config['DB_NAME'],'utf8','../data/dbback/');
		$tb_name = $_POST['tbName'];
		$db_size = $_POST['dbsize'];
		$db_sql	 = $_POST['dbsql'];
		if($tb_name=="allback")
		{
			$data = $db->getTables($this->config['DB_NAME']);
		}
		else
		{
			$data = explode(",",substr($tb_name,0,strlen($tb_name)-1));
		}
		if($db->exportSql($data,$db_size,$db_sql))
		{	
			echo 1;	
		}
		else
		{	
			echo 0;
		}
	}
	
	//获取备份文件列表
	public function getFileName()
	{
		$f_open = "../data/dbback/";
		if(is_dir($f_open))
		{
			$dir = opendir($f_open);
			while(false!=$file=readdir($dir))
			{    
				if($file!='.' && $file!='..' && !is_dir($f_open."\\".$file))
				{
					$file		= $file;
					$arr_file1[]= $file;
				}
			}
		}
		closedir($dir);
		if($arr_file1)
		{
			$i = 0;
			foreach($arr_file1 as &$val)
			{
				$path = '../data/dbback/'.$val;
				$arr_file2[$i]['name']		= $val;
				$arr_file2[$i]['size']		= filesize($path);
				$arr_file2[$i]['time']		= date("Y-m-d h:i:s",fileatime($path));
				$arr_file2[$i]['edition']	= $this->config['ver'];
				$i++;
			}
		}
		return $arr_file2;	
	}
	
	//恢复已存在备份
	public function recovery()
	{
		@set_time_limit(0);
		$db		= new Dbbak($this->config['DB_HOST'],$this->config['DB_USER'],$this->config['DB_PWD'],$this->config['DB_NAME'],'utf8','../data/dbback/');
		$path	= $_GET['path'];
		if($db->importSql($path))
		{
			$this->success('数据恢复成功！','/get_table');
		}
		else
		{
			$this->error('数据恢复失败！');
		}
	}
	
	public function alldel()
	{
		$file_name		= $_POST['fileName'];
		$new_file 		= substr($file_name,4,strlen($file_name)-5);
		$db_file_name	= explode(',',$new_file);
		foreach($db_file_name as $val)
		{
			if(is_file('../data/dbback/'.$val))
			{
				unlink('../data/dbback/'.$val);
			}
		}
		echo 1;
	}	
}
?>