<?php
class focusMod extends commonMod
{
	//焦点列表
	public function get_list()
	{
		$order		= in(isset($_GET[0]) ? trim($_GET[0]) :'show_order');
		$url		= __URL__.'/get_list-'.$order.'-page-{page}.html';
		$list_rows	= 10;
		$page		= new Page();
		$cur_page	= $page->getCurPage();		
		$count		= $this->model->table('focus')->count();
		$this->assign('list',$this->condition_list($list_rows,$cur_page,'',$order));
		$this->assign('page',$page->show($url,$count,$list_rows));
		$this->display('focus/list');
	}
	
	//查询列表
	public function condition_list($list_rows,$cur_page,$where,$order)
	{
		$limit_start = ($cur_page-1)*$list_rows;
		$limit		 = $limit_start.','.$list_rows;
		$list		 = $this->model->field('id,title,url,show_order')->table('focus')->where($where)->order($order.' DESC,id DESC')->limit($limit)->select();
		if($list)
		{
			foreach($list as & $val)
			{
				$val['edit'] = __URL__.'/edit-'.$val['id'].'.html';
				$val['del']	 = __URL__.'/del-'.$val['id'].'.html';
			}
			return $list;
		}
	}
		
	//添加焦点
	public function add()
	{
		if(empty($_POST['do']))
		{
			$this->display('focus/add');
			return;
		}
		//数据验证
		$msg = Check::rule(array(
							array(check::must($_POST['title']),'焦点名称不可为空！'),
							array(check::must($_POST['url']),'焦点地址不可为空！'),
						  )); 
        //如果数据验证通不过，返回错误信息						   
		if($msg!==true)
		{                
			$this->error($msg);
		}
		
		$data = array();
		$data['title']		= in($_POST['title']);					//焦点焦点名称
		$data['pic']		= in($_POST['pic']);
		$data['url']		= in($_POST['url']);
		$data['show_order'] = intval($_POST['show_order']);
		
		//添加数据
		if($this->model->table('focus')->data($data)->insert())
		{
			$this->success('添加成功！','/get_list');
		}
		else
		{
			$this->error('添加失败！');
		}
	}
		
	//修改焦点
	public function edit()
	{
		if(empty($_POST['do']))
		{
			$id = intval($_GET['0']);
			$this->assign('info',$this->info($id));
			$this->display('focus/edit');
			return;
		}
		//数据验证
		$msg = Check::rule(array(
							array(check::must($_POST['title']),'焦点名称不可为空！'),
							array(check::must($_POST['url']),'焦点地址不可为空！'),
						  )); 
		//如果数据验证通不过，返回错误信息						   
		if($msg!==true)
		{                
			$this->error($msg);
		}
		 
		$data = array();
		$data['title']		= in($_POST['title']);					//焦点焦点名称
		$data['pic']		= in($_POST['pic']);
		$data['url']		= in($_POST['url']);
		$data['show_order'] = intval($_POST['show_order']);
		
		//修改数据
		$condition['id'] 	= intval($_POST['id']);
		$info				= $this->info(intval($_POST['id']));
		if($info['pic']!=$data['pic'])
		{
			if(is_file($_SERVER['DOCUMENT_ROOT'].$info['pic']))
			{
				unlink($_SERVER['DOCUMENT_ROOT'].$info['pic']);
			}
		}
		if($this->model->table('focus')->data($data)->where($condition)->update())
		{
			$this->success('修改成功！','/get_list');
		}
		else
		{
			$this->error('修改失败！');
		}
	}
		
	//读取信息
	public function info($id)
	{
		$condition['id'] = $id;
		$info = $this->model->table('focus')->where($condition)->find();
		if($info)
		{
			return $info;
		}
		else
		{
			$this->error('不存在此信息！');
		}
	}
	
	//删除信息
	public function del()
	{
		$condition['id'] = intval($_GET['0']);
		$info			 = $this->info(intval($_GET['0']));
		if(is_file($_SERVER['DOCUMENT_ROOT'].$info['pic']))
		{
			unlink($_SERVER['DOCUMENT_ROOT'].$info['pic']);
		}
		if($this->model->table('focus')->where($condition)->delete())
		{
			$this->success('删除成功！','/get_list');
		}
		else
		{
			$this->error('删除失败！');
		}
	}
	
	//删除选中
	public function all_del()
	{
		$id		= $_POST['id'];
		$new_id = substr($id,0,strlen($id)-1); 
		$data	= explode(',',$new_id);
		$list = $this->model->table('focus')->where('id in ('.$new_id.')')->select();
		if($list)
		{
			foreach($list as $val)
			{
				if(is_file($_SERVER['DOCUMENT_ROOT'].$val['pic']))
				{
					unlink($_SERVER['DOCUMENT_ROOT'].$val['pic']);
				}
			}
		}
		if($this->model->table('focus')->where('id in ('.$new_id.')')->delete())
		{
			echo 1;
		}
		else
		{
			echo 0;
		}
	}
	
	//设置排序
	public function set_sort()
	{
		$id		= explode(',',substr($_POST['id'],0,strlen($_POST['id'])-1));
		$order	= explode(',',substr($_POST['order'],0,strlen($_POST['order'])-1));
		$num	= 0;
		for($i=0;$i<count($id);$i++)
		{
			$condition['id'] = $id[$i];
			if($this->model->table('focus')->data("show_order='".$order[$i]."'")->where($condition)->update());
			{
				$num++;
			}
		}
		if(count($id)==$num)
		{
			echo "1";
		}
		else
		{
			echo "0";
		}
	}
}
?>