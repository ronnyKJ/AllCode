<?php
class indexMod extends commonMod
{
	//显示管理后台首页	
	public function index()
	{
		$condition['id']	= $_SESSION['user_id'];
		$info  = $this->model->table('user')->where($condition)->find();
		$this->assign('info',		$info);
		$this->display('index/index');
	}
	
	//登录页面
	public function login()
	{
		if(!$this->isPost())
		{
			$this->display('index/login');
			return;
		}
		
		//数据验证
		$msg = Check::rule(array(
							array(check::must($_POST['name']),		'请输入用户名！'),
							array(check::must($_POST['pwd']),		'请输入密码！'),
							array(check::must($_POST['checkcode']), '请输入验证码！'),  
							array(check::same($_POST['checkcode'],	$_SESSION['verify']),'验证码错误，请重新输入！'),
						  )); 
         //如果数据验证通不过，返回错误信息						   
		 if($msg!==true)
		 {                
			 $this->error($msg);
		 }
		
		$user_name	= in($_POST['name']);
		$password	= md5($this->config['CODE_PREFIX'].$_POST['pwd']);
		//数据库操作
		if($this->_login($user_name,$password))
		{
			
			$this->redirect(__APP__);
		}
		else
		{
			$this->error('用户名或密码错误，请重新输入！');
		}	
	}
	
	//用户登录
	public function _login($user_name,$password)
	{
		$condition = array();
		$condition['name'] = $user_name;
		$user_info = $this->model->table('user')->where($condition)->find();
		//用户名密码正确且没有锁定
		if(($user_info['pwd']==$password)&&($user_info['is_lock']=='1'))
		{	
			//设置登录信息
			$_SESSION['user_id']		= $user_info['id'];
			$_SESSION['user_group_id']	= $user_info['group_id'];
			$_SESSION['user_name']		= $user_info['nickname'];
			Auth::set($user_info['group_id']);//设置用户组，用来权限验证
			$_SESSION['__ROOT__']=__ROOT__;		
			return true;
		}
		return false;
	}
	
	//生成验证码
	public function verify()
	{
		Image::buildImageVerify();
	}
	
	//欢迎模块
	public function welcome()
	{
        $xml    = Xml::decode(file_get_contents('http://bbs.lqcms.net/lqtk.xml'));
		$lqcms['upload_file']		= ini_get('upload_max_filesize');
		$lqcms['server_software']	= $_SERVER['SERVER_SOFTWARE'];
		$lqcms['catalog']			= $_SERVER['DOCUMENT_ROOT'];
		$mysql = $this->model->query("SELECT VERSION()");
		$lqcms['mysql']				= $mysql['0']['VERSION()'];
		$condition['id']			= $_SESSION['user_id'];
		$info  = $this->model->table('user')->where($condition)->find();
		$group=$this->model->table('group')->where("id='".$info['group_id']."'")->find();
		$this->assign('xml',		$xml);
        $this->assign('lqcms',	$lqcms);
		$this->assign('info',		$info);
		$this->assign('group_name',	$group['name']);
		$this->assign('login_ip',	$_SERVER["REMOTE_ADDR"]);
		$this->display('index/welcome');
	}
	
	//用户退出
	public function login_out()
	{
		unset($_SESSION['user_id']);
		unset($_SESSION['user_group_id']);
		unset($_SESSION['user_name']);
		Auth::clear();						//清除权限验证
		unset($_SESSION['__ROOT__']);
		$this->success('您已成功退出系统');
	}
	public function plugins()
	{
		$this->display('index/plugins');
	}
}
?>