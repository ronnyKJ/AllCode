<?php
class siteMod extends commonMod
{
	//站点设置
	public function set_up()
	{
		$condition['id']	= 1;
		if(empty($_POST['do']))
		{
			$read=$this->model->table('site')->where($condition)->find();
			$this->assign('read',$read);
			$this->display('site/set_up');
			return;
		}
		$data['name']		= in($_POST['name']);
		$data['keywords']	= in($_POST['keywords']);
		$data['description']= in($_POST['description']);
		$data['title']		= in($_POST['title']);
		$data['email']		= in($_POST['email']);
		$data['icpcode']	= in($_POST['icpcode']);
		$data['address']	= in($_POST['address']);
		$data['tel']		= in($_POST['tel']);
		$data['fax']		= in($_POST['fax']);
		$data['statistical']= in($_POST['statistical']);
		$data['siteurl']	= in($_POST['siteurl']);
		$data['qq']			= in($_POST['qq']);
		if($this->model->table('site')->data($data)->where($condition)->update())
		{
			$this->success('设置成功！','/set_up');
		}
		else
		{
			$this->error('设置失败！或您未修改任何数据！');
		}
	}
	//配置设置
	public function save_config()
	{
		if(empty($_POST['do']))
		{
			$this->assign('cfg',$this->getconfig());
			$this->display('site/system');
			return;
		}
		$config=$_POST;//接收表单数据 
		$config_array=array();
		foreach($config as $key=>$value)
		{
			$config_array["config['".$key."']"]=$value;	
		}
		if(!$this->set_config($config_array))
		{
			$this->error('配置文件写入失败！');
		}
		else
		{
			$this->success('配置成功！','/save_config');
		}
	}
	
	//修改配置的函数 
	public function set_config($array,$config_file='./../config.php')
	{
		 if(empty($array)||!is_array($array))
		 {
			 return false;
		 }
	
		 $config=file_get_contents($config_file);//读取配置
		 foreach($array as $name=>$value)
		 { 
			$name=str_replace(array("'",'"','['),array("\\'",'\"','\['),$name);//转义特殊字符，再传给正则替换
			if(is_string($value)&&!in_array($value,array('true','false','3306')))
			{
				$value="'".$value."'";//如果是字符串，加上单引号
			}
			$config=preg_replace("/(\\$".$name.")\s*=\s*(.*?);/i", "$1={$value};", $config);//查找替换
		 }
		//写入配置
		if(file_put_contents($config_file,$config))
		return true;
		else 
		return false; 
	}
	
}
?>