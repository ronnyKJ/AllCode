<?php
class spiderMod extends commonMod
{
	//蜘蛛列表
	public function get_list()
	{
		$sql	= "SELECT id,name,url,`time`,count( name ) AS view FROM (SELECT * FROM {$this->model->pre}spider ORDER BY id DESC) AS {$this->model->pre}spider GROUP BY name ORDER BY id DESC ";
		$list	= $this->model->query($sql); 
		$this->assign('list',$list);
		$this->display('spider/list');
	}
	
	//爬行列表
	public function spider_list()
	{
		$name		= in(isset($_GET['0']) ? trim($_GET['0']) :'baiduspider');
		$order		= in(isset($_GET['1']) ? trim($_GET['1']) :'id');
		$url		= __URL__.'/spider_list-'.$name.'-'.$order.'-page-{page}.html';
		$where		= "name='".$name."'";
		$list_rows	= 10;
		$page		= new Page();
		$cur_page	= $page->getCurPage();		
		$count		= $this->model->table('spider')->where($where)->count();
		$this->assign('list',$this->condition_list($list_rows,$cur_page,$where,$order));
		$this->assign('page',$page->show($url,$count,$list_rows));
		$this->display('spider/sdrlist');
	}
	
	//查询列表
	public function condition_list($list_rows,$cur_page,$where,$order)
	{
		$limit_start = ($cur_page-1)*$list_rows;
		$limit		 = $limit_start.','.$list_rows;
		$list		 = $this->model->field('id,name,time,url')->table('spider')->where($where)->order($order.' DESC,id DESC')->limit($limit)->select();
		if($list)
		{
			foreach($list as & $val)
			{
				$val['del']  = __URL__.'/del-'.$val['id'].'.html';
			}
			return $list;
		}
	}
	
	//删除信息
	public function del()
	{
		$condition['id'] = intval($_GET['0']);
		if($this->model->table('spider')->where($condition)->delete())
		{
			$this->success('删除成功！','/get_list');
		}
		else
		{
			$this->error('删除失败！');
		}
	}
	
	//删除选中
	public function all_del()
	{
		$id		= $_POST['id'];
		$new_id = substr($id,0,strlen($id)-1); 
		if($this->model->table('spider')->where('id in ('.$new_id.')')->delete())
		{
			echo 1;
		}
		else
		{
			echo 0;
		}
	}
}
?>