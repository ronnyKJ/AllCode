<?php
class tbkMod extends commonMod
{
	//站点设置
	public function tkapi()
	{
		$condition['tkid']	= 1;
		if(empty($_POST['do']))
		{
			$read=$this->model->table('tbk')->where($condition)->find();
			$this->assign('read',		$read);
			$this->assign('tcategory',	$this->category());
			$this->display('tbk/tkapi');
			return;
		}
		$data['tkname']		= in($_POST['tkname']);
		$data['tkpid']		= in($_POST['tkpid']);
		$data['tkkey']		= in($_POST['tkkey']);
		$data['tksecret']	= in($_POST['tksecret']);
		$data['tksize']		= intval($_POST['tksize']);
		$data['tkcat']		= intval($_POST['tkcat']);
		$data['tkorder']	= in($_POST['tkorder']);
		$data['tklevel']	= in($_POST['tklevel']);
		$data['tksearch']	= in($_POST['tksearch']);
		if($this->model->table('tbk')->data($data)->where($condition)->update())
		{
			$this->success('设置成功！','/tkapi');
		}
		else
		{
			$this->error('设置失败！或您未修改任何数据！');
		}
	}
	
	public function category()
	{
		$condition['tkid']	= 1;
		$tbk	= $this->model->table('tbk')->where($condition)->find();
                $keys	= explode(',',$tbk['tkkey']);
		$secret	= explode(',',$tbk['tksecret']);
		$num	= count($keys);
		$rd	= array();
		for($i=0;$i<$num;$i++)
		{
			$Tbk	= new Tbk(array(trim($keys[$i]),trim($secret[$i]),trim($tbk['tkname']),1,'','','','','',''));
			$tmp	= $Tbk->akstate();
			if($tmp && !array_key_exists('code', $tmp))
			{
				$rd[]	= $i;
			}
		}
		$kid	= $rd[array_rand($rd, 1)];
		$tbk['tkkey']		= $keys[$kid];
		$tbk['tksecret']	= $secret[$kid];
		$Tbk	= new Tbk(array(trim($tbk['tkkey']),trim($tbk['tksecret']),trim($tbk['tkname']),'',0,'',$tbk['tkorder'],$tbk['tklevel'],'',''));
		return $Tbk->get_category();
	}
}
?>