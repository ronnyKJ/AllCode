<?php
class tplMod extends commonMod
{
	public function read_style()
	{
		//遍历风格读取配置参数
		$dir	= '../themes';
		$list	= scandir($dir);
		foreach($list as $file)
		{
			$file_location=$dir."/".$file;
			if(is_dir($file_location) && $file!="." &&$file!="..")
			{
				$arr_file1[] = $file;
			}
		}
		$i = 0;
		if(is_array($arr_file1))
		{
			foreach($arr_file1 as $val)
			{
				$xml_array = simplexml_load_file('../themes/'.$val.'/config.xml');
				$style[$i]['SiteName']	= $xml_array->SiteName;
				$style[$i]['FileName']	= $xml_array->FileName;
				$style[$i]['SiteMaster']= $xml_array->SiteMaster;
				$style[$i]['PubDate']	= $xml_array->PubDate;
				$style[$i]['StyleType']	= $xml_array->StyleType;
				$style[$i]['summary']	= $xml_array->summary;
				$style[$i]['pic']		= '/themes/'.$val.'/'.$xml_array->pic;
				$i++;
			}
		}
		$this->assign('now_style',$this->config['DEFAULT_STYLE']);
		$this->assign('style',$style);
		$this->display('tpl/style');
	}
	
	//删除风格
	public function del_dir_file()
	{
		$dir_name = "../themes/".$_GET[0];
		if($this->config['DEFAULT_STYLE']==$_GET[0])
		{
			$this->error('风格正在使用禁止删除！');
		}
		else
		{
			del_dir($dir_name);
			$this->success('删除风格成功！','/read_style');
		}
	}
	
	//风格设置
	public function save_config()
	{
		$config['DEFAULT_STYLE'] = $_GET[0];
		$config_array			 = array();
		foreach($config as $key=>$value)
		{
			$config_array["config['".$key."']"] = $value;	
		}
		if(!$this->set_config($config_array))
		{
			$this->error('风格设置失败！');
		}
		else
		{
			$this->success('风格设置成功！','/read_style');
		}
	}
	
	//修改配置的函数 
	public function set_config($array,$config_file='./../config.php')
	{
		 if(empty($array)||!is_array($array))
		 {
			 return false;
		 }
	
		 $config = file_get_contents($config_file);//读取配置
		 foreach($array as $name=>$value)
		 { 
			$name=str_replace(array("'",'"','['),array("\\'",'\"','\['),$name);//转义特殊字符，再传给正则替换
			if(is_string($value)&&!in_array($value,array('true','false','3306')))
			{
				$value="'".$value."'";//如果是字符串，加上单引号
			}
			$config=preg_replace("/(\\$".$name.")\s*=\s*(.*?);/i", "$1={$value};", $config);//查找替换
		 }
		//写入配置
		if(file_put_contents($config_file,$config))
		return true;
		else 
		return false; 
	}
}

?>