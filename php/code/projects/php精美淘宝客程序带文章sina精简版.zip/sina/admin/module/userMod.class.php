<?php
class userMod extends commonMod
{
	//用户列表
	public function get_list()
	{
		$order		= in(isset($_GET[0]) ? trim($_GET[0]) :'id');
		$url		= __URL__.'/get_list-'.$order.'-page-{page}.html';
		$list_rows	= 10;
		$page		= new Page();
		$cur_page	= $page->getCurPage();	
		$where		= 'group_id!=1';	
		$count		= $this->model->table('user')->where($where)->count();
		$this->assign('list',$this->condition_list($list_rows,$cur_page,$where,$order));
		$this->assign('page',$page->show($url,$count,$list_rows));
		$this->display('user/list');
	}
	
	//查询列表
	public function condition_list($list_rows,$cur_page,$where,$order)
	{
		$limit_start = ($cur_page-1)*$list_rows;
		$limit		 = $limit_start.','.$list_rows;
		$list		 = $this->model->field('id,name,nickname,group_id,is_lock')->table('user')->where($where)->order($order.' DESC,id DESC')->limit($limit)->select();
		if($list)
		{
			foreach($list as & $val)
			{
				$val['edit'] = __URL__.'/edit-'.$val['id'].'.html';
				$val['del']  = __URL__.'/del-'.$val['id'].'.html';
			}
				return $list;
		}
	}
	
	//添加用户
	public function add()
	{
		if(empty($_POST['do']))
		{
			$this->assign('list',$this->model->field('id,name')->table('group')->where('id!=1')->select());
			$this->display('user/add');
			return;
		}
		//数据验证
		$msg = Check::rule(array(
							array(check::must($_POST['name']),'帐号不可为空！'),
							array(check::must($_POST['pwd']),'密码不可为空！'),
						  )); 
        //如果数据验证通不过，返回错误用户						   
		if($msg!==true)
		{                
			$this->error($msg);
		}
		
		$data = array();
		$data['name']		= in($_POST['name']);									//帐号
		$data['pwd']		= md5($this->config['CODE_PREFIX'].$_POST['pwd']);		//密码
		$data['group_id']	= in($_POST['group_id']);								//用户组
		$data['is_lock']	= intval($_POST['is_lock']);							//状态
		
		//添加数据
		if($this->model->table('user')->data($data)->insert())
		{
			$this->success('添加成功！','/get_list');
		}
		else
		{
			$this->error('添加失败！');
		}
	}
	
	//修改用户
	public function edit()
	{
		if(empty($_POST['do']))
		{
			$id = intval($_GET['0']);
			$this->assign('info',$this->info($id));
			$this->assign('list',$this->model->field('id,name')->table('group')->where('id!=1')->select());
			$this->display('user/edit');
			return;
		}
		//数据验证
		$msg = Check::rule(array(
							array(check::must($_POST['name']),'帐号不可为空！'),
							array(check::must($_POST['pwd']),'密码不可为空！'),
						  )); 
		//如果数据验证通不过，返回错误用户						   
		if($msg!==true)
		{                
			$this->error($msg);
		}
		$data = array();
		$data['name']		= in($_POST['name']);								//帐号
		$data['pwd']		= md5($this->config['CODE_PREFIX'].$_POST['pwd']);	//密码
		$data['group_id']	= in($_POST['group_id']);							//用户组
		$data['is_lock']	= intval($_POST['is_lock']);						//状态
		
		//修改数据
		$condition['id']	= intval($_POST['id']);
		if($this->model->table('user')->data($data)->where($condition)->update())
		{
			$this->success('修改成功！','/get_list');
		}
		else
		{
			$this->error('修改失败！');
		}
	}
	
	//密码设置
	public function edit_pwd()
	{
		$user_id = $_SESSION['user_id'];
		$info	 = $this->info($user_id);
		if(empty($_POST['do']))
		{
			$this->assign('info',$info);
			$this->display('user/edit_pwd');
			return;
		}
		
		$data	 = array();
		$oldpwd  = in($this->config['CODE_PREFIX'].$_POST['oldpwd']);
		
		if(md5($oldpwd)!=$info['pwd'])
		{
			$this->error('原密码输入错误！');
		}
		
		if($_POST['newpwd']==$_POST['newpwd2']&&!empty($_POST['newpwd']))
		{
			$data['pwd']=md5(in($this->config['CODE_PREFIX'].$_POST['newpwd']));
		}
		else
		{
			$this->error('两次输入的密码不一致，或者新密码为空！');
		}
		
		$condition['id']=$user_id;
		
		if($this->model->table('user')->data($data)->where($condition)->update())
		{
			$this->success('密码设置成功！','/edit_pwd');
		}
		else
		{
			$this->error('密码设置失败！或您未修改任何数据！');
		}
	}
	
	//读取用户
	public function info($id)
	{
		$condition['id'] = $id;
		$info = $this->model->table('user')->where($condition)->find();
		if($info)
		{
			$info['group']		= $this->model->table('group')->where('id='.$info['group_id'])->find();
			return $info;
		}
		else
		{
			$this->error('不存在此用户！');
		}
	}
	
	//删除用户
	public function del()
	{
		$condition['id'] = intval($_GET['0']);
		if($this->model->table('user')->where($condition)->delete())
		{
			$this->success('删除成功！','/get_list');
		}
		else
		{
			$this->error('删除失败！');
		}
	}
	
	//删除选中
	public function all_del()
	{
		$id		= $_POST['id'];
		$new_id = substr($id,0,strlen($id)-1); 
		if($this->model->table('user')->where('id in ('.$new_id.')')->delete())
		{	
			echo 1;
		}
		else
		{
			echo 0;
		}
	}
	
}
?>