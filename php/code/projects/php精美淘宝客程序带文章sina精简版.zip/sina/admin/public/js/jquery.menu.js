function initMenu() {
    $('#menu ul').hide();
    $('#menu ul:first').show();
    $('#menu li a').click(function(){
        var checkElement = $(this).next();
        if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            checkElement.removeClass("selected");
             $('#menu ul:visible>a').removeClass("selected");
            return false;
        }
        if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
            $('#menu ul:visible').slideUp('normal');
            checkElement.addClass("selected");
            checkElement.slideDown('normal');
            return false;
        }
    });
}
$(function() {initMenu();});