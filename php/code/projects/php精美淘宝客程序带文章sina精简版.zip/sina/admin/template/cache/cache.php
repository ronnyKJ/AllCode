<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" /></head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 缓存管理</h6>
	<div class="content">
	<div id="ltop">
   
    </div>
	<div class="bk20 hr"><hr /></div>
	<table id="list">
    <tr>
    <td width="35%">缓存目录</td>
	<td width="40%">描述</td>
    <td width="25%" style="padding:0px; text-align:center" >管理操作</td>
    </tr>
   	<?php if(!empty($list)){ ?>
	<tr>
    <td>cache</td>
	<td>全部缓存</td>
    <td style="padding:0px; text-align:center">
    <a href="__APP__/cache/clear.html">清除缓存</a> 
    </td>
    </tr>
	<?php foreach($list as $val){?>
    <tr>
    <td>{$val}</td>
	<td><?php if($val=='db_cache'){ echo '数据库缓存';}else if($val=='html_cache'){echo 'html缓存';}else{echo '模版缓存';}?></td>
    <td style="padding:0px; text-align:center">
    <a href="__APP__/cache/clear-{$val}.html">清除缓存</a> 
    </td>
    </tr>
    <?php }?>
    <?php }else{?>
    <tr><td colspan="3" style="text-align:center;">暂无数据！</td></tr>
    <?php }?>
    </table>
	</div>
</div>
</div>
</body>
</html>