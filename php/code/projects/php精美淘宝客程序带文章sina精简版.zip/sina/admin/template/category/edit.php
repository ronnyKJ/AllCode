<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	function check_form(obj){
		if(obj.title.value=='')
		{
			alert('信息栏目名称不能为空！');
			obj.title.focus();
			return false;
		}
		if(obj.module.value=='0')
		{
			alert('请选择栏目模型！');
			return false;
		}
		if(obj.template.value=='')
		{
			alert('信息栏目模版不能为空！');
			obj.template.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 编辑信息栏目</h6>
	<div class="content">
    <form name="edit" action="__URL__/edit" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.edit);" >
    <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%">名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：</td>
        <td><input name="title" type="text" style="width:200px;" value="{$info['title']}" /></td>
      </tr>
      <tr>
        <td>上级栏目：</td>
        <td><select name="parent_id">
        	<option value="0">顶级栏目</option>
            <?php if(!empty($list)){ foreach($list as $val){?>
            <option <?php if($val['id']==$info['parent_id']){ ?> selected="selected" <?php }?> value="{$val['id']}">{$val['fulltitle']}</option>
            <?php }}?>
        	</select></td>
      </tr>
      <tr>
        <td>栏目模型：</td>
        <td><select name="module">
        	<option value="0">选择模型</option>
            <option value="1" <?php if($info['module']==1){ ?> selected="selected" <?php }?> >信息模型</option>
        	</select>
        </td>
      </tr>
      <tr>
        <td>栏目模版：</td>
        <td><input name="template" type="text" style="width:150px;" value="{$info['template']}" /></td>
      </tr>
      <tr>
        <td>排&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;序：</td>
        <td><input name="show_order" type="text" value="{$info['show_order']}" /></td>
      </tr>
      <tr>
        <td>关 键&nbsp;&nbsp;词：</td>
        <td><input name="keywords" type="text" style="width:350px;" value="{$info['keywords']}" /></td>
      </tr>
      <tr>
        <td>描&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;述：</td>
        <td><textarea name="description" class="tex" cols="70" rows="6">{$info['description']}</textarea></td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /><input name="id" type="hidden" value="{$info['id']}" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 提 交 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>