<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script src="__PUBLIC__/js/jquery-1.3.2-vsdoc2.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function() {
//全选
$('#allck').bind('click',function () 
{
	 if($('#allck').attr("checked"))
	 {
		 $("input:checkbox").attr("checked",true);
		 }
	 else
	 {
		 $("input:checkbox").attr("checked",false);
		 }
   	});
//删除所选
$('#alldel').bind('click',function(){
	var id="";
	$("#list input:checked").each(function(){                
		id+=$(this).val()+',';
	});
	if(id=="")
	{
		alert("请选择要删除的数据！");
		return;
		}
	if(confirm('确定要删除吗？'))
	{
		$.ajax({
			type: "POST",
			url:  "__URL__/all_del",
			data: {id:id},
			success: function(data){
				if(data=="1")
				{
					alert("删除成功！");
					window.location.href="__URL__/get_list.html";
					}
				else{
					alert("删除失败！请确认栏目下是否含有子栏目！");
					}
				}
			});
		}
})
//保存排序
$('#set').bind('click',function(){
	var id="";
	var order="";
	$("input:text").each(function(){                
		id+=$(this).attr("name")+',';
		order+=$(this).val()+','
	});
	$.ajax({
		type: "POST",
		url:  "__URL__/set_sort",
		data: {id:id,order:order},
		success: function(data){
			if(data=="1")
			{
				alert("排序已更新！");
				window.location.href="__URL__/get_list.html";
				}
			else{
				alert("保存失败！");
				}
			}
		});
	});
})
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 信息栏目列表</h6>
	<div class="content">
	<div id="ltop">
    <span style="padding-left:0px;"><input id="allck" name="allck" type="checkbox" /> 全选</span>
    <a href="__URL__/add.html">添加</a>
    <a id="alldel">删除</a>
    <a id="set">排序</a>
    </div>
	<div class="bk20 hr"><hr /></div>
	<table id="list">
    <tr>
    <td width="5%">选择</td>
    <td width="5%">编号</td>
    <td width="20%">标题</td>
	<td width="30%">栏目模版</td>
    <td width="20%" style="padding:0px; text-align:center" >管理操作</td>
    <td width="8%" style="padding:0px; text-align:center" >排序【降序】</td>
    </tr>
   	<?php if(!empty($list)){ foreach($list as $val){?>
    <tr>
    <td><input name="ck" type="checkbox" value="{$val['id']}" /></td>
    <td>{$val['id']}</td>
    <td>{$val['fulltitle']}</td>
	<td>{$val['template']}</td>
    <td style="padding:0px; text-align:center">
    <a href="__URL__/add-{$val['id']}.html">添加子栏目</a> |
    <a href="__URL__/edit-{$val['id']}.html">修改</a> | 
    <a href="__URL__/del-{$val['id']}.html">删除</a> | 
    <a href="__APP__/article/get_list-{$val['id']}-show_order.html">内容管理</a>
    </td>
    <td style="padding:0px; text-align:center" ><input class="tx" name="{$val['id']}" type="text" value="{$val['show_order']}" /></td>
    </tr>
    <?php }?>
    <tr><td id="page" colspan="6" >{$page}</td></tr>
    <?php }else{?>
    <tr><td colspan="6" style="text-align:center;">暂无数据！</td></tr>
    <?php }?>
    </table>
	</div>
</div>
</div>
</body>
</html>