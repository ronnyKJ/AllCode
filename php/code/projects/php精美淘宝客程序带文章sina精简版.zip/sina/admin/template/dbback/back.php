<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script src="__PUBLIC__/js/jquery-1.3.2-vsdoc2.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function() {
   $("#allck").bind('click',function () {
	 if($('#allck').attr("checked")){
	 $("#dbck input:checkbox").attr("checked",true);}
	 else{$("#dbck input:checkbox").attr("checked",false);}
   });
   $("#dbback").click(function() {
	   var db="";
	   if($('#list input:checked').val()=="1")
	   {
		   db="allback";
		   }
	   if($('#list input:checked').val()=="2")
	   {
		   $("#dbck input:checked").each(function(){                
			  db+=$(this).val()+',';
		   });
		   }
	   if(db=="")
	   {
		   alert("请选择要备份的表");
		   return;
		   }
	   //删除提示
	   $.ajax({
		   type: "POST",
		   url: "__URL__/backup",
		   data: { tbName:db,dbsize:$('#dbsize').val(),dbsql:$('#dbsql').val()},
		   success: function(data) {
		   if(data==1){alert("备份成功！"); window.location.href="__URL__/get_table";}else{alert("备份失败！");}
		   }
		});
   });
   $("#dbinfo").hide();
   
  $("#allckr").bind('click',function () {
	 if($('#allckr').attr("checked")){
     $("#reco input:checkbox").attr("checked",true);}
	 else{$("#reco input:checkbox").attr("checked",false);}
   }
  );
  $("#del").click(function() {
  //获取ID
  var s="";
  $("#list input:checked").each(function(){                
  s+=$(this).val()+',';
  });
  if(s=="1,")
  {
	  alert("请选择要删除的文件！");
	  return false;
  }
  //删除提示
  if(confirm('确定要删除吗？'))
  {//ajax操作
  $.ajax({
  type: "POST",
  url: "__URL__/alldel",
  data: { fileName:s},
  success: function(data) {
  if(data=="1")
  {alert("删除成功！");
  window.location.href="__URL__/get_table";
  }else{alert("删除失败！");}
  }});
  }
  });
});
function show()
{
	$("#dbinfo").show();
}
function hide()
{
	$("#dbinfo").hide();
}
</script>

</head>
<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 备份数据</h6>
	<div class="content">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="list">
      <tr>
        <td width="20%"><input name="back" type="radio" value="1" onclick="hide()" checked="checked" /> 全部备份</td>
        <td>备份数据库所有表</td>
      </tr>
      <tr>
        <td><input id="zdy" name="back" type="radio" value="2" onclick="show()"/> 自定义备份</td>
        <td>根据需要自行选择备份数据表</td>
      </tr>
      <tr>
        <td colspan="2" id="dbinfo">
        <input id="allck" name="" type="checkbox" value="" style="margin-left:10px;" /> 全选
        <div id="dbck">
        <?php if($table){foreach($table as $val){ ?>
        <span><input name="" type="checkbox" value="{$val}" /> {$val}</span>
        <?php }} ?>
        </div>
		</td>
      </tr>
      <tr>
        <td>大小</td>
        <td><input id="dbsize" name="dbsize" type="text" style="border:1px solid #cadcb2;"  value="2048"/></td>
      </tr>
      <tr>
        <td>备份文件名</td>
        <td><a id="dbsql" name="dbsql">{$dbname}</a></td>
      </tr>
      <tr>
        <td><input type="hidden" name="do" value="yes" /></td>
        <td><input id="dbback" name="submit" type="button" style="border:1px solid #cadcb2;" value=" 开 始 备 份 " /></td>
      </tr>
    </table>
	</div>
</div>
</div>

<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 恢复数据</h6>
	<div class="content" id="reco">
    <table width="100%" border="0" cellpadding="0" id="list"  style="margin-top:20px;">
    <tr>
    <td colspan="6" >服务器上备份文件</td>
    </tr>
    <tr>
    <td width="5%" ><input id="allckr" name="checkbox" type="checkbox" value="all" /> 全选</td>
    <td width="20%">文件名</td>
    <td width="10%">版本</td>
    <td width="10%">时间</td>
    <td width="10%">大小</td>
    <td width="7%">管理操作</td>
    </tr>
    <?php if($list){foreach($list as $val){ ?> 
    <tr>
    <td>
    <input name="checkbox" type="checkbox"  value="{$val['name']}" /></td>
    <td>{$val['name']}</td>
    <td>{$val['edition']}</td>
    <td>{$val['time']}</td>
    <td>{$val['size']}kb</td>
    <td><span >[</span><a href="recovery.html?path=../data/dbback/">导入</a><span >]</span></td>
    </tr>
    <?php } ?>
    <tr><td colspan="6"  style="text-align:center;">
    <input id="del" style="border:1px solid #cadcb2;" name="" type="button" value=" 删 除 备 份 " /></td></tr>
    <?php }else{ ?>
    <tr><td colspan="6"  style="text-align:center;">暂无数据！</td></tr>
    <?php } ?>
    </table>
	</div>
</div>
</div>
</body>
</html>