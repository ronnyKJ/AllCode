<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<script type="text/javascript" src="{$Lqcms}/kindeditor/kindeditor.js"></script>
<script type="text/javascript" src="{$Lqcms}/kindeditor/lang/zh_CN.js"></script>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<link href="{$Lqcms}/kindeditor/themes/default/default.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	function check_form(obj){
		if(obj.title.value=='')
		{
			alert('焦点名称不能为空！');
			obj.title.focus();
			return false;
		}
		if(obj.url.value=='')
		{
			alert('焦点地址不能为空！');
			obj.url.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 添加焦点</h6>
	<div class="content">
    <form name="add" action="__URL__/add" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.add);" >
    <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%">名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：</td>
        <td><input name="title" type="text" style="width:200px;" /></td>
      </tr>
      <tr id="logo">
        <td>焦点图片：</td>
        <td>
        <script type="text/javascript">
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							imageUrl : K('#url').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
        <input name="pic" type="text" id="url" value="" /> <input type="button" id="image" value="选择图片" />
        </td>
      </tr>
      <tr>
        <td>焦点地址：</td>
        <td><input name="url" type="text" style="width:350px;" /></td>
      </tr>
      <tr>
        <td>排&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;序：</td>
        <td><input name="show_order" type="text" value="255" /></td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 提 交 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>