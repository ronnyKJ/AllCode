<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<script type="text/javascript" src="{$Lqcms}/kindeditor/kindeditor.js"></script>
<script type="text/javascript" src="{$Lqcms}/kindeditor/lang/zh_CN.js"></script>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<link href="{$Lqcms}/kindeditor/themes/default/default.css" rel="stylesheet" type="text/css" />
<script src="__PUBLIC__/js/jquery-1.3.2-vsdoc2.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('#type').bind('change',function(){
		if($('#type').val()!='2')
		{
			$('#logo').css('display','none');
			}
		else
		{
			$('#logo').css('display','');
			}
	});
	})
	function check_form(obj){
		if(obj.title.value=='')
		{
			alert('链接名称不能为空！');
			obj.title.focus();
			return false;
		}
		if(obj.url.value=='')
		{
			alert('链接地址不能为空！');
			obj.url.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 编辑友链</h6>
	<div class="content">
    <form name="edit" action="__URL__/edit" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.edit);" >
      <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%">名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：</td>
        <td><input name="title" type="text" value="{$info['title']}" style="width:200px;" /></td>
      </tr>
      <tr>
        <td>链接类型：</td>
        <td><select id="type" name="type">
        	<option value="{$info['type']}"><?php if($info['type']==1){ echo "文本链接";}else{ echo "图片链接";}?></option>
        	<option value="1">文本链接</option>
            <option value="2">图片链接</option>
        	</select></td>
      </tr>
      <tr id="logo" <?php if($info['type']!=2){ ?>style="display:none;"<?php }?>>
        <td>友链图片：</td>
        <td>
        <script type="text/javascript">
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							imageUrl : K('#url').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
        <input name="logo" type="text" id="url" value="" /> <input type="button" id="image" value="选择图片" />
        </td>
      </tr>
      <tr>
        <td>链接地址：</td>
        <td><input name="url" type="text" style="width:350px;" value="{$info['url']}" /></td>
      </tr>
      <tr>
        <td>排&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;序：</td>
        <td><input name="show_order" type="text" value="{$info['show_order']}" /></td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /><input name="id" type="hidden" value="{$info['id']}" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 提 交 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>