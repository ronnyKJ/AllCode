<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" class="off">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<title>狼群CMS - 后台管理中心</title>
<link href="__PUBLIC__/css/common.css" rel="stylesheet" type="text/css" />
<script src="__PUBLIC__/js/jquery-1.3.2-vsdoc2.js" type="text/javascript"></script>
<script src="__PUBLIC__/js/jquery.menu.js" type="text/javascript"></script>
</head>
<body scroll="no" class="objbody">
<div class="header" style="width: auto; ">
<a href="/"><div class="logo"></div></a>
<ul class="frame-top-nav" id="js_frame_nav_top">
<li><a href="__URL__/welcome.html" target="right" class="nav focus">系统主页</a></li>
<li><a href="__APP__/tbk/tkapi.html" target="right" class="nav">淘客设置</a></li>
<li><a href="__APP__/site/set_up.html" target="right" class="nav">网站设置</a></li>        
<li><a href="__APP__/tpl/read_style.html" target="right" class="nav">风格设置</a></li>        
<li><a href="__APP__/index/plugins.html" target="right" class="nav">插件中心</a></li>
<li><a href="__APP__/dbback/get_table.html" target="right" class="nav">数据备份</a></li>        
</ul>
<!--用户菜单-->
<ul class="user-menu">
<li><a href="{$Lqcms}" target="_blank" class="menu-switch" style="padding-right:7px;">
<b class="no-data">网站首页</b></a></li>
<li><a class="menu-switch" href="http://bbs.lqcms.net/"><span>官方论坛</span></a></li>
<li><a class="menu-switch"><span>{$info['nickname']}</span></a></li>
<li><a href="__APP__/index/login_out.html" target="_top" class="menu-switch"><span>退出</span></a></li>
</ul>
</div>
<div id="content" style="width:auto;">
<!--内左边容-->
<div class="col-left">
<div id="Scroll" style="height:840px;">
<div id="leftMain">
<ul id="menu">

<li><a href=""><span class="icon1">会员中心</span></a>
<ul style="display:block;">
<li><a href="__APP__/user/get_list.html" target="right">用户列表</a></li>            
<li><a href="__APP__/user/edit_pwd.html" target="right">修改密码</a></li>            
</ul>
</li>

<li><a href=""><span class="icon2">内容管理</span></a>
<ul style="display:none;">
<li><a href="__APP__/category/get_list.html" target="right">栏目设置</a></li>            
<li><a href="__APP__/article/get_list.html" target="right">信息列表</a></li>
<li><a href="__APP__/page/get_list.html" target="right">单页管理</a></li>           
<li><a href="__APP__/comment/get_list.html" target="right">评论管理</a></li>        
</ul>
</li>

<li><a href=""><span class="icon2">界面设置</span></a>
<ul style="display:none;">
<li><a href="__APP__/nav/get_list.html" target="right">导航设置</a></li>            
<li><a href="__APP__/focus/get_list.html" target="right">首页轮换</a></li>            
<li><a href="__APP__/friend/get_list.html" target="right">友情链接</a></li>        
</ul>
</li>
<li><a href=""><span class="icon5">插件管理</span></a>
<ul style="display:none;">
<?php Plugin::hook('_pluginMenu');?>       	
</ul>
</li>
<li><a href=""><span class="icon5">蜘蛛管理</span></a>
<ul style="display:none;">
<li><a href="__APP__/spider/get_list.html" target="right">爬行统计</a></li>            
<li><a href="__APP__/spider/spider_list-baiduspider-id.html" target="right">百度蜘蛛</a></li>            	
</ul>
</li>

<li><a href=""><span class="icon7">系统设置</span></a>
<ul style="display:none;">
<li><a href="__APP__/cache/cache.html" target="right">缓存管理</a></li>            
<li><a href="__APP__/site/set_up.html" target="right">站点设置</a></li>           
<li><a href="__APP__/site/save_config.html" target="right">系统配置</a></li>	
</ul>
</li>

</ul>
</div>
</div>
</div>
<!--正文内容-->
<div class="col-auto">  
<div class="col-1">
<div class="content" style="position:relative; overflow:hidden">
<iframe name="right" id="rightMain" src="__URL__/welcome.html" frameborder="false" scrolling="auto" style="border-top-style: none; border-right-style: none; border-bottom-style: none; border-left-style: none; border-width: initial; border-color: initial; border-image: initial; height: 835px; " width="100%" height="auto" allowtransparency="true">
</iframe>
</div>
</div>
</div>

</div>
<script type="text/javascript">
if(!Array.prototype.map)
Array.prototype.map=function(fn,scope){var result=[],ri=0;for(var i=0,n=this.length;i<n;i++){if(i in this){result[ri++]=fn.call(scope,this[i],i,this)}}return result};
var getWindowSize=function(){return["Height","Width"].map(function(name){return window["inner"+name]||document.compatMode==="CSS1Compat"&&document.documentElement["client"+name]||document.body["client"+name]})}
window.onload=function(){if(!+"\v1"&&!document.querySelector){document.body.onresize=resize}else{window.onresize=resize}function resize(){wSize();return false}}
function wSize(){
    var str=getWindowSize();
    var strs= new Array(); //定义一数组
    strs=str.toString().split(","); //字符分割
    var heights = strs[0]-45,Body = $('body');$('#rightMain').height(heights);   
    if(strs[1]<980){
        $('.header').css('width',980+'px');
        $('#content').css('width',980+'px');
        Body.attr('scroll','');
        Body.removeClass('objbody');
    }else{
        $('.header').css('width','auto');
        $('#content').css('width','auto');
        Body.attr('scroll','no');
        Body.addClass('objbody');
    }
    var openClose = $("#rightMain").height()+25;
    $("#Scroll").height(openClose-20);
}
wSize();
//导航
$(function(){$('.nav').click(function(){$('.nav').removeClass('focus');$(this).addClass('focus');});});
</script>
<div id="ldg_dragmask" style="display: none; position: fixed; left: 0px; top: 0px; width: 100%; height: 100%; cursor: move; opacity: 0; background-image: initial; background-attachment: initial; background-origin: initial; background-clip: initial; background-color: rgb(255, 255, 255); pointer-events: none; background-position: initial initial; background-repeat: initial initial; "></div>
</body>
</html>