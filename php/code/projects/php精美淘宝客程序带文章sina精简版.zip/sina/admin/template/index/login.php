<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>网站后台管理中心-Powered by Lqcms</title>
<link href="__PUBLIC__/css/login.css" rel="stylesheet" type="text/css" />
<script src="__PUBLIC__/js/jquery.js" type="text/javascript"></script>
<script src="__PUBLIC__/js/login.js" type="text/javascript"></script>
<script type="text/javascript">
//重载验证码
function fleshVerify()
{
var timenow = new Date().getTime();
document.getElementById('verifyImg').src= '__URL__/verify.html?'+timenow;
//提交数据前，对数据进行检查
}
</script>
</head>

<body>

<div class="container">
<div class="header">
<h1 class="logo"><a href="">狼群淘客意在共赢！</a></h1>
</div>

<div class="main">
<div class="contents">
<div class="feature-box">
<div class="feature-show fs-cloud" id="js_big_pic"></div>
<ul class="feature-list" id="js_feature-list">
<li>
<div class="feature-text ft-cloud" style="display:none;"><strong>系统</strong><span>高效率高负载 &#8226; 简单灵活</span></div>
<div class="feature-point fp-cloud"></div>
</li>
<li>
<div class="feature-text ft-message" style="display:none;"><strong>淘客</strong><span>推广渠道任您挑 &#8226; 互通共赢</span></div>
<div class="feature-point fp-message"></div>
</li>
<li>
<div class="feature-text ft-note" style="display:none;"><strong>掌柜</strong><span>找寻淘客不用愁 &#8226; 广告计划</span></div>
<div class="feature-point fp-note"></div>
</li>
</ul>
</div>
<div class="login-box">
<dl class="login-form">
<dt>用户登录</dt>
<dd>
<form id="js_login_form" action="__URL__/login" method="post" >
<ul>
<li>
<label for="account">请输入管理员帐号</label>
<input type="text" name="name" id="account" class="text" errortype="notempty" errmsgtype="1" value="" tabindex="1" errmsg="请输入管理员帐号 "/>
</li>
<li>
<label for="passwd">请输入您的密码</label>
<input type="password"  name="pwd" id="passwd" errortype="notempty" errmsgtype="1" class="text" tabindex="2" errmsg="请输入密码" />
</li>
<li>
<label for="checkcode">验证码</label>
<input type="text" name="checkcode" id="checkcode" class="text" style="width:150px;" errortype="notempty" errmsgtype="1"  tabindex="3" errmsg="请输入验证码" />
<img src='__URL__/verify' name="verifyImg" align="absmiddle" id="verifyImg" style='width:100px; height:39px; float:right; cursor:pointer;border:#999999' title="看不请验证码？点击更换一张" onclick="fleshVerify();"/>
</li>
</ul>
<div class="login-button">
<button type="submit"><i>登录</i></button>
</div>
</form>
</dd>
</dl>

</div>
</div>
</div>
<div class="footer">
<ul class="client-list">
<li><a>欢迎您使用狼群淘客系统！狼群淘客是一款简洁、开源、高效、免费的淘宝商品推广系统。具有高效率、高负载量、灵活、简单的特点。</a></li>
</ul>
<p>Copyright © 2012 The <a href="http://www.ibtf.net/">Wolves</a> Network Taobao Customer System. All rights reserved.</p>
<p> <a href="http://www.ibtf.net/" target="_blank" >淘宝客</a>·<a href="http://www.hbwanghai.com/" target="_blank" >网站建设</a>　 <a href="http://www.ibtf.net/" target="_blank" >淘客</a></p>
</div>
</div>
<!--[if IE 6]>
<script src="__PUBLIC__/js/transparent_v62.js" type="text/javascript"></script>
<![endif]-->
<script type="text/javascript">
(function(){
H.Login.Init($("#js_login_form"));
var error = '';
var account = $("#account"), pwd = $("#passwd"), cd = $("#checkcode");
if(error){
var errShowBox;
var errCode = '';
if(errCode == '300'){
errShowBox = account;
}
else if(errCode == ''){
errShowBox = pwd;
}
else{
errShowBox = checkcode;
}
H.Login.ShowMsg(errShowBox, error);
window.setTimeout(function(){
errShowBox.focus();
}, 50);
}
else{
window.setTimeout(function(){
if(account.val() == ""){
account.focus();
}
else if(pwd.val() == ""){
pwd.focus();
}else{
cd.focus();
}
}, 100);
}

$(document).ready(function(){
var list = [];
$("#js_feature-list").find("li").each(function(i){
var el = $(this);
list.push({Tab: el.find(".feature-point"), Content: el.find(".feature-text"), ind:i});
});
var tab = new H.TabManager(list, "feature-point", "feature-point");
tab.Animate = true;
tab.SetAuto(true);
tab.SetChangeHandler(function(obj){

var arr = ["cloud", "message","note"];
var ind = obj.ind;

var box = $("#js_big_pic");
for(var i = 0, len = arr.length; i < len; i++){
box.removeClass("fs-" + arr[i]);
}
box.addClass("fs-" + arr[ind]);
});
window.setTimeout(function(){
tab.Select(0);
},1000);
tab._autoTimeOut = 8000;

var changeHeight = function(){
var containBox = $(".container");
var cH = containBox.height(), dH = $(document).height();

var h = (dH - cH) / 3;
if(!h){
h = 0;
}
containBox.css({top: h});
}
changeHeight();
$(window).on("resize", function(){
changeHeight();
})

});
})();

</script>
</body>
</html>