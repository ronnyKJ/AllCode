<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 插件列表</h6>
	<div class="content">
	<div id="ltop">
    </div>
	<div class="bk20 hr"><hr /></div>
	<table id="list">
    <tr>
    <td width="20%">插件名称</td>
    <td width="20%">插件版本</td>
    <td width="20%">插件作者</td>
	<td width="30%">更新时间</td>
    <td width="10%" style="padding:0px; text-align:center" >管理操作</td>
    </tr>
   	<?php Plugin::hook('_pluginList'); ?>
    </table>
	</div>
</div>
</div>
</body>
</html>