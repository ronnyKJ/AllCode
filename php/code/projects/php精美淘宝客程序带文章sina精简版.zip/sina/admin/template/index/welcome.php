<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>欢迎</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="explain-col mb10" style="display:none" id="browserVersionAlert">
</div>
<div class="col-2 lf mr10" style="width:48%">
	<h6>我的个人信息</h6>
	<div class="content"> 
	您好！ {$info['name']}<br/>
	用户组： {$group_name}
	<div class="bk20 hr"><hr /></div>
	登录IP：{$login_ip}<br/>
	</div>
</div>
<div class="col-2 col-auto">
	<h6>最新动态</h6>
	<div class="content" style="color:#ff0000;">
	※ <a href="{$xml['menu']['note']['0']['url']}" style="color:#ff0000;" target="_blank" >{$xml['menu']['note']['0']['title']}</a><br/>
	※ <a href="{$xml['menu']['note']['1']['url']}" style="color:#ff0000;" target="_blank" >{$xml['menu']['note']['1']['title']}</a>
	<div class="bk20 hr"><hr /></div>
	※ <a href="{$xml['menu']['note']['2']['url']}" style="color:#ff0000;" target="_blank" >{$xml['menu']['note']['2']['title']}</a><br/>
	※ <a href="{$xml['menu']['note']['3']['url']}" style="color:#ff0000;" target="_blank" >{$xml['menu']['note']['3']['title']}</a>
	</div>
</div>
<div class="bk10"></div>
<div class="col-2 lf mr10" style="width:48%">
	<h6>快捷方式</h6>
	<div class="content" id="admin_panel">


	</div>
</div>
<div class="col-2 col-auto">
	<h6>系统信息</h6>
	<div class="content">
	Lqcms程序版本： 狼群淘客1.0beta<br/>
	程序目录： {$lqcms['catalog']}<br/>
	服务器软件：{$lqcms['server_software']}<br/>
	MySQL 版本： {$lqcms['mysql']}<br/>
	上传文件： {$lqcms['upload_file']} 
	</div>
</div>
<div class="bk10"></div>
<div class="col-2 lf mr10" style="width:48%">
	<h6>开发与支持团队：</h6>
	<div class="content">
	版权所有： 狼群淘客<br/>
	总 策 &nbsp;划： 王 聪 <br/>
	开发与支持团队： 王 聪 <br/>
	淘客网站：<a href="http://www.ibtf.net/">http://www.ibtf.net/</a>
	</div>
</div>

<div class="col-2 col-auto">
	<h6>授权信息</h6>
	<div class="content">
	程序版本：狼群淘客1.0beta<br/>
    
	</div>
</div>
    <div class="bk10"></div>
</div>
</body>
</html>