<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	function check_form(obj){
		if(obj.title.value=='')
		{
			alert('导航名称不能为空！');
			obj.title.focus();
			return false;
		}
		if(obj.url.value=='')
		{
			alert('导航地址不能为空！');
			obj.url.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 编辑导航</h6>
	<div class="content">
    <form name="edit" action="__URL__/edit" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.edit);" >
      <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%">名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：</td>
        <td><input name="title" type="text" value="{$info['title']}" style="width:200px;" /></td>
      </tr>
       <tr>
        <td>上级页面：</td>
        <td><select name="pid">
        	<option value="0">顶级栏目</option>
			<?php if(!empty($list)){ foreach($list as $val){?>
            <option <?php if($info['pid']==$val['id']){ ?> selected="selected" <?php }?> value="{$val['id']}">{$val['fulltitle']}</option>
            <?php }}?>
        	</select></td>
      </tr>
      <tr>
        <td>导航地址：</td>
        <td><input name="url" type="text" style="width:350px;" value="{$info['url']}" /></td>
      </tr>
      <tr>
        <td>排&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;序：</td>
        <td><input name="show_order" type="text" value="{$info['show_order']}" /></td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /><input name="id" type="hidden" value="{$info['id']}" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 提 交 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>