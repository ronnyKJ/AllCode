<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<script type="text/javascript" src="{$Lqcms}/kindeditor/kindeditor.js"></script>
<script type="text/javascript" src="{$Lqcms}/kindeditor/lang/zh_CN.js"></script>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	function check_form(obj){
		if(obj.title.value=='')
		{
			alert('单页标题不能为空！');
			obj.title.focus();
			return false;
		}
		return true;
	}
	function hide()
	{
		if(document.getElementById('tr_keywords').style.display=="none")
		{
			document.getElementById('tr_keywords').style.display="";
			document.getElementById('tr_description').style.display="";
		}
		else
		{
			document.getElementById('tr_keywords').style.display="none";
			document.getElementById('tr_description').style.display="none";
		}
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 添加单页</h6>
	<div class="content">
    <form name="add" action="__URL__/add" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.add);" >
    <div id="opet">
    <span style="padding-left:0px;"><input style="width:20px;" name="recmt" type="checkbox" value="1" /> 推荐</span>
    <span>阅读：<input name="views" type="text" style="width:35px;" value="<?php echo mt_rand(0,1000); ?>" /></span>
    <span>排序：<input name="show_order" type="text" value="255" /></span>
    </div>
    <div class="bk20 hr"><hr /></div>
    <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%">标&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;题：</td>
        <td><input name="title" type="text" style="width:450px;" /></td>
      </tr>
	  <tr>
        <td>上级页面：</td>
        <td><select name="pid">
        	<option value="0">顶级栏目</option>
			<?php if(!empty($list)){ foreach($list as $val){?>
            <option <?php if($pid==$val['id']){ ?> selected="selected" <?php }?> value="{$val['id']}">{$val['fulltitle']}</option>
            <?php }}?>
        	</select> <input type="button" value=" 显示/隐藏关键词和摘要 " class="submit" onClick="hide()"></td>
      </tr>
      <tr>
        <td>附&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;件：</td>
        <td>
        <script type="text/javascript">
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							imageUrl : K('#url').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
        <input name="pic" type="text" id="url" value="" /> <input type="button" id="image" value="选择图片" />
        </td>
      </tr>
      <tr id="tr_keywords" style="display:none;" >
        <td>关 键&nbsp; 词：</td>
        <td><input name="keywords" type="text" style="width:350px;" /></td>
      </tr>
      <tr id="tr_description" style="display:none" >
        <td>描&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;述：</td>
        <td><textarea name="description" class="tex" cols="80" rows="5"></textarea></td>
      </tr>
      <tr>
        <td>内&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;容：</td>
        <td style="padding:10px 10px 10px 15px;">
        <textarea id="editor_id" name="content" style="width:800px;height:350px;">
        欢迎试用Lqcms内容管理系统！        
        </textarea>
        <script>
        var editor;
        KindEditor.ready(function(K) {
                editor = K.create('#editor_id');
        });
		</script>
        </td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 提 交 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>