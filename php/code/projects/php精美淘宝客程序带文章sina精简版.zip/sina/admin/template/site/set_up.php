<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	function check_form(obj){
		if(obj.name.value=='')
		{
			alert('站点名称不能为空！');
			obj.name.focus();
			return false;
		}
		if(obj.siteurl.value=='')
		{
			alert('站点网址不能为空！');
			obj.siteurl.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>站点设置</h6>
	<div class="content">
    <form name="add" action="__URL__/set_up" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.add);" >
    <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%">站点名称：</td>
        <td><input name="name" type="text" style="width:280px;" value="{$read['name']}" /></td>
      </tr>
      <tr>
        <td>企业邮箱：</td>
        <td><input name="email" type="text" style="width:280px;" value="{$read['email']}" /></td>
      </tr>
      <tr>
        <td>ICP 备案：</td>
        <td><input name="icpcode" type="text" style="width:280px;" value="{$read['icpcode']}" /></td>
      </tr>
      <tr>
        <td>公司地址：</td>
        <td><input name="address" type="text" style="width:450px;" value="{$read['address']}" /></td>
      </tr>
      <tr>
        <td>公司电话：</td>
        <td><input name="tel" type="text" style="width:280px;" value="{$read['tel']}" /></td>
      </tr>
      <tr>
        <td>公司传真：</td>
        <td><input name="fax" type="text" style="width:280px;" value="{$read['fax']}" /></td>
      </tr>
      <tr>
        <td>在线咨询：</td>
        <td><input name="qq" type="text" style="width:280px;" value="{$read['qq']}" /> 注：多个qq请用,隔开！</td>
      </tr>
      <tr>
        <td>站点网址：</td>
        <td><input name="siteurl" type="text" style="width:350px;" value="{$read['siteurl']}" /></td>
      </tr>
      <tr>
        <td>站点标题：</td>
        <td><input name="title" type="text" style="width:350px;" value="{$read['title']}" /></td>
      </tr>
      <tr>
        <td>关 键&nbsp;&nbsp;词：</td>
        <td><input name="keywords" type="text" style="width:350px;" value="{$read['keywords']}" /> 注：关键词请用,号隔开</td>
      </tr>
      <tr>
        <td>描&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;述：</td>
        <td><textarea name="description" class="tex" cols="80" rows="5">{$read['description']}</textarea></td>
      </tr>
      <tr>
        <td>站外统计：</td>
        <td><textarea name="statistical" class="tex" cols="80" rows="5">{$read['statistical']}</textarea></td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 保 存 设 置 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>
