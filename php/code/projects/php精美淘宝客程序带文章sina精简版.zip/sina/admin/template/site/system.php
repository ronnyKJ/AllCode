<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 系统设置</h6>
	<div class="content">
    <form action="__URL__/save_config" method="post" enctype="multipart/form-data" >
    <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="15%">伪&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;静&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;态：</td>
        <td><input name="URL_REWRITE_ON" type="radio" value="true" <?php if($cfg['URL_REWRITE_ON'])  {?>checked="checked"<?php } ?> />开启
        	<input name="URL_REWRITE_ON" type="radio" value="false" <?php if(!$cfg['URL_REWRITE_ON']){?>checked="checked"<?php } ?> />关闭
        	<span style="color: rgb(255, 102, 0);">(开启前请确认服务器是否支持伪静态！谨慎操作！)</span></td>
      </tr>
      <tr>
        <td width="15%">数 据 库 缓 存：</td>
        <td><input name="DB_CACHE_ON" type="radio" value="true" <?php if($cfg['DB_CACHE_ON'])  {?>checked="checked"<?php } ?> />开启
        	<input name="DB_CACHE_ON" type="radio" value="false" <?php if(!$cfg['DB_CACHE_ON']){?>checked="checked"<?php } ?> />关闭
        </td>
      </tr>
       <tr>
        <td width="15%">模 版 页 缓 存：</td>
        <td><input name="TPL_CACHE_ON" type="radio" value="true" <?php if($cfg['TPL_CACHE_ON'])  {?>checked="checked"<?php } ?> />开启
        	<input name="TPL_CACHE_ON" type="radio" value="false" <?php if(!$cfg['TPL_CACHE_ON']){?>checked="checked"<?php } ?> />关闭
        </td>
      </tr>
       <tr>
        <td width="15%">静 态 页 缓 存：</td>
        <td><input name="HTML_CACHE_ON" type="radio" value="true" <?php if($cfg['HTML_CACHE_ON'])  {?>checked="checked"<?php } ?> />开启
        	<input name="HTML_CACHE_ON" type="radio" value="false" <?php if(!$cfg['HTML_CACHE_ON']){?>checked="checked"<?php } ?> />关闭
        </td>
      </tr>
      <tr>
        <td width="15%">静态页缓存时间：</td>
        <td>
        <input name="HTML_CACHE_TIME" type="text" value="{$cfg['HTML_CACHE_TIME']}" />
        <span style="color: rgb(255, 102, 0);">(缓存时间,单位秒！)</span>
        </td>
      </tr>
      <tr>
        <td width="15%">数据库缓存时间：</td>
        <td>
        <input name="DB_CACHE_TIME" type="text" value="{$cfg['DB_CACHE_TIME']}" />
        <span style="color: rgb(255, 102, 0);">(缓存时间,0不缓存，-1永久缓存，单位秒!)</span>
        </td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 保 存 设 置 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>
