<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 蜘蛛统计</h6>
	<div class="content">
	<div id="ltop">
    
    </div>
	<div class="bk20 hr"><hr /></div>
	<table id="list">
    <tr>
    <td width="5%">编号</td>
    <td width="18%">名称</td>
	<td width="8%">爬行次数</td>
    <td width="15%">最后爬行时间</td>
    <td width="32%">最后爬行地址</td>
    <td width="6%" style="padding:0px; text-align:center" >管理操作</td>
    </tr>
   	<?php if(!empty($list)){ foreach($list as $val){?>
    <tr>
    <td>{$val['id']}</td>
    <td><a href="__URL__/spider_list-{$val['name']}-id.html">{$val['name']}</a></td>
	<td>{$val['view']}</td>
    <td>
   <?php echo date('y-m-d h:i:s',$val['time']); ?>
    </td>
    <td>{$val['url']}</td>
    <td style="padding:0px; text-align:center">
    <a href="__URL__/spider_list-{$val['name']}-id.html">查看列表</a>
    </td>
    </tr>
    <?php }}else{?>
    <tr><td colspan="6" style="text-align:center;">暂无数据！</td></tr>
    <?php }?>
    </table>
	</div>
</div>
</div>
</body>
</html>