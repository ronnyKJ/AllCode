<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script src="__PUBLIC__/js/jquery-1.3.2-vsdoc2.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function() {
//全选
$('#allck').bind('click',function () 
{
	 if($('#allck').attr("checked"))
	 {
		 $("input:checkbox").attr("checked",true);
		 }
	 else
	 {
		 $("input:checkbox").attr("checked",false);
		 }
   	});
//删除所选
$('#alldel').bind('click',function(){
	var id="";
	$("#list input:checked").each(function(){                
		id+=$(this).val()+',';
	});
	if(id=="")
	{
		alert("请选择要删除的数据！");
		return;
		}
	if(confirm('确定要删除吗？'))
	{
		$.ajax({
			type: "POST",
			url:  "__URL__/all_del",
			data: {id:id},
			success: function(data){
				if(data=="1")
				{
					alert("删除成功！");
					window.location.href="__URL__/get_list.html";
					}
				else{
					alert("删除失败！");
					}
				}
			});
		}
})
})
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 蜘蛛列表</h6>
	<div class="content">
	<div id="ltop">
    <span style="padding-left:0px;"><input id="allck" name="allck" type="checkbox" /> 全选</span>
    <a id="alldel">删除</a>
    </div>
	<div class="bk20 hr"><hr /></div>
	<table id="list">
    <tr>
    <td width="5%">选择</td>
    <td width="5%">编号</td>
    <td width="18%">名称</td>
    <td width="10%">时间</td>
	<td width="32%">地址</td>
    <td width="6%" style="padding:0px; text-align:center" >管理操作</td>
    </tr>
   	<?php if(!empty($list)){ foreach($list as $val){?>
    <tr>
    <td><input name="ck" type="checkbox" value="{$val['id']}" /></td>
    <td>{$val['id']}</td>
    <td>{$val['name']}</td>
	<td><?php echo date('y-m-d h:i:s',$val['time']); ?></td>
    <td >{$val['url']}</td>
    <td style="padding:0px; text-align:center">
    <a href="{$val['del']}">删除</a>
    </td>
    </tr>
    <?php }?>
    <tr><td id="page" colspan="6" >{$page}</td></tr>
    <?php }else{?>
    <tr><td colspan="6" style="text-align:center;">暂无数据！</td></tr>
    <?php }?>
    </table>
	</div>
</div>
</div>
</body>
</html>