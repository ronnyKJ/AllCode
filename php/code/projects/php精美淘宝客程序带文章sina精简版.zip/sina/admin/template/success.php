<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv='Refresh' content='{$waitSecond};URL={$url}'>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<style type="text/css">
A:link, A:visited, A:active, A:hover { COLOR: #6f9822; TEXT-DECORATION: none }
A:hover{ color:#6C6 }
body{font-size:12px; color: #555; line-height: 150%; }
h4{font-weight:normal; font-size:14px; padding-left:20px; height:10px;}
div{margin:0; padding:0; }
.info,.topbg,.footbg{background: url(__PUBLIC__/images/sucess.gif);width:512px; height:30px;background-position: -512px 0px; background-repeat: no-repeat;}
.container{background: url(sucess.gif); margin:60px auto; width:512px; }
.info{background-position: 0px 0px;  background-repeat: repeat-y; height:auto; text-indent:30px; }
.info span{ color:#FF0000; font-weight:bold}
.footbg{background-position: -512px -30px;}
</style>
<title>温馨提示</title>
</head>
<body>
<div class="container">
  <div class="topbg"></div>
  <div class="info">
    <h4>温馨提示</h4>
    <h4>{$message}</h4>
    <p><span>{$waitSecond}</span> 秒后自动跳转,如果不想等待,直接点击 <A HREF="{$url}">这里跳转</A> </p>
  </div>
  <div class="footbg"></div>
</div>
</body>
</html>
