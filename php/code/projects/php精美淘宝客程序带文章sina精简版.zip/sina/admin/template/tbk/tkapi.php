<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	function check_form(obj){
		if(obj.tkname.value=='')
		{
			alert('淘宝昵称不能为空！');
			obj.tkname.focus();
			return false;
		}
		if(obj.tkpid.value=='')
		{
			alert('淘宝PID不能为空！');
			obj.tkpid.focus();
			return false;
		}
		if(obj.tkkey.value=='')
		{
			alert('淘宝APP Key不能为空！');
			obj.tkkey.focus();
			return false;
		}
		if(obj.tksecret.value=='')
		{
			alert('淘宝App Secret不能为空！');
			obj.tksecret.focus();
			return false;
		}
		if(obj.tksize.value=='')
		{
			alert('每页显示商品数不可为空！');
			obj.tksize.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>淘客设置</h6>
	<div class="content">
    <form name="add" action="__URL__/tkapi" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.add);" >
    <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="15%">淘宝昵称：</td>
        <td><input name="tkname" type="text" style="width:245px;" value="{$read['tkname']}" /></td>
      </tr>
      <tr>
        <td width="15%">淘宝P I D：</td>
        <td><input name="tkpid" type="text" style="width:245px;" value="{$read['tkpid']}" /></td>
      </tr>
      <tr>
        <td>淘宝APP Key：</td>
        <td><input name="tkkey" type="text" style="width:245px;" value="{$read['tkkey']}" /> 注：多个APP Key请用,隔开！</td>
      </tr>
      <tr>
        <td>淘宝App Secret：</td>
        <td><input name="tksecret" type="text" style="width:245px;" value="{$read['tksecret']}" /> 注：多个App Secret请用,隔开！且与APP Key 一一对应！</td>
      </tr>
      <tr>
        <td>淘客列表显示商品数：</td>
        <td><input name="tksize" type="text" style="width:245px;" value="{$read['tksize']}" />  注：每页最多显示40个。</td>
      </tr>
      <tr>
        <td>淘客热门搜索关键词：</td>
        <td><input name="tksearch" type="text" style="width:245px;" value="{$read['tksearch']}" />  注：多个关键词用半角,隔开！</td>
      </tr>
      <tr>
        <td>卖家起始等级：</td>
        <td>
<select name="tklevel">
<option value="1heart" <?php if($read['tklevel']=="1heart"){ ?> selected="selected" <?php } ?>>(一心)</option>      
<option value="2heart" <?php if($read['tklevel']=="2heart"){ ?> selected="selected" <?php } ?>>(两心)</option>      
<option value="3heart" <?php if($read['tklevel']=="3heart"){ ?> selected="selected" <?php } ?>>(三心)</option>      
<option value="4heart" <?php if($read['tklevel']=="4heart"){ ?> selected="selected" <?php } ?>>(四心)</option>      
<option value="5heart" <?php if($read['tklevel']=="5heart"){ ?> selected="selected" <?php } ?>>(五心)</option>                              
<option value="1diamond" <?php if($read['tklevel']=="1diamond"){ ?> selected="selected" <?php } ?>>(一钻)</option>      
<option value="2diamond" <?php if($read['tklevel']=="2diamond"){ ?> selected="selected" <?php } ?>>(两钻)</option>      
<option value="3diamond" <?php if($read['tklevel']=="3diamond"){ ?> selected="selected" <?php } ?>>(三钻)</option>      
<option value="4diamond" <?php if($read['tklevel']=="4diamond"){ ?> selected="selected" <?php } ?>>(四钻)</option>      
<option value="5diamond" <?php if($read['tklevel']=="5diamond"){ ?> selected="selected" <?php } ?>>(五钻)</option>                              
<option value="1crown" <?php if($read['tklevel']=="1crown"){ ?> selected="selected" <?php } ?>>(一冠)</option>      
<option value="2crown" <?php if($read['tklevel']=="2crown"){ ?> selected="selected" <?php } ?>>(两冠)</option>      
<option value="3crown" <?php if($read['tklevel']=="3crown"){ ?> selected="selected" <?php } ?>>(三冠)</option>   
<option value="4crown" <?php if($read['tklevel']=="4crown"){ ?> selected="selected" <?php } ?>>(四冠)</option>            
<option value="5crown" <?php if($read['tklevel']=="5crown"){ ?> selected="selected" <?php } ?>>(五冠)</option>      
<option value="1goldencrown" <?php if($read['tklevel']=="1goldencrown"){ ?> selected="selected" <?php } ?>>(一黄冠)</option>                              
<option value="2goldencrown" <?php if($read['tklevel']=="2goldencrown"){ ?> selected="selected" <?php } ?>>(二黄冠)</option>      
<option value="3goldencrown" <?php if($read['tklevel']=="3goldencrown"){ ?> selected="selected" <?php } ?>>(三黄冠)</option>      
<option value="4goldencrown" <?php if($read['tklevel']=="4goldencrown"){ ?> selected="selected" <?php } ?>>(四黄冠)</option>      
<option value="5goldencrown" <?php if($read['tklevel']=="5goldencrown"){ ?> selected="selected" <?php } ?>>(五黄冠)</option>      
</select>
        </td>
      </tr>
      <tr>
        <td>商品排序方式：</td>
        <td>
<select name="tkorder">
<option value="price_desc" <?php if($read['tkorder']=="price_desc"){ ?> selected="selected" <?php } ?>>(价格从高到低)</option>      
<option value="price_asc" <?php if($read['tkorder']=="price_asc"){ ?> selected="selected" <?php } ?>>(价格从低到高)</option>
<option value="credit_desc" <?php if($read['tkorder']=="credit_desc"){ ?> selected="selected" <?php } ?>>(信用等级从高到低)</option>
<option value="commissionRate_desc" <?php if($read['tkorder']=="commissionRate_desc"){ ?> selected="selected" <?php } ?>>(佣金比率从高到底</option>
<option value="commissionRate_asc" <?php if($read['tkorder']=="commissionRate_asc"){ ?> selected="selected" <?php } ?>>(佣金比率从低到高)</option>
<option value="commissionNum_desc" <?php if($read['tkorder']=="commissionNum_desc"){ ?> selected="selected" <?php } ?>>(成交量成高到低) </option>
<option value="commissionNum_asc" <?php if($read['tkorder']=="commissionNum_asc"){ ?> selected="selected" <?php } ?>>(成交量从低到高</option>
<option value="commissionVolume_desc" <?php if($read['tkorder']=="commissionVolume_desc"){ ?> selected="selected" <?php } ?>>(总支出佣金从高到底)</option>
<option value="commissionVolume_asc" <?php if($read['tkorder']=="commissionVolume_asc"){ ?> selected="selected" <?php } ?>>(总支出佣金从低到高)</option>
<option value="delistTime_desc" <?php if($read['tkorder']=="delistTime_desc"){ ?> selected="selected" <?php } ?>>(商品下架时间从高到底)</option>
<option value="delistTime_asc" <?php if($read['tkorder']=="delistTime_asc"){ ?> selected="selected" <?php } ?>>(商品下架时间从低到高)</option>
</select>
          </td>
      </tr>
      <tr>
        <td>推广商品类目：</td>
        <td>
        	<select name="tkcat" style="width:245px; ">
            <option value="0" <?php if($read['tkcat']==0){?> selected="selected" <?php } ?> >所有分类</option>
            <?php if(!empty($tcategory)){
			foreach($tcategory as $val)
			{?>
				<option value="{$val['cid']}" <?php if($val['cid']==$read['tkcat']){?> selected="selected" <?php } ?> >&nbsp;{$val['name']}</option>
			<?php
            }	
			} ?>
            </select>
        </td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 保 存 设 置 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>
