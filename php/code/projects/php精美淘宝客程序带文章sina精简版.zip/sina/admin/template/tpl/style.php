<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 风格设置</h6>
	<div class="content">
    <form action="$__URL__/set_up" method="post" enctype="multipart/form-data" >
    <ul id="style">
    <?php if($style){foreach($style as $val){ ?>
    <li <?php if($now_style==$val['FileName']){ ?> style="background:#6F9;" <?php } ?>>
    <a href="__URL__/save_config-{$val['FileName']}"><img src="{$Lqcms}{$val['pic']}" alt="{$val['summary']}" /></a><br />
    名称：{$val['SiteName']}<br />
    标识：{$val['FileName']}<br />
    作者：{$val['SiteMaster']}<br />
    日期：{$val['PubDate']}<br />
    <div><a href="__URL__/del_dir_file-{$val['FileName']}">[删除]</a><a href="__URL__/save_config-{$val['FileName']}">[使用]</a></div>
    </li>
     <?php }} ?>
    </ul>
    </form>
	</div>
</div>
</div>
</body>
</html>
