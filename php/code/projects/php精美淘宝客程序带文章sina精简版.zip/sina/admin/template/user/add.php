<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<link href="{$Lqcms}/ueditor/themes/default/ueditor.css"/ rel="stylesheet" type="text/css" />
<script type="text/javascript">
	function check_form(obj){
		if(obj.name.value=='')
		{
			alert('帐号不能为空！');
			obj.name.focus();
			return false;
		}
		if(obj.pwd.value=='')
		{
			alert('密码不能为空！');
			obj.pwd.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 添加用户</h6>
	<div class="content">
    <form name="add" action="__URL__/add" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.add);" >
    <div class="bk20 hr"><hr /></div>
    <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%">帐&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;号：</td>
        <td><input name="name" type="text" style="width:120px;" /></td>
      </tr>
      <tr>
        <td>密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码：</td>
        <td><input name="pwd" type="password" style="width:120px;" /></td>
      </tr>
      <tr>
        <td>用 户&nbsp; 组：</td>
        <td>
        	<select name="group_id" style="width:80px;">
            <?php if(!empty($list)){ foreach($list as $val){?>
            <option value="{$val['id']}">{$val['name']}</option>
            <?php }}?>
        	</select>
        </td>
      </tr>
      <tr>
        <td>状&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;态：</td>
        <td>
     		<select name="is_lock" style="width:80px;">
            <option value="1">正常</option>
            <option value="0">禁用</option>
        	</select>
        </td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 提 交 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>