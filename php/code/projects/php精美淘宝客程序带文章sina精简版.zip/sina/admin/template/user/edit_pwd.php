<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="__PUBLIC__/css/reset.css" rel="stylesheet" type="text/css" />
<link href="__PUBLIC__/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function check_form(obj){
		if(obj.newpwd.value=='')
		{
			alert('密码不可为空！');
			obj.newpwd.focus();
			return false;
		}
		if(obj.newpwd.value!=obj.newpwd2.value)
		{
			alert('两次输入的密码不一致请重新输入！');
			obj.newpwd.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body>
<div id="main_frameid" class="pad-10 display" style="_margin-right:-12px;_width:98.9%;">
<div class="col-2 lf mr10 col">
	<h6>├ 密码设置</h6>
	<div class="content">
    <form name="editpwd" action="__URL__/edit_pwd" method="post" enctype="multipart/form-data" onSubmit="return check_form(document.editpwd);" >
    <table id="ope" width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%">当前用户：</td>
        <td>{$info['name']}</td>
      </tr>
      <tr>
        <td width="10%">原&nbsp;密&nbsp;&nbsp;码：</td>
        <td><input name="oldpwd" type="password"  /></td>
      </tr>
      <tr>
        <td>新&nbsp;密&nbsp;&nbsp;码：</td>
        <td><input name="newpwd" type="password"  /></td>
      </tr>
      <tr>
        <td>重复密码：</td>
        <td><input name="newpwd2" type="password"  /></td>
      </tr>
      <tr>
        <td><input name="do" type="hidden" value="yes" /></td>
        <td><input class="submit" name="submit" type="submit" value=" 保 存 设 置 " /></td>
      </tr>
    </table>
    </form>
	</div>
</div>
</div>
</body>
</html>