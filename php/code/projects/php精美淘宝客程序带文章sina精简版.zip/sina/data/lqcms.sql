DROP TABLE IF EXISTS `lq_article`;
CREATE TABLE `lq_article` (
  `id` int(12) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `recmt` tinyint(1) NOT NULL,
  `views` int(9) NOT NULL,
  `add_time` int(10) NOT NULL,
  `cat_id` int(3) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `user_id` int(9) NOT NULL,
  `show_order` int(5) NOT NULL,
  `pic` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=6;

DROP TABLE IF EXISTS `lq_category`;
CREATE TABLE `lq_category` (
  `id` int(5) NOT NULL auto_increment,
  `pid` int(5) NOT NULL,
  `module` int(3) NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `show_order` int(5) NOT NULL,
  `template` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=7;

DROP TABLE IF EXISTS `lq_comment`;
CREATE TABLE `lq_comment` (
  `id` int(12) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `siteurl` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `tid` int(12) NOT NULL,
  `pid` int(4) NOT NULL,
  `add_time` int(10) NOT NULL,
  `top_type` int(2) NOT NULL,
  `is_validated` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

DROP TABLE IF EXISTS `lq_focus`;
CREATE TABLE `lq_focus` (
  `id` int(3) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `url` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `show_order` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

DROP TABLE IF EXISTS `lq_friend`;
CREATE TABLE `lq_friend` (
  `id` int(5) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `show_order` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=3;

DROP TABLE IF EXISTS `lq_group`;
CREATE TABLE `lq_group` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `power_value` varchar(1000) NOT NULL,
  PRIMARY KEY  (`id`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=4;

DROP TABLE IF EXISTS `lq_nav`;
CREATE TABLE `lq_nav` (
  `id` int(3) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `url` varchar(100) NOT NULL,
  `pid` int(3) NOT NULL,
  `show_order` int(3) NOT NULL,
  PRIMARY KEY  (`id`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=10;

DROP TABLE IF EXISTS `lq_page`;
CREATE TABLE `lq_page` (
  `id` int(12) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `recmt` tinyint(1) NOT NULL,
  `views` int(9) NOT NULL,
  `add_time` int(10) NOT NULL,
  `pid` int(12) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `user_id` int(9) NOT NULL,
  `show_order` int(5) NOT NULL,
  `pic` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

DROP TABLE IF EXISTS `lq_resource`;
CREATE TABLE `lq_resource` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `pid` int(10) unsigned NOT NULL,
  `operate` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=109;


DROP TABLE IF EXISTS `lq_site`;
CREATE TABLE `lq_site` (
  `id` int(2) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `icpcode` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `qq` varchar(50) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `fax` varchar(50) NOT NULL,
  `statistical` text NOT NULL,
  `siteurl` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=2;

DROP TABLE IF EXISTS `lq_spider`;
CREATE TABLE `lq_spider` (
  `id` int(2) unsigned NOT NULL auto_increment,
  `name` varchar(50)  NOT NULL,
  `url` varchar(100) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

DROP TABLE IF EXISTS `lq_tbk`;
CREATE TABLE `lq_tbk` (
  `tkid` int(1) unsigned NOT NULL auto_increment,
  `tkpid` varchar(50) NOT NULL,
  `tkname` varchar(100) NOT NULL,
  `tkkey` varchar(100) NOT NULL,
  `tksecret` varchar(255) NOT NULL,
  `tktime` int(10) unsigned NOT NULL,
  `tkcache` varchar(50) NOT NULL,
  `tkcat` int(5) unsigned NOT NULL,
  `tkorder` varchar(30) NOT NULL,
  `tklevel` varchar(20) NOT NULL,
  `tksize` int(2) unsigned NOT NULL,
  `tksearch` varchar(255) NOT NULL,
  PRIMARY KEY  (`tkid`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=2;

DROP TABLE IF EXISTS `lq_user`;
CREATE TABLE `lq_user` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(60) NOT NULL,
  `nickname` varchar(60) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `is_lock` int(1) NOT NULL,
  `group_id` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=3;

INSERT INTO `lq_article` VALUES (1, '偶尔穿穿有品位有档次的衣服,更值得女性青睐和欣赏', '', '', '很多平凡地女孩从小到大都做着灰姑娘的梦，期望有一天自己的白马王子能够来到面前，将自己带到王宫，从此过着幸福的生活。但梦终究是梦，不过对于男士而言，王子般的打扮还是能够赢得女孩子好感的。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n所以成熟有品位的男士会更值得女性青睐和欣赏。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n你是潮流型男呢，还是有品位的绅士？小编相信您一定有属于自己的穿衣选择和风格，但试想，如果你是潮流男，偶尔穿穿有品位有档次的衣服，会彰显你成熟稳重的一面；如果你是一位绅士，偶尔穿穿比较时尚前卫的衣服，是不是也可以更阳光呢？当然，无论你喜欢哪种风格，都可以到淘宝网购物男装哦！&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n浪漫型男士服装搭配追求的是明亮鲜艳的色彩搭配，因此彩色就是他们的最爱。他们以展现个性、施展魅力为目的，将丝巾取代领带，所以给人一种柔和清晰的感觉。因此“浪漫王子”型潮男服装搭配最受女孩子青睐。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n除了帅气以外，女孩子也比较喜欢有品位的男士。每位男士都应该是一位极其讲究的绅士，走近他们身边能感觉到一种高贵。他们总能给人一种中规中矩的感觉，能把最简单的衣物穿出高级感来。淘宝网购物&lt;a href=&quot;http://www.ibtf.net/&quot; target=&quot;_blank&quot;&gt;&lt;strong&gt;大码&lt;/strong&gt;&lt;span&gt;&lt;strong&gt;女装&lt;/strong&gt;&lt;/span&gt;&lt;/a&gt;。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n品位男人在穿衣方面一贯讲究舒适、大气，选料一定要上乘，工艺一定要精湛。服装搭配在稳重、不张扬中展示精明能干和高贵的气质。&lt;br /&gt;', 0, 869, 1341824511, 1, 'lqcms', 1, 255, '');
INSERT INTO `lq_article` VALUES (2, '淘宝网女装夏装时尚新品,搭配裤装或裙装都会很好看的小衬衫', '', '', '1、2012夏装 新款女装 韩版印花小碎花性感短袖雪纺衫&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;p style=&quot;text-align:center;&quot;&gt;\r\n	&lt;img src=&quot;/upload/image/20120709/09015546.jpg&quot; alt=&quot;&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;br /&gt;\r\n非常可爱灵动的碎花雪纺面料，简单却又独具匠心的小上衣，轻盈的大荷叶边围绕着领子和肩部。大荷叶边还用了高温压摺的工艺效果。无疑让最性感的部分最低调展现出来，颜色清新淡雅，面料柔软细滑，就如夏日清晨的一缕清风，给你的炎炎夏日带来一丝丝凉爽。这也是一款非常好搭配的小上衣，搭配蓬蓬裙变得更加温柔可爱；搭配蕾丝短裤变得轻松乖巧；搭配牛仔热裤更是可爱中带着性感和热。绝对是值得入手的夏日必备。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n2、2012夏装 &lt;strong&gt;&lt;a href=&quot;http://www.ibtf.net/&quot; target=&quot;_blank&quot;&gt;新款女装&lt;/a&gt;&lt;/strong&gt; 韩版钉珠翻领喇叭袖雪纺衬衫&lt;br /&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p style=&quot;text-align:center;&quot;&gt;\r\n	&lt;img src=&quot;/upload/image/20120709/09015608.jpg&quot; alt=&quot;&quot; /&gt;\r\n&lt;/p&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n很多MM都会比较 喜欢这款衬衫的设计。很宽松的款式加上简单的设计。颜色不是特别的跳跃，但又不失自己独有的味道。 垫肩的设计，小女人中带着点霸气。小翻领，可以适合上班穿着，比较正式。同时也是约会的好单品。垫 肩上的珍珠装饰全都是工人手工定制上去的，所以亲可以放心。。。&lt;br /&gt;\r\n&lt;div&gt;\r\n	&lt;br /&gt;\r\n&lt;/div&gt;', 0, 897, 1341799063, 7, 'lqcms', 1, 255, '');
INSERT INTO `lq_article` VALUES (3, '春、夏、秋、冬四季时尚、淑女、休闲女装2012秋装新品首发', '', '', '迪薇娜品牌折扣女装2012秋装新品首发上市衣食住行，衣在基层;四季更替，潮流变迁，生活所需，时尚促就;任其更换淘汰，唯市场不变。项目来自市场，看街头巷尾，摩登女郎无数，淡妆浓抹，衣衫鞋履，尽源市场。&lt;br /&gt;\r\n　　&lt;br /&gt;\r\n品牌优势：&lt;br /&gt;\r\n&lt;br /&gt;\r\n汇集了国内八大派系,风格迥异、新品不断、流行时尚、价格低廉 产品涵盖春夏秋冬四季服装，我们可配货，也可供自由选货;准确定位在22—48 岁女性消费人群，以其唯一性、独特性、不可类比性为消费者所喜爱。 我们现向全国诚招代理商、加盟商，只要您有适合的店面我们都将提供“物美价廉”的货品，让您挖掘全新的商机!&lt;br /&gt;\r\n　　&lt;br /&gt;\r\n因此，女人是潮流市场的强势消费群体，要创业，当选&lt;a href=&quot;http://www.ibtf.net/&quot; target=&quot;_blank&quot;&gt;&lt;span&gt;&lt;strong&gt;品牌&lt;/strong&gt;&lt;/span&gt;&lt;strong&gt;女装&lt;/strong&gt;&lt;/a&gt;。 迪薇娜品牌折扣女装，全部为品牌服装，品质高档，超低劲爆价格，是消费者的购衣天堂!&lt;br /&gt;\r\n&lt;br /&gt;\r\n迪薇娜品牌折扣女装，产品涵盖春、夏、秋、冬四季时尚、淑女、休闲女装，每季近1000款货品与原品牌几乎同步上市;与原品牌相比，物美价廉、超低价格，具有强大的竞争优势。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;', 0, 928, 1341798359, 8, 'lqcms', 1, 255, '');
INSERT INTO `lq_article` VALUES (4, '一探“大码女装店”火爆的究竟。', '', '', '在苏州有新开了家“大码女装店”，没有想到针对丰满女性的店铺生意还不错。新奇的“大码”字眼引来众多好奇的目光，服装店生意煞是火爆。昨天我们一起来到了凤凰街这家服装店，一探“大码女装店”的究竟。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n据悉，大码女装店十年前就在北京出现过，但在苏州很少听到。问起开店原由，店主任佩瑛说，四五十岁以上的妇女十个有四五是偏胖的，但一般商场的服装很少有三尺以上的衣服，买衣难成了偏胖一族的麻烦事。今年的北京国际服装博览会上，北京一大码女装公司的发布让她豁然开朗。经过半年前期准备，多年经营高档男士服装的她开起了苏州首家大码女装店。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n60平方米的店堂分成两小间，以暗色的风衣、毛料大衣为主。&lt;strong&gt;&lt;a href=&quot;http://www.ibtf.net/&quot; target=&quot;_blank&quot;&gt;大码女装&lt;/a&gt;&lt;/strong&gt;店店堂内挤着七八对顾客，大多是身型较大的阿姨。一位阿姨询问可有胸围三尺二的衣服，店员招呼说：“当然有，胸围三尺二三的衣服在这不算大的。胸围三尺七的衣服都有”。随手翻看衣服的标签，发现一米六五身高的衣服从相当于l号的88逐级递增到112，也就相当于xxxxxxl号的女装。记者咋舌惊叹时，店员笑称：“再多几个x的都可以买到，店内买不到还可以预定。”询问一位身材娇小的董小姐，她说刚好乘公交车经过，看到“大码”二字就赶快下车进店里瞧瞧：“老妈四尺胸围很难买衣服，这里还有得挑挑，明天就拉她过来买过年的衣服。”&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n新店营业还不到两周，人气却不断攀升，工作日一晚上也总有五六十名顾客进进出出，加入大码店会员的顾客已达到三四十人。平时买衣尴尬的胖女士们，在这里多出了几分归属感，甚至热心地建议起店主进些大码鞋，或者再开个大码男装店。任佩瑛笑称，男士大码店消费群体少很多，所以不太可行，但多代理些大码女装品牌，进些大码鞋都是不错的建议。她已经考虑多开几家大码女装店，在苏州打造一个大码女装的连锁品牌。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;', 0, 264, 1341824681, 6, 'lqcms', 1, 255, '');
INSERT INTO `lq_article` VALUES (5, '淘宝网女装New女装最畅销的流行款式女装', '', '', '随着人们生活的水平的不断提高，我们每一个人的审美标准也在不断地爬升。品牌生活已经走进了千家万户，深入每一个生命的心灵里面。近日，现在，向大家郑重推荐一个淘宝网女装选购必去的地方：New女装&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n目前的实际情况是，不论男人还是女人，还是小小孩，在选择自己的衣服的时候，那眼光肯定是不断地体提高标准啊。这个相不中，颜色不好，那个相不中，款式不好，这个还可以，质量挺好的，那个不太好，穿起来不很舒服。。。。。等等的原因，也许在选购衣服的时候，需要关顾很多的商店，需要走很多的路才能够选择到自己喜欢的服装，选择到自己喜爱的东东，这就是购物的需要付出的一个小小的负面的代价。当然了，现在你可以选择，直接到&lt;span&gt;New&lt;/span&gt;女装这个淘宝网&lt;strong&gt;&lt;a href=&quot;http://www.ibtf.net/&quot; target=&quot;_blank&quot;&gt;新款女装&lt;/a&gt;&lt;/strong&gt;专卖店去选购。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n淘宝网女装&lt;span&gt;New&lt;/span&gt;女装首页都是最畅销的流行款式女装，可以解决我们消费时间的效率低的问题，我们可以完全省去逛街的人力、物力的消耗，直接通过互联网逛淘宝网女装，仅仅简单的轻轻的点击一下我们手中的鼠标，浏览逛街的目的就已经达到，我们完全可以在炎热的夏天，不用出门就可以购买到淘宝网女装夏装，流行款式中彻底的全面的浏览全世界流行女装，选购到自己喜欢的淘宝网女装，并可以查看各种各样的流行女装相关新闻。&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n这简直就是一个美美的好事情啦，有什么犹豫呢？快快行动吧！淘宝网女装流行款式选购网http://www.ibtf.net/等待您的光临！&amp;nbsp;&lt;br /&gt;', 0, 844, 1341825059, 5, 'lqcms', 1, 255, '');

INSERT INTO `lq_category` VALUES (1, 0, 1, '品牌女装', '', '', 255, 'artinfo.php');
INSERT INTO `lq_category` VALUES (2, 0, 1, '女装搭配', '', '', 222, 'artinfo.php');
INSERT INTO `lq_category` VALUES (3, 0, 1, '大码女装', '', '', 255, 'artinfo.php');
INSERT INTO `lq_category` VALUES (4, 0, 1, '流行女装', '', '', 255, 'artinfo.php');
INSERT INTO `lq_category` VALUES (5, 0, 1, '夏季女装', '', '', 255, 'artinfo.php');
INSERT INTO `lq_category` VALUES (6, 0, 1, '女装秋装', '', '', 255, 'artinfo.php');

INSERT INTO `lq_friend` VALUES (1, '爱美丽', 'http://www.ibtf.net/', 1, '', 255);
INSERT INTO `lq_friend` VALUES (2, '比特福精品汇', 'http://www.bitefu.net/', 2, '', 255);

INSERT INTO `lq_group` VALUES (1, '创始人', '-1');
INSERT INTO `lq_group` VALUES (2, '管理员', '');
INSERT INTO `lq_group` VALUES (3, '编辑员', '');

INSERT INTO `lq_nav` VALUES (1, '连衣裙', 'http://www.ibtf.net/index.php/lqtk/tlist-50010850.html', 0, 321);
INSERT INTO `lq_nav` VALUES (2, 'T恤', 'http://www.ibtf.net/index.php/lqtk/tlist-50000671.html', 0, 255);
INSERT INTO `lq_nav` VALUES (3, '衬衫', 'http://www.ibtf.net/index.php/lqtk/tlist-162104.html', 0, 255);
INSERT INTO `lq_nav` VALUES (4, '裤子', 'http://www.ibtf.net/index.php/lqtk/tlist-1622.html', 0, 255);
INSERT INTO `lq_nav` VALUES (5, '半身裙', 'http://www.ibtf.net/index.php/lqtk/tlist-1623.html', 0, 255);
INSERT INTO `lq_nav` VALUES (6, '短外套', 'http://www.ibtf.net/index.php/lqtk/tlist-50011277.html', 0, 255);
INSERT INTO `lq_nav` VALUES (7, '大码女装', 'http://www.ibtf.net/index.php/lqtk/tlist-1629.html', 0, 255);
INSERT INTO `lq_nav` VALUES (8, '职业套装', 'http://www.ibtf.net/index.php/lqtk/tlist-1624.html', 0, 255);
INSERT INTO `lq_nav` VALUES (9, '婚纱旗袍', 'http://www.ibtf.net/index.php/lqtk/tlist-50011404.html', 0, 255);

INSERT INTO `lq_resource` VALUES (1, 0, 'index', '');
INSERT INTO `lq_resource` VALUES (2, 1, 'index', '');
INSERT INTO `lq_resource` VALUES (3, 1, 'login', '');
INSERT INTO `lq_resource` VALUES (4, 1, '_login', '');
INSERT INTO `lq_resource` VALUES (5, 1, 'verify', '');
INSERT INTO `lq_resource` VALUES (6, 1, 'welcome', '');
INSERT INTO `lq_resource` VALUES (7, 1, 'login_out', '');
INSERT INTO `lq_resource` VALUES (8, 0, 'category', '');
INSERT INTO `lq_resource` VALUES (9, 8, 'get_list', '');
INSERT INTO `lq_resource` VALUES (10, 8, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (11, 8, 'add', '');
INSERT INTO `lq_resource` VALUES (12, 8, 'edit', '');
INSERT INTO `lq_resource` VALUES (13, 8, 'info', '');
INSERT INTO `lq_resource` VALUES (14, 8, 'del', '');
INSERT INTO `lq_resource` VALUES (15, 8, 'all_del', '');
INSERT INTO `lq_resource` VALUES (16, 8, 'set_sort', '');
INSERT INTO `lq_resource` VALUES (17, 8, 'getCat', '');
INSERT INTO `lq_resource` VALUES (18, 0, 'article', '');
INSERT INTO `lq_resource` VALUES (19, 18, 'get_list', '');
INSERT INTO `lq_resource` VALUES (20, 18, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (21, 18, 'add', '');
INSERT INTO `lq_resource` VALUES (22, 18, 'edit', '');
INSERT INTO `lq_resource` VALUES (23, 18, 'info', '');
INSERT INTO `lq_resource` VALUES (24, 18, 'del', '');
INSERT INTO `lq_resource` VALUES (25, 18, 'all_del', '');
INSERT INTO `lq_resource` VALUES (26, 18, 'set_sort', '');
INSERT INTO `lq_resource` VALUES (27, 0, 'page', '');
INSERT INTO `lq_resource` VALUES (28, 27, 'get_list', '');
INSERT INTO `lq_resource` VALUES (29, 27, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (30, 27, 'add', '');
INSERT INTO `lq_resource` VALUES (31, 27, 'edit', '');
INSERT INTO `lq_resource` VALUES (32, 27, 'info', '');
INSERT INTO `lq_resource` VALUES (33, 27, 'del', '');
INSERT INTO `lq_resource` VALUES (34, 27, 'all_del', '');
INSERT INTO `lq_resource` VALUES (35, 27, 'set_sort', '');
INSERT INTO `lq_resource` VALUES (36, 27, 'getCat', '');
INSERT INTO `lq_resource` VALUES (37, 0, 'comment', '');
INSERT INTO `lq_resource` VALUES (38, 37, 'get_list', '');
INSERT INTO `lq_resource` VALUES (39, 37, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (40, 37, 'validated', '');
INSERT INTO `lq_resource` VALUES (41, 37, 'info', '');
INSERT INTO `lq_resource` VALUES (42, 37, 'del', '');
INSERT INTO `lq_resource` VALUES (43, 37, 'all_del', '');
INSERT INTO `lq_resource` VALUES (44, 37, 'all_validated', '');
INSERT INTO `lq_resource` VALUES (45, 0, 'focus', '');
INSERT INTO `lq_resource` VALUES (46, 45, 'get_list', '');
INSERT INTO `lq_resource` VALUES (47, 45, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (48, 45, 'add', '');
INSERT INTO `lq_resource` VALUES (49, 45, 'edit', '');
INSERT INTO `lq_resource` VALUES (50, 45, 'info', '');
INSERT INTO `lq_resource` VALUES (51, 45, 'del', '');
INSERT INTO `lq_resource` VALUES (52, 45, 'all_del', '');
INSERT INTO `lq_resource` VALUES (53, 45, 'set_sort', '');
INSERT INTO `lq_resource` VALUES (54, 0, 'friend', '');
INSERT INTO `lq_resource` VALUES (55, 54, 'get_list', '');
INSERT INTO `lq_resource` VALUES (56, 54, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (57, 54, 'add', '');
INSERT INTO `lq_resource` VALUES (58, 54, 'edit', '');
INSERT INTO `lq_resource` VALUES (59, 54, 'info', '');
INSERT INTO `lq_resource` VALUES (60, 54, 'del', '');
INSERT INTO `lq_resource` VALUES (61, 54, 'all_del', '');
INSERT INTO `lq_resource` VALUES (62, 54, 'set_sort', '');
INSERT INTO `lq_resource` VALUES (63, 0, 'nav', '');
INSERT INTO `lq_resource` VALUES (64, 63, 'get_list', '');
INSERT INTO `lq_resource` VALUES (65, 63, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (66, 63, 'add', '');
INSERT INTO `lq_resource` VALUES (67, 63, 'edit', '');
INSERT INTO `lq_resource` VALUES (68, 63, 'info', '');
INSERT INTO `lq_resource` VALUES (69, 63, 'del', '');
INSERT INTO `lq_resource` VALUES (70, 63, 'all_del', '');
INSERT INTO `lq_resource` VALUES (71, 63, 'set_sort', '');
INSERT INTO `lq_resource` VALUES (72, 63, 'getCat', '');
INSERT INTO `lq_resource` VALUES (73, 0, 'spider', '');
INSERT INTO `lq_resource` VALUES (74, 73, 'get_list', '');
INSERT INTO `lq_resource` VALUES (75, 73, 'spider_list', '');
INSERT INTO `lq_resource` VALUES (76, 73, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (77, 73, 'info', '');
INSERT INTO `lq_resource` VALUES (78, 73, 'del', '');
INSERT INTO `lq_resource` VALUES (79, 73, 'all_del', '');
INSERT INTO `lq_resource` VALUES (80, 0, 'user', '');
INSERT INTO `lq_resource` VALUES (81, 80, 'get_list', '');
INSERT INTO `lq_resource` VALUES (82, 80, 'condition_list', '');
INSERT INTO `lq_resource` VALUES (83, 80, 'add', '');
INSERT INTO `lq_resource` VALUES (84, 80, 'edit', '');
INSERT INTO `lq_resource` VALUES (85, 80, 'edit_pwd', '');
INSERT INTO `lq_resource` VALUES (86, 80, 'update', '');
INSERT INTO `lq_resource` VALUES (87, 80, 'info', '');
INSERT INTO `lq_resource` VALUES (88, 80, 'del', '');
INSERT INTO `lq_resource` VALUES (89, 80, 'all_del', '');
INSERT INTO `lq_resource` VALUES (90, 80, 'detail', '');
INSERT INTO `lq_resource` VALUES (91, 0, 'site', '');
INSERT INTO `lq_resource` VALUES (92, 91, 'set_up', '');
INSERT INTO `lq_resource` VALUES (93, 91, 'save_config', '');
INSERT INTO `lq_resource` VALUES (94, 91, 'set_config', '');
INSERT INTO `lq_resource` VALUES (95, 91, 'testing', '');
INSERT INTO `lq_resource` VALUES (96, 0, 'tpl', '');
INSERT INTO `lq_resource` VALUES (97, 96, 'read_style', '');
INSERT INTO `lq_resource` VALUES (98, 96, 'del_dir_file', '');
INSERT INTO `lq_resource` VALUES (99, 96, 'delDirAndFile', '');
INSERT INTO `lq_resource` VALUES (100, 96, 'save_config', '');
INSERT INTO `lq_resource` VALUES (101, 96, 'set_config', '');
INSERT INTO `lq_resource` VALUES (102, 0, 'dbback', '');
INSERT INTO `lq_resource` VALUES (103, 102, 'get_table', '');
INSERT INTO `lq_resource` VALUES (104, 102, 'backup', '');
INSERT INTO `lq_resource` VALUES (105, 102, 'getFileName', '');
INSERT INTO `lq_resource` VALUES (106, 102, 'recovery', '');
INSERT INTO `lq_resource` VALUES (107, 102, 'recovery_file', '');
INSERT INTO `lq_resource` VALUES (108, 102, 'alldel', '');

INSERT INTO `lq_site` VALUES (1, '淘宝网女装', '淘宝商城秋装、夏装新款女装货到付款！ - 淘宝网女装', '女士内衣,品牌文胸,新款女装,大码女装', '淘宝网女装春夏秋冬四季新款，淘宝网商城正品连衣裙、T恤、衬衫、牛仔裤、文胸套装，支持七天无理由退换货、货到付款！花最少的钱买最好的货！', '756663992@qq.com', '苏ICP备10073547号-1', '', '80425721,394306748', '', '', '', 'http://www.ibtf.net/');

INSERT INTO `lq_tbk` VALUES (1, 'mm_16329643_0_0', 'ganggang4321', '12594307', 'c3b09f568f1846ad18c944dcf7be2fb4', 10, '', 16, 'commissionNum_desc', '1heart', 39, 'lv女包,新款女装,性感内衣,品牌女装,大码女装,韩版女装');

INSERT INTO `lq_user` VALUES (1, 'admin', 'lqcms', 'd9ec0e19382c5865b2020e483daf3819', 1, 1);
