<?php
/*
功能:淘宝API。
作者：琅之舞乛 QQ:80425721;
创建时间：2012-6-20;	
*/

class Tbk
{	
	private $testMode 		= 'false';
	private $field			= array();
	private $parent_cid 	= '0';	   
	private $start_price	= '0.01';
	private $end_price		= '99999999';
	private $auto_send 		= '';
	private $area 			= '';
	private $end_credit		= '5goldencrown';	  
	private $guarantee 		= '';
	private $start_commissionRate	= '150';
	private $end_commissionRate		= '5000';
	private $start_commissionNum	= '0';
	private $end_commissionNum		= '99999999';
	
	//接收参数
	public function __construct($field=array())
	{	
		$this->field['appKey']		= isset($field['0'])?$field['0']:'';
		$this->field['appSecret']	= isset($field['1'])?$field['1']:'';
		$this->field['userNick']	= isset($field['2'])?$field['2']:'';
		$this->field['num_iid']		= isset($field['3'])?$field['3']:'';
		$this->field['cid']			= isset($field['4'])?$field['4']:'';
		$this->field['keyword']		= isset($field['5'])?$field['5']:'';
		$this->field['sort']		= isset($field['6'])?$field['6']:'';
		$this->field['start_credit']= isset($field['7'])?$field['7']:'';
		$this->field['page_no']		= isset($field['8'])?$field['8']:'';
		$this->field['page_size']	= isset($field['9'])?$field['9']:'';
	}

	//API状态
	public function api_state()
	{
		if ($this->testMode=='true'){
			$url 		= 'http://gw.api.tbsandbox.com/router/rest?';  	//沙箱环境提交URL
			$appKey 	= 'test';  
			$appSecret 	= 'test'; 	
			$userNick 	= 'sandbox_c_2'; 								//沙箱环境可选昵称	 	
		}else if($this->testMode=='false'){
			$url 		= 'http://gw.api.taobao.com/router/rest?';  	//正式环境提交URL
			$appKey 	= $this->field['appKey']; 						//填写自己申请的AppKey
			$appSecret 	= $this->field['appSecret']; 					//填写自己申请的$appSecret
			$userNick 	= $this->field['userNick']; 					//淘宝昵称		
		}
		return $url;
	}
	
	//获取商品类目
	public function get_category()
	{
		if ($this->field['cid']=='0'){
			$this->parent_cid	= '0';
		}else{
			$this->parent_cid = $this->field['cid'];
		}
		//参数数组
		$paramArr = array(
		/* API系统级输入参数 Start */
		'method' 		=> 'taobao.itemcats.get',  	//API名称
		'timestamp' 	=> date('Y-m-d H:i:s'),			
		'format' 		=> 'xml',  					//返回格式,本demo仅支持xml
		'app_key' 		=> $this->field['appKey'],  //Appkey			
		'v' 			=> '2.0',   				//API版本号		   
		'sign_method'	=> 'md5', 					//签名方式						 
		
		/* API应用级输入参数 Start*/
		'fields' 		=> 'cid,parent_cid,name,is_parent,status,sort_order,last_modified',  	//返回字段
		'parent_cid' 	=> $this->parent_cid,  													//父商品类目id
		);
		
		$sign = createSign($paramArr,$this->field['appSecret']);		//生成签名
		$strParam = createStrParam($paramArr);							//组织参数
		$strParam .= 'sign='.$sign;
		$url = $this->api_state().$strParam;							//构造Url
		$cnt=0;															//连接超时自动重试
		while($cnt < 5 && ($result=@vita_get_url_content($url))===FALSE) $cnt++;
		$result = getXmlData($result);									//解析Xml数据
		$sub_msg = $result['sub_msg'];									//获取错误信息
		$ItemCat = $result['item_cats']['item_cat'];					//返回结果
		return $ItemCat;
	}
	
	//获取商品类目
	public function get_now_category()
	{
		//参数数组
		$paramArr = array(
		/* API系统级输入参数 Start */
		'method' 		=> 'taobao.itemcats.get',  	//API名称
		'timestamp' 	=> date('Y-m-d H:i:s'),			
		'format' 		=> 'xml',  					//返回格式,本demo仅支持xml
		'app_key' 		=> $this->field['appKey'],  //Appkey			
		'v' 			=> '2.0',   				//API版本号		   
		'sign_method'	=> 'md5', 					//签名方式						 
		
		/* API应用级输入参数 Start*/
		'fields' 		=> 'cid,parent_cid,name,is_parent,status,sort_order,last_modified',  	//返回字段
		'cids' 			=> $this->field['cid'],  													//父商品类目id
		);
		
		$sign = createSign($paramArr,$this->field['appSecret']);		//生成签名
		$strParam = createStrParam($paramArr);							//组织参数
		$strParam .= 'sign='.$sign;
		$url = $this->api_state().$strParam;							//构造Url
		$cnt=0;															//连接超时自动重试
		while($cnt < 5 && ($result=@vita_get_url_content($url))===FALSE) $cnt++;
		$result = getXmlData($result);									//解析Xml数据
		$sub_msg = $result['sub_msg'];									//获取错误信息
		$ItemCat = $result['item_cats']['item_cat'];									//返回结果
		return $ItemCat;
	}
	
	//获取商品列表
	public function get_tklist()
	{
		$paramArr = array(
		/* API系统级输入参数 Start */
		'method' 		=> 'taobao.taobaoke.items.get',					//API名称
		'timestamp' 	=> date('Y-m-d H:i:s'),			
		'format' 		=> 'xml',  										//返回格式,本demo仅支持xml
		'app_key' 		=> $this->field['appKey'],  					//Appkey			
		'v' 			=> '2.0',   									//API版本号		   
		'sign_method'	=> 'md5', 										//签名方式			
		/* API系统级参数 End */				 
		
		/* API应用级输入参数 Start*/
		'fields' 		=>  'iid,num_iid,title,nick,pic_url,price,click_url,commission,commission_rate,commission_num,commission_volume,shop_click_url,seller_credit_score,item_location',  									//返回字段
		'nick' 			=> $this->field['userNick'],  					//推广者淘宝昵称
		'keyword'		=> $this->field['keyword'],  					//查询关键字	
		'cid' 			=> $this->field['cid'],  						//商品所属分类id 		   
		'start_price' 	=> $this->start_price, 							//起始价格
		'end_price' 	=> $this->end_price, 							//最高价格
		'auto_send' 	=> $this->auto_send, 							//是否自动发货
		'area' 			=> $this->area, 								//商品所在地 例如:杭州市
		'start_credit' 	=> $this->field['start_credit'], 				//卖家起始信用
		'end_credit' 	=> $this->end_credit,  							//卖家最高信用
		'sort' 			=> $this->field['sort'], 						//排序方式
		'guarantee' 	=> $this->guarantee, 							//查询是否消保卖家
		'start_commissionRate'=>$this->start_commissionRate, 			//起始佣金比率选项
		'end_commissionRate'=> $this->end_commissionRate, 				//最高佣金比率
		'start_commissionNum'=> $this->start_commissionNum, 			//起始累计推广量选项
		'end_commissionNum' => $this->end_commissionNum, 				//最高累计推广量
		'page_no' 		=> $this->field['page_no'], 					//结果页数.1~99
		'page_size' 	=> $this->field['page_size'], 					//每页返回结果数.最大每页40 
		/* API应用级输入参数 End*/
		);
		$sign 		= createSign($paramArr,$this->field['appSecret']);					//生成签名
		$strParam 	= createStrParam($paramArr);										//组织参数
		$strParam  .= 'sign='.$sign;
		$url 		= $this->api_state().$strParam;													//构造Url
		$cnt		= 0;																//连接超时自动重试
		while($cnt < 5 && ($result=@vita_get_url_content($url))===FALSE) $cnt++;
		$result 	= getXmlData($result);												//解析Xml数据
		$sub_msg 	= $result['sub_msg'];												//获取错误信息
		$TaobaokeItem  = $result['taobaoke_items']['taobaoke_item'];					//返回结果
		$TaobaokeCount = $result['total_results'];
		$data		   = array();
		$data['item']  = $TaobaokeItem;
		$data['count'] = $TaobaokeCount;
		return $data;
	}
	
	//得到商品详细信息
	public function get_tkgoods()
	{
		$paramArr = array(
		/* API系统级输入参数 Start */
		'method' 		=> 'taobao.taobaoke.items.detail.get',   						//API名称
		'timestamp' 	=> date('Y-m-d H:i:s'),			
		'format' 		=> 'xml',  														//返回格式,本demo仅支持xml
		'app_key' 		=> $this->field['appKey'],  									//Appkey			
		'v' 			=> '2.0',   													//API版本号		   
		'sign_method'	=> 'md5', 														//签名方式				
		/* API应用级输入参数 Start*/
		'fields' 		=> 'iid,detail_url,num_iid,title,nick,type,cid,seller_cids,props,input_pids,input_str,desc,pic_url,num,valid_thru,list_time,delist_time,stuff_status,location,price,post_fee,express_fee,ems_fee,has_discount,freight_payer,has_invoice,has_warranty,has_showcase,modified,increment,auto_repost,approve,status,postage_id,product_id,auction_point,property_alias,item_imgs,prop_imgs,skus,outer_id,is_virtual,is_taobao,is_ex,videos,is_3D,score,volume,one_station,click_url,shop_click_url,seller_credit_score,approve_status', 																//返回字段
		'num_iids' 		=> $this->field['num_iid'], 									//Num_iid
		'nick' 			=> $this->field['userNick'], 									//推广者昵称
		);
		
		
		$sign 		= createSign($paramArr,$this->field['appSecret']);					//生成签名
		$strParam 	= createStrParam($paramArr);										//组织参数
		$strParam  .= 'sign='.$sign;
		$url 		= $this->api_state().$strParam;										//构造Url
		$cnt		= 0;																//连接超时自动重试
		while($cnt < 5 && ($result=@vita_get_url_content($url))===FALSE) $cnt++;
		$result 	= getXmlData($result);												//解析Xml数据
		$sub_msg 	= $result['sub_msg'];												//获取错误信息
		$taobaokeItemdetail = $result['taobaoke_item_details']['taobaoke_item_detail']['item'];
		$taobaokeItem = $result['taobaoke_item_details']['taobaoke_item_detail'];
		return $taobaokeItem;
	}
	
	//测试appkey状态
	public function akstate()
	{
		$paramArr = array(
		/* API系统级输入参数 Start */
		'method' 		=> 'taobao.taobaoke.items.detail.get',   						//API名称
		'timestamp' 	=> date('Y-m-d H:i:s'),			
		'format' 		=> 'xml',  														//返回格式,本demo仅支持xml
		'app_key' 		=> $this->field['appKey'],  									//Appkey			
		'v' 			=> '2.0',   													//API版本号		   
		'sign_method'	=> 'md5', 														//签名方式				
		/* API应用级输入参数 Start*/
		'fields' 		=> 'iid,detail_url,num_iid,title,nick,type,cid,seller_cids,props,input_pids,input_str,desc,pic_url,num,valid_thru,list_time,delist_time,stuff_status,location,price,post_fee,express_fee,ems_fee,has_discount,freight_payer,has_invoice,has_warranty,has_showcase,modified,increment,auto_repost,approve,status,postage_id,product_id,auction_point,property_alias,item_imgs,prop_imgs,skus,outer_id,is_virtual,is_taobao,is_ex,videos,is_3D,score,volume,one_station,click_url,shop_click_url,seller_credit_score,approve_status', 																//返回字段
		'num_iids' 		=> $this->field['num_iid'], 									//Num_iid
		'nick' 			=> $this->field['userNick'], 									//推广者昵称
		);
		
		
		$sign 		= createSign($paramArr,$this->field['appSecret']);					//生成签名
		$strParam 	= createStrParam($paramArr);										//组织参数
		$strParam  .= 'sign='.$sign;
		$url 		= $this->api_state().$strParam;										//构造Url
		$cnt		= 0;																//连接超时自动重试
		while($cnt < 5 && ($result=@vita_get_url_content($url))===FALSE) $cnt++;
		$result 	= getXmlData($result);												//解析Xml数据
		$sub_msg 	= $result['sub_msg'];												//获取错误信息
		return $result;
	}
}
?>