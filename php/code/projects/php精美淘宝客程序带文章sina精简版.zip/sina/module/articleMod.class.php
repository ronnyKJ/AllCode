<?php
class articleMod extends commonMod
{
	public function artlist()
	{
		$cat_id		= intval($_GET[0]);
		$url		= __URL__.'/artlist-'.$cat_id.'-page-{page}.html';
		$list_rows	= 35;
		$count		= $this->model->table('article')->where("cat_id ='$cat_id'")->order('show_order DESC')->count();
		$page		= new Page();
		$cur_page	= $page->getCurPage();
		$cat		= module('category')->info($cat_id);
		if(!$cat['id'])
		{
			$this->error("不存在此分类！");
		}
		$this->assign('curpage',	$cur_page);
		$this->assign('artcat',		$cat);
		$this->assign('page',		$page->show($url,$count,$list_rows));
		$this->assign('artlist',	$this->get_list("cat_id ='$cat_id'",'show_order',$list_rows,$cur_page));
		$this->display('artlist');
	}
	
	public function nest_list($where,$order,$rows)
	{
		$nest_list = module('category')->get_list($where,$order,$rows);
		$i=0;
		foreach($nest_list as &$val)
		{	
			$i++;
			$val['list']= $this->get_list('cat_id='.$val['id'],'show_order DESC',8);
			if($i%2)
			{
				$val['css'] = true;
			}else
			{
				$val['css'] = false;
			}
		}
		return $nest_list;
	}
	
	public function get_list($where,$order='show_order DESC',$list_rows=10,$cur_page=1)
	{
		$limit_start	= ($cur_page-1) * $list_rows;
		$limit			= $limit_start.','.$list_rows;
		$list = $this->model->table('article')->where($where)->limit($limit)->order($order)->select();
		if($list)
		{
			foreach($list as &$val)
			{
				$val['add_time']	= date('Y-m-d',$val['add_time']);
				$val['url']			= __APP__.'/article/artinfo-'.$val['id'].'.html';
			}
			return $list;
		}
	}
	
	public function artinfo()
	{
		$id				 = intval($_GET[0]);
		$condition['id'] = $id;
		if($this->model->table('article')->data('views=views+1')->where($condition)->update())
		{
			$info		 = $this->info($id);
			$this->assign('info',			$info);
			$this->assign('cmcount',		$this->model->table('comment')->where("top_type=1 AND tid='$id' AND is_validated=1")->count());
			$this->assign('artcat',			module('category')->info($info['cat_id']));
			$this->display('artinfo');
		}
		else
		{
			$this->error('此信息不存在！');
		}
	}
	
	public function info($id)
	{
		if(empty($id))
		{
			$this->error('参数传递有误');
		}
		$condition['id']	= $id;
    	$info				= $this->model->table('article')->where($condition)->find();
		$info['content']	= html_out($info['content']);
		$info['add_time']	= date('Y-m-d H:i:s',$info['add_time']);
		$info['cat']		= module('category')->info($info['cat_id']);
		$info['url']		= __APP__.'/article/artinfo-'.$info['id'].'.html';
		return $info;
	}
}
?>