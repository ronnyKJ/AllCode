<?php
class categoryMod extends commonMod
{
	public function get_list($where,$order='show_order DESC',$list_rows=10,$cur_page=1)
	{
		$limit_start	= ($cur_page-1) * $list_rows;
		$limit			= $limit_start.','.$list_rows;
		$list = $this->model->table('category')->where($where)->limit($limit)->order($order)->select();
		if($list)
		{
			foreach($list as &$val)
			{
				$val['url'] = __APP__.'/article/artlist-'.$val['id'].'.html';
			}
			return $list;
		}
	}
	
	public function info($id)
	{
		if(empty($id))
		{
			$this->error('参数传递有误');
		}
		$condition['id']	= $id;
    	$info				= $this->model->table('category')->where($condition)->find();
		$info['url']		= __APP__.'/article/artlist-'.$info['id'].'.html';
		return $info;	
	}
}
?>