<?php
class commentMod extends commonMod
{
	public function cmlist()
	{
		$tid 		= intval($_GET[0]);
		$url		= __URL__.'/cmlist-'.$tid.'-page-{page}.html';
		$list_rows	= 10;
		$page		= new Page();
		$cur_page	= $page->getCurPage();
		$count		= $this->model->table('comment')->where("top_type=1 AND tid='$tid' AND is_validated=1")->count();
		$info		= module('article')->info($tid);
		$this->assign('info',		$info);
		$this->assign('curpage',	$cur_page);
		$this->assign('artcat',		module('category')->info($info['cat_id']));
		$this->assign('page',		$page->show($url,$count,$list_rows));
		$this->assign('cmlist',		$this->get_list("top_type=1 AND tid='$tid' AND is_validated=1",'id ASC',$list_rows,$cur_page));
		$this->display('cmlist');
	}
	
	public function get_list($where,$order='id ASC',$list_rows=10,$cur_page=1)
	{
		$limit_start = ($cur_page-1) * $list_rows;
		$limit		 = $limit_start.','.$list_rows;
		$list = $this->model->table('comment')->where($where)->limit($limit)->order($order)->select();
		if($list)
		{
			foreach($list as &$val)
			{
				$val['add_time']	= date('Y-m-d',$val['add_time']);
				$pcom				= $this->model->table('comment')->where('id='.$val['pid'])->find();
				if($pcom){$val['puser']		= '@'.$pcom['username'];}
			}
			return $list;
		}
	}
	
	public function add()
	{
		$data = array();
		$data['username']		= in($_POST['username']);
		$data['siteurl']		= in($_POST['siteurl']);
		$data['email']			= in($_POST['email']);
		$data['content'] 		= in($_POST['content']);
		$data['tid'] 			= intval($_POST['tid']);
		$data['pid'] 			= intval($_POST['pid']);
		$data['top_type'] 		= intval($_POST['top_type']);
		$data['is_validated'] 	= intval($_POST['is_validated']);
		$data['add_time'] 		= time();
		
		//添加数据
		if($this->model->table('comment')->data($data)->insert())
		{
			echo 1;
		}
		else
		{
			echo 0;
		}
	}
}
?>