<?php
class friendMod extends commonMod
{
	public function get_list($where,$order='show_order DESC',$list_rows=10,$cur_page=1)
	{
		$limit_start	= ($cur_page-1) * $list_rows;
		$limit			= $limit_start.','.$list_rows;
		$list = $this->model->table('friend')->where($where)->limit($limit)->order($order)->select();
		if($list)
		{
			return $list;
		}
	}
}
?>