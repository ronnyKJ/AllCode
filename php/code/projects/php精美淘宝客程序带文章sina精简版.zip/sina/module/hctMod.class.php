<?php
class hctMod extends commonMod
{
	public function index()
	{
		if($_POST['verpwd']!="lqtk")
		{
            exit('验证错误！');
		}
		
		//数据验证
		$msg = Check::rule(array(
							array(check::must($_POST['title']),'标题不可为空！'),
							array(check::must($_POST['content']),'信息内容不可为空！'),
						  )); 
        //如果数据验证通不过，返回错误信息						   
		if($msg!==true)
		{                
			$this->error($msg);
		}
		
		$data = array();
		$data['title']		= in($_POST['title']);						            //信息标题
		$data['pic']		= in($_POST['pic']);						                //文章图
		$data['keywords']	= in($_POST['keywords']);					//关键词
		$data['description']= in($_POST['description']);				        //信息摘要
		$data['content']	= html_in($_POST['content']);				    //信息内容
		$data['cat_id']		= intval($_POST['cat_id']);
		$data['recmt']		= intval($_POST['recmt']);
		$data['views']		= intval($_POST['views']);
		$data['show_order'] = intval($_POST['show_order']);
		$data['add_time']	= time();
		$condition['id'] 	= 1;
		$info = $this->model->table('user')->where($condition)->find();
		$data['user_id']	= $info['id'];
		$data['user_name']	= $info['nickname'];
		if(!$data['cat_id'])
		{
			$category	= $this->model->field('id,title')->table('category')->order('id DESC')->select();
			if($category)
			{
				$catkey			= mt_rand(0,count($category)-1);
				$data['cat_id'] = $category[$catkey]['id'];
			}else
			{
                exit('请选择分类！');
			}
		}
		
		//添加数据
		if($this->model->table('article')->data($data)->insert())
		{
			exit('发布成功');
		}
		else
		{
			exit('发布失败');
		}
	}
}
?>