<?php
class indexMod extends commonMod
{
	public function index()
	{
		$tk_list	= module('lqtk')->get_list(1,'','',40);
		$this->assign('tk_list',	$tk_list['item']);
		$this->assign('nest_list',	module('article')->nest_list('','show_order DESC',4));
		$this->assign('txtfriend',	module('friend')->get_list('type=1','show_order DESC',50));
		$this->assign('imgfriend',	module('friend')->get_list('type=2','show_order DESC',50));
		$this->display('index');
	}
	
}
?>