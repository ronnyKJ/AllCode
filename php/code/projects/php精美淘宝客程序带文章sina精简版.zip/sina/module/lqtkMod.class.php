<?php
class lqtkMod extends commonMod
{	
	public function tlist()
	{
		$tbk			= module('tbk')->tbk();
		$cid			= intval(isset($_GET['0']) ? trim($_GET['0']) :$tbk['tkcat']);
		$url			= __URL__.'/tlist-'.$cid.'-page-{page}.html';
		$page			= new Page();
		$page_no		= $page->getCurPage();
		$list			= $this->get_list($page_no,$cid,'','');
		$count		   	= $tbk['tksize']*99;
		if($count>$list['count'])
		{
			$count		= $list['count'];
		}
		$this->assign('curpage',$page_no);
		$this->assign('nowcat',	$this->now_category($cid));
		$this->assign('list',	$list['item']);
		$this->assign('page',   $page->show($url,$count,$tbk['tksize']));
		$this->display('tlist');
	}
	
	public function tgoods()
	{
		$num_iid	= isset($_GET['0']) ? trim($_GET['0']) :0;
		$goods		= $this->goods($num_iid);
		$this->assign('nowcat', $this->now_category($goods['item']['cid']));
		$this->assign('gurl',	$_SERVER['SCRIPT_URI']);
		$this->assign('goods',	$goods);
		$this->display('goods');
	}
	
	public function tsearch()
	{
		$tbk			= module('tbk')->tbk();
		$cid			= intval(isset($_GET['0']) ? trim($_GET['0']) :$tbk['tkcat']);
		$keyword		= iconv("gb2312","utf-8",in(isset($_GET['1']) ? trim($_GET['1']) :''));
		$url			= __URL__.'/tsearch-'.$cid.'-'.$keyword.'-page-{page}.html';
		$page			= new Page();
		$page_no		= $page->getCurPage();
		$list			= $this->get_list($page_no,$cid,$keyword,'');
		$count		   	= $tbk['tksize']*99;
		if($count>$list['count'])
		{
			$count		= $list['count'];
		}
		$tstil['name']  = $keyword;
		$tstil['url']	= __URL__.'/tsearch-'.$cid.'-'.$keyword.'.html';
		$this->assign('tstil',	$tstil);
		$this->assign('curpage',$page_no);
		$this->assign('list',	$list['item']);
		$this->assign('page',   $page->show($url,$count,$tbk['tksize']));
		$this->display('tsearch');
	}
	
	public function get_list($page_no,$cid,$keyword,$page_size)
	{
		$tbk	= module('tbk')->tbk();
		$cid	= !empty($cid) ? $cid :$tbk['tkcat'];
		$page_size	= !empty($page_size) ? $page_size :$tbk['tksize'];
		$Tbk	= new Tbk(array(trim($tbk['tkkey']),trim($tbk['tksecret']),trim($tbk['tkname']),'',$cid,$keyword,$tbk['tkorder'],$tbk['tklevel'],$page_no,$page_size));
		$tklist = $Tbk->get_tklist();
		if($tklist['item'])
		{
			foreach($tklist['item'] as &$val)
			{
				$val['url'] = __APP__.'/lqtk/tgoods-'.$val['num_iid'].'.html';
			}
		}
		else
		{
			define("READ_CACHE",true);
		}
		return $tklist;
	}
	
	public function category()
	{
		$tbk	= module('tbk')->tbk();
		$Tbk	= new Tbk(array(trim($tbk['tkkey']),trim($tbk['tksecret']),trim($tbk['tkname']),'',$tbk['tkcat'],'',$tbk['tkorder'],$tbk['tklevel'],'',''));
		$tkcat	= $Tbk->get_category();
        if($tkcat)
		{
			foreach($tkcat as &$val)
			{
				$val['url'] = __APP__.'/lqtk/tlist-'.$val['cid'].'.html';
			}
		}
		else
		{
			define("READ_CACHE",true);
		}
		return $tkcat;
	}
	
	public function now_category($cid)
	{
		$tbk	= module('tbk')->tbk();
		$Tbk	= new Tbk(array(trim($tbk['tkkey']),trim($tbk['tksecret']),trim($tbk['tkname']),'',$cid,'',$tbk['tkorder'],$tbk['tklevel'],'',''));
		$tknowcat = $Tbk->get_now_category();
		if($tknowcat)
		{
			$tknowcat['url'] = __APP__.'/lqtk/tlist-'.$tknowcat['cid'].'.html';
		}
		else
		{
			define("READ_CACHE",true);
		}
		return $tknowcat;
	}
	
	public function goods($num_iid)
	{
		$tbk	= module('tbk')->tbk();
		$Tbk	= new Tbk(array(trim($tbk['tkkey']),trim($tbk['tksecret']),trim($tbk['tkname']),$num_iid,$tbk['tkcat'],'',$tbk['tkorder'],$tbk['tklevel'],'',''));
		if($Tbk->get_tkgoods())
		{
		}
		else
		{
			define("READ_CACHE",true);
		}
        return $Tbk->get_tkgoods();
	}
	
}
?>