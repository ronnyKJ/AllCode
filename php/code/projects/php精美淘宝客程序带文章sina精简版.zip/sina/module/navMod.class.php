<?php
class navMod extends commonMod
{
	public function get_list($where,$order='show_order DESC')
	{
		$list	= $this->model->table('nav')->where($where)->order($order)->select();
		if($list)
		{
			foreach($list as & $val)
			{
				$condition['pid']	= $val['id'];
				$nav_two = $this->model->table('nav')->where($condition)->order($order)->select();
				$val['nav_two'] = $nav_two;
			}
			return $list;
		}
	}
}
?>