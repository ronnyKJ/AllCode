<?php
class siteMod extends commonMod
{
	public function site($id=1)
	{
		$condition['id'] = $id;
		$info=$this->model->table('site')->where($condition)->find();
		if($info)
		{
			$info['key']	 	 = explode(',',$info['keywords']);
			$info['qq']			 = explode(',',$info['qq']);
			$info['statistical'] = html_out($info['statistical']);
			return $info;
		}
	}
}
?>