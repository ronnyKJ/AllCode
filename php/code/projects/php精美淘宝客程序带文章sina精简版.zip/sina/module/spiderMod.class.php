<?php
class spiderMod extends commonMod
{
	public function spider()
	{
		@$url		= $_SERVER['REQUEST_URI'];
		@$spider	= strtolower($_SERVER['HTTP_USER_AGENT']);
		@$turl		= $_SERVER['HTTP_REFERER'];
		@$ip		    = $_SERVER['REMOTE_ADDR'];
		$baidu		= strpos($spider,"baiduspider");
		$google	= strpos($spider,"googlebot");
		$soso		= strpos($spider,"sosospider");
		$youdao	= strpos($spider,"youdaobot");
		$bing		= strpos($spider,"bingbot");
		$sogou		= strpos($spider,"sogou");
		$yahoo		= strpos($spider,"yahoo");
		if($baidu)
		{
			$spider = 'baidu';
		}else if($google)
		{
			$spider	= 'google';
		}else if($soso)
		{
			$spider	= 'soso';
		}else if($youdao)
		{
			$spider	= 'youdao';
		}else if($bing)
		{
			$spider	= 'bing';
		}else if($sogou)
		{
			$spider	= 'sogou';
		}else if($yahoo)
		{
			$spider	= 'yahoo';
		}else
		{
			$spider	= null;
		}
		if($spider)
		{
			$data	= array();
			$data['name']	= $spider;
			$data['url']	    = $turl;
			$data['time']	= time();
			$this->model->table('spider')->data($data)->insert();
		}
	}
}
?>