<?php
class tbkMod extends commonMod
{
	public function tbk($id=1)
	{
		$condition['tkid'] = $id;
		$info = $this->model->table('tbk')->where($condition)->find();
		if($info)
		{
			$data 	= explode(',',$info['tksearch']);
			$info['tksearch'] = $data;
			$keys	= explode(',',$info['tkkey']);
			$secret	= explode(',',$info['tksecret']);
			$num	= count($keys);
			$rd		= array();
			for($i=0;$i<$num;$i++)
			{
				$Tbk	= new Tbk(array(trim($keys[$i]),trim($secret[$i]),trim($info['tkname']),1,'','','','','',''));
				$tmp	= $Tbk->akstate();
				if($tmp && !array_key_exists('code', $tmp))
				{
					$rd[]	= $i;
				}
			}
                        $kid	= $rd[array_rand($rd, 1)];
			$info['tkkey']		= $keys[$kid];
			$info['tksecret']	= $secret[$kid];
			return $info;
		}
	}
}
?>