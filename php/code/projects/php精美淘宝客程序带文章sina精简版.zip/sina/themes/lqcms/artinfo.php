<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{$info['title']}_{$artcat['title']} - {$site['name']}</title>
<link href="{$themes}/styles/basic.css" type="text/css" rel="stylesheet"/>
<link href="{$themes}/styles/common.css" type="text/css" rel="stylesheet">
<script src="{$themes}/js/jquery.js" type="text/javascript"></script>
<script src="{$themes}/js/commentadd.js" type="text/javascript"></script>
</head>

<body>
{include file="library/header"} 
<div id="content" style="margin-top:12px;">

{include file="library/left2"}

<div id="tlil" style="border:1px solid #cccccc; width:748px;">
<div class="postn" style="width:733px; border:none; border-bottom:1px solid #cccccc;"> 
当前位置：<a href="{$site['siteurl']}">网站首页</a> <span>>></span> 
<a href="{$artcat['url']}">{$artcat['title']}</a>
</div>
<h1>{$info['title']}</h1>
<div id="container">
<div id="desc">{$info['desc']}</div>
<div id="con">
<!--<?php if($info['pic']){ ?><img src="{$info['pic']}" alt="{$info['title']}"  style="float:left; margin:5px;" /> <?php }?>-->
{$info['content']}
<div id="dinp">
<span style="float:left;">网友点评：</span><span style="float:right;"><a href="__APP__/comment/cmlist-{$info[id]}.html">已有（{$cmcount}）条点评</a></span>
<textarea id="comcon" name="comcon"></textarea>
<span id="comxx" style="float:left;">
姓名：<input id="username" name="username" type="text" /> * 
网址：<input id="siteurl" name="siteurl" type="text" />  
邮箱：<input id="email" name="email" type="text" /> *
</span>
<input id="tid" name="tid" type="hidden" value="{$info['id']}" />
<input id="pid" name="pid" type="hidden" value="0" />
<input id="top_type" name="top_type" type="hidden" value="1" /> 
<input id="is_validated" name="is_validated" type="hidden" value="0" /> 
</span>
<span style="float:right;">
<input id="tijiao" name="tijiao" type="button" value="&nbsp;&nbsp;提&nbsp;&nbsp;交&nbsp;&nbsp;" style="margin-top:6px;" />
</span>
<div style="clear:both;"></div>
</div>

</div>
</div>
<div>

</div>
</div>
{include file="library/right2"}
</div>
{include file="library/footer"}
</body>
</html>
