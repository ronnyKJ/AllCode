<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{$artcat['title']}_第{$curpage}页 - {$site['name']}</title>
<link href="{$themes}/styles/basic.css" type="text/css" rel="stylesheet"/>
<link href="{$themes}/styles/common.css" type="text/css" rel="stylesheet">
</head>

<body>
{include file="library/header"} 
<div id="content" style="margin-top:12px;">
{include file="library/left2"}
<div id="tlil" style="border:1px solid #cccccc; width:748px;">
<div class="postn" style="width:733px; border:none; border-bottom:1px solid #cccccc;"> 
当前位置：<a href="{$site['siteurl']}">网站首页</a> <span>>></span> 
<a href="{$nowcat['url']}">{$artcat['title']}</a>
</div>
<div id="container">
<ul id="alist">
<?php if(!empty($artlist)){ foreach($artlist as $val){?> 	
<li><a href="{$val['url']}" title="{$val['title']}">{$val['title']}</a><span>[{$val['add_time']}]</span></li>
<?php } } ?>
</ul>
</div>
<div id="page" style="margin:10px;">{$page}</div>
</div>
{include file="library/right2"}
</div>
{include file="library/footer"}
</body>
</html>
