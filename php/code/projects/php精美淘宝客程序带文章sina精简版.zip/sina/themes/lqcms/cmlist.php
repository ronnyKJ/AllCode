<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{$info['title']}资讯点评_第{$curpage}页 - {$site['name']}</title>
<link href="{$themes}/styles/basic.css" type="text/css" rel="stylesheet"/>
<link href="{$themes}/styles/common.css" type="text/css" rel="stylesheet">
<script src="{$themes}/js/jquery.js" type="text/javascript"></script>
<script src="{$themes}/js/commentadd.js" type="text/javascript"></script>
</head>

<body>
{include file="library/header"} 
<div id="content" style="margin-top:12px;">
{include file="library/left2"}
<div id="tlil" style="border:1px solid #cccccc; width:748px;">
<div class="postn" style="width:733px; border:none; border-bottom:1px solid #cccccc;"> 
当前位置：<a href="{$site['siteurl']}">网站首页</a> <span>>></span> 
<a href="{$artcat['url']}">{$artcat['title']}</a>
</div>
<h1><a href="{$info['url']}">{$info['title']}</a></h1>
<div id="container">
<div id="con"><?php echo msubstr($info['content'],0,400); ?>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{$info['url']}" style="color:red;">查看详细</a></div>
</div>

<div id="cmlist">
<ul>
<?php if(!empty($cmlist)){ foreach($cmlist as $val){?> 	
<li>
<p><span style="float:left;"><a href="{$val['siteurl']}" rel="nofllow">{$val['username']}</a>&nbsp;&nbsp;&nbsp;&nbsp;邮箱：{$val['email']}</span><span style="float:right;">发表于{$val['add_time']}</span></p>
<p style="clear:both;">{$val['puser']} {$val['content']}</p>
<p style="text-align:right;"><a href="#page" onclick="repid({$val['id']});">回复</a></p>
</li>
<?php }} ?>
</ul>
</div>

<div id="page" style="margin:10px;">{$page}</div>

<div id="dinp" style="margin:20px 10px;">
<textarea id="comcon" name="comcon"></textarea>
<span id="comxx" style="float:left;">
姓名：<input id="username" name="username" type="text" /> * 
网址：<input id="siteurl" name="siteurl" type="text" />  
邮箱：<input id="email" name="email" type="text" /> *
</span>
<input id="tid" name="tid" type="hidden" value="{$info['id']}" />
<input id="pid" name="pid" type="hidden" value="0" />
<input id="top_type" name="top_type" type="hidden" value="1" /> 
<input id="is_validated" name="is_validated" type="hidden" value="0" /> 
<span style="float:right;">
<input id="tijiao" name="tijiao" type="button" value="&nbsp;&nbsp;提&nbsp;&nbsp;交&nbsp;&nbsp;" style="margin-top:6px;" />
</span>
<div style="clear:both;"></div>
</div>

</div>
{include file="library/right2"}
</div>
{include file="library/footer"}
</body>
</html>
