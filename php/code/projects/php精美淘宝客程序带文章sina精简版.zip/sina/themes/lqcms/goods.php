<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{$goods['item']['title']}_{$nowcat['name']} - {$site['name']}</title>
<link href="{$themes}/styles/basic.css" type="text/css" rel="stylesheet"/>
<link href="{$themes}/styles/common.css" type="text/css" rel="stylesheet">
</head>

<body>
{include file="library/header"} 
<div id="content" style="margin-top:12px;">
<div id="tlil">
<div class="postn"> 
当前位置：<a href="{$site['siteurl']}">网站首页</a> <span>>></span> 
<a href="{$nowcat['url']}">{$nowcat['name']}</a>
</div>

<div id="pinfo">
<div class="prodinfo">
<div class="left">             
<div class="pic">                    
<a onclick="window.open('{$goods['click_url']}');" href="javascript:void(0);">
<img alt="{$goods['item']['title']}" src="{$goods['item']['pic_url']}"></a>
</div>
<div class="fav"><a href="#"><img alt="" src="http://www.wctbk.com/view/default/images/btn_fav.gif"></a></div>
</div>

<div class="right">
<h1 style="text-align:left;"><a onclick="window.open ('{$goods['click_url']}');" href="javascript:void(0);">{$goods['item']['title']}</a></h1>
<ul>
<li><span>优惠价：</span> <strong style="color:#CC0000;font-size:18px;font-weight:bold;">{$goods['item']['price']}</strong> 元</li>
<li><span>服&nbsp;&nbsp;&nbsp;务：</span> 免运费 货到付款 品牌专卖</li>
<li><span>已&nbsp;&nbsp;&nbsp;售：</span> <strong style="color:#CC0000;font-size:18px;font-weight:bold;">{$goods['item']['num']}</strong> 件</li>
<li><span>商&nbsp;&nbsp;&nbsp;城：</span> <a onclick="window.open ('{$goods['shop_click_url']}');" href="javascript:void(0);">{$goods['item']['nick']}</a></li>
<li><span>信&nbsp;&nbsp;&nbsp;誉：</span>
<img alt="卖家信用" src="{$themes}/images/level_{$goods['seller_credit_score']}.gif"></li>
</ul>
<div class="btn">
<a onclick="window.open('{$goods['click_url']}');" href="javascript:void(0);">
<img alt="立即购买" src="http://www.wctbk.com/view/default/images/btn_buy.gif"></a>
</div>
<div class="btn">
<!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
        <a class="bds_qzone"></a>
        <a class="bds_tsina"></a>
        <a class="bds_tqq"></a>
        <a class="bds_renren"></a>
        <span class="bds_more">更多</span>
		<a class="shareCount"></a>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=629299" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
</div>
</div>
</div>

<div class="prodshow">
<div class="title">
<h3>详细信息 <span>{$gurl}</span></h3>
</div>
<div class="proddetails">
<?php echo preg_replace("/(?<=href=)([^>]*)(?=>)/i","#",$goods['item']['desc']);?>
</div>
</div>

</div>

</div>
{include file="library/left"}
</div>
{include file="library/footer"}
</body>
</html>
