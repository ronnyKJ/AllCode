<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{$site['title']}</title>
<meta name="keywords" content="{$site['keywords']}" />
<meta name="description" content="{$site['description']}" />
<link href="{$themes}/styles/basic.css" type="text/css" rel="stylesheet"/>
<link href="{$themes}/styles/common.css" type="text/css" rel="stylesheet">
<script src="{$themes}/js/jquery.js" type="text/javascript"></script>
<script src="{$themes}/js/lazyload.js" type="text/javascript"></script>
<script src="{$themes}/js/jquery.masonry.min.js" type="text/javascript"></script> 
<script src="{$themes}/js/tooltip.js" type="text/javascript"></script>
</head>

<body>
{include file="library/header"} 
<script type="text/javascript">
$(document).ready(function()
{
$("#container .pic img").lazyload({
placeholder : "{$themes}/images/grey.gif",
effect : "fadeIn"
});
});
</script>

<div id="content">

<div class="listcate">
<ul style="padding-left:15px;">
<?php if(!empty($tk_cat)){ foreach($tk_cat as $val){?> 	
<li ><a href="{$val['url']}">{$val['name']}</a></li>
<?php } } ?>
</ul>
</div>

<div id="container">

<?php if(!empty($tk_list)){ foreach($tk_list as $val){?> 	
<div class="col">
<div class="pic">
<a href="{$val['url']}" rel="{$val['pic_url']}" class="tooltip" title="{$val['title']}" target="_blank">                
<img src="{$themes}/images/grey.gif" original="{$val['pic_url']}" alt="{$val['title']}" /></a>
</div>
<h3>
<a href="{$val['url']}" target="_blank">{$val['title']}</a>
</h3>
<div class="mallprice">
<div class="left">
<div>优惠价 <strong>{$val['price']}</strong>元</div>
<div class="malltitle">          
<a href="javascript:void(0);" onclick= "window.open ('{$val['shop_click_url']}');">淘宝：{$val['nick']}</a>
有售</div>
</div>
<div class="right">
<a href="javascript:void(0);" onclick= "window.open ('{$val['click_url']}');"></a>
</div>
</div>
</div>
<?php } } ?>
</div>

<script type="text/javascript">
$(function(){
$('#container').masonry({
itemSelector : '.col',
columnWidth : 245
});
});
</script>
</div>
<!--[if gt IE 6]>
<script src="js/scrolltop.js" type="text/javascript"></script>
<div style="DISPLAY: none" id=goTopBtn><IMG border=0 src="images/up.gif"></div>
<![endif]-->
<script type="text/javascript">goTopEx();</script>
<div id="nzx">

<?php if(!empty($nest_list)){ foreach($nest_list as $val){?> 
<div class="listcate <?php if($val['css']){ ?> newzx <?php }else{?> newzxt <?php } ?>">
<div class="sellor_title"><a href="{$val['url']}">{$val['title']}</a></div>
<ul>
<?php if(!empty($val['list'])){ foreach($val['list'] as $val){?> 
<li><a href="{$val['url']}">{$val['title']}</a><span>[{$val['add_time']}]</span></li>
<?php } } ?>
<div style="clear:both;"></div>
</ul>
</div>
<?php } } ?>

<div style="clear:both;"></div>
</div>

<div class="listcate" style="padding:0px; margin:10px auto;">
<div class="sellor_title">友情链接</div>
<ul>
<?php if(!empty($imgfriend)){ foreach($imgfriend as $val){?> 
<li><a href="{$val['url']}"><img src="{$val['logo']}" alt="{$val['title']}" /></a></li>
<?php } } ?>
<li style="clear:both; float:none;"></li>
<?php if(!empty($txtfriend)){ foreach($txtfriend as $val){?> 
<li><a href="{$val['url']}">{$val['title']}</a></li>
<?php } } ?>
</ul>
</div>
{include file="library/footer"}
</body>
</html>
