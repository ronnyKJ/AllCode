// JavaScript Document
$(document).ready(function() {
$('#tijiao').bind('click',function(){
	if($("#comcon").val()=="")
	{
		alert("点评内容不可为空！");return false;
	}
	if($("#username").val()=="")
	{
		alert("昵称不可为空！");return false;
	}
	if($("#email").val()=="")
	{
		alert("邮箱不可为空！");return false;
	}
	$.ajax({
		type: "POST",
		url:  "/index.php/comment/add",
		data: {username:$('#username').val(),siteurl:$('#siteurl').val(),email:$('#email').val(),content:$('#comcon').val(),tid:$('#tid').val(),pid:$('#pid').val(),top_type:$('#top_type').val(),is_validated:$('#is_validated').val()},
		success: function(data){
			if(data=="1")
			{
				alert("评论成功请等待管理员审核！");
				$("#comcon").val("");$("#username").val("");$("#siteurl").val("");$("#email").val("");
				}
			else{
				alert("评论失败请确认信息是否填写完整！");
				}
			}
		});
	});
})