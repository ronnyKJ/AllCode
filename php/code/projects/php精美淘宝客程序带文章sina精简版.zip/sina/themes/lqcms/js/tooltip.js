/**
 * 
 */

$(function(){
	var x = 10;
	var y = 20;
	$("a.tooltip").mouseover(function(e){
		this.myTitle = this.title;
		this.title = "";	
		var imgTitle = this.myTitle? "<br/>" + this.myTitle : "";
		var tooltip = "<div id='tooltip'><img src='"+ this.rel +"' alt='"+imgTitle+"'/><h3>"+imgTitle+"</h3><\/div>"; //创建 div 元素
		$("body").append(tooltip);	//把它追加到文档中						 
		$("#tooltip")
			.css({
				"top": (e.pageY+y) + "px",
				"left":  (e.pageX+x)  + "px"
			}).show("fast");	  //设置x坐标和y坐标，并且显示
    }).mouseout(function(){
		this.title = this.myTitle;	
		$("#tooltip").remove();	 //移除 
    }).mousemove(function(e){
		$("#tooltip")
			.css({
				"top": (e.pageY+y) + "px",
				"left":  (e.pageX+x)  + "px"
			});
	});
})


function SetHome(obj){
try{
obj.style.behavior='url(#default#homepage)';
obj.setHomePage('http://www.toofanli.com/');
}catch(e){
if(window.netscape){
try{
netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
}catch(e){
alert("抱歉，此操作被浏览器拒绝！\n\n请在浏览器地址栏输入'about:config'并回车然后将[signed.applets.codebase_principal_support]设置为'true'");
};
}else{
alert("抱歉，您所使用的浏览器无法完成此操作。\n\n您需要手动将'http://www.toofanli.com/'设置为首页。");
};
};
};
function addFavorite(){
var url="http://www.toofanli.com/";
var title="淘宝商城女装";
ua = navigator.userAgent.toLowerCase();
if(document.all){
try{
window.external.AddFavorite(url,title);
}
catch(e){
alert("加入收藏失败，\n请您使用菜单栏或Ctrl+D收藏本站。");
}
}else if(window.sidebar){
window.sidebar.addPanel(title,url,"")
}
else{
alert("加入收藏失败，\n请您使用菜单栏或Ctrl+D收藏本站。");
}
}