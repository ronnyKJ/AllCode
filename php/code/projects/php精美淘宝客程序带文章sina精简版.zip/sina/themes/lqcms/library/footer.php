<div style="height:20px; clear:both"></div>
<div class="bottom">
<p><?php if(!empty($site['key'])){foreach($site['key'] as $val){ ?> <a href="{$site['siteurl']}">{$val}</a> <?php }} ?></p>
<p>{$site['icpcode']} 邮箱：{$site['email']}　 联系qq：<?php if(!empty($site['qq'])){foreach($site['qq'] as $val){ ?> {$val} <?php }} ?> </p>
<p>Copyright &copy; <?=date("Y")?> The Wolves Network Taobao Customer System. All rights reserved.<a href="http://www.ibtf.net/">爱美丽</a></p>
</div>
{$site['statistical']}
<script src="__APP__/spider/spider.html" type="text/javascript"></script>