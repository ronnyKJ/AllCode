<div class="top">
<div id="topt">
<div id="tpsc">
<span>
<a href="javascript:void(0);" onclick="addFavorite();">收藏本站</a> | 
<a href="javascript:void(0);" onclick="SetHome(this);" style="margin-left:5px;">设为首页</a></span>
<span id="tprt">
<a>热销分类</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("新款女装") ?>.html">新款女装</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("文胸套装") ?>.html">文胸套装</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("时尚饰品") ?>.html">时尚饰品</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("品牌男装") ?>.html">品牌男装</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("性感丝袜") ?>.html">性感丝袜</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("流行女鞋") ?>.html">流行女鞋</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("女士内衣") ?>.html">女士内衣</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("时尚女包") ?>.html">时尚女包</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("韩版女装") ?>.html">韩版女装</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("减肥瘦身") ?>.html">减肥瘦身</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("丰胸美白") ?>.html">丰胸美白</a> - 
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode("") ?>.html">更多>></a>
</span>
</div></div>
<div id="top">
<div id="logo">
<img class="logo" src="{$themes}/images/logo.jpg" style="max-width:300px;" />
</div>		
<div id="search">
<div class="slt">
<span>
<a id="ish_1" onclick="SearchSelect(1,'');" class="on">宝贝</a>				
</span></div>
<input type="text" name="q" id="kw" onfocus="this.className='on';" value="热销女装" autocomplete="off" />
<button type="submit" class="search" onclick="soso();">搜 索</button>
<script type="text/javascript">
function soso()
{
	window.open("http://s8.taobao.com/search?cat={$tbk['tkcat']}&sort=coefp&q="+document.getElementById("kw").value+"&pid={$tbk['tkpid']}&style=grid&tk_rate=[1000.0,3000.0]&sort=sale-desc");
} 
</script>
<p>热搜：
<?php if(!empty($tbk['tksearch'])){ foreach($tbk['tksearch'] as $val){?>
<a href="__APP__/lqtk/tsearch-{$tbk['tkcat']}-<?php echo urlencode($val) ?>.html" target="_black">{$val}</a> 	
<?php }} ?>
</p>
</div>

<script language="javascript">	
var keywords=document.getElementById("kw");
keywords.onclick=function()
{
if(this.defaultValue==this.value)
{
this.value="";
}	
}
keywords.onblur=function(){
if(this.value==""){
this.value="热销女装";
}
}
</script>

</div>
<div style="height:46px;">
<div id="nav">
<ul>
<li class="hover" onclick="changename(0)"><a href="{$site['siteurl']}">网站首页</a></li>
<?php if(!empty($nav)){ foreach($nav as $key=>$val){?>
<li><a onclick="changename(<?php echo $key+1; ?>)" href="{$val['url']}">{$val['title']}</a></li>
<?php }} ?>					
</ul>
</div>
</div>
</div>
<script type="text/javascript">
function changename(c,cl)
{
var d=document.getElementById("nav").getElementsByTagName("li");
if(!cl)
{
writeCookie("hovers",c,222);
}
c=readCookie("hovers")?readCookie("hovers"):c;
for(i=0;i<d.length;i++)
{
d[i].className=i==c?"hover":"";
}
}
function writeCookie(name, value, hours)
{
var expire = "";
if(hours != null)
{
expire = new Date((new Date()).getTime() + hours * 3600000);
expire = "; expires=" + expire.toGMTString();
}
document.cookie = name + "=" + escape(value) + expire;
}
// alert( readCookie("myCookie") );
function readCookie(name)
{
var cookieValue = "";
var search = name + "=";
if(document.cookie.length > 0)
{ 
offset = document.cookie.indexOf(search);
if (offset != -1)
{ 
offset += search.length;
end = document.cookie.indexOf(";", offset);
if (end == -1) end = document.cookie.length;
cookieValue = unescape(document.cookie.substring(offset, end))
}
}
return cookieValue;
}
function clear()
{
writeCookie("hovers","",222);
document.location=document.location.href;
}
changename(0,1)
</script>
