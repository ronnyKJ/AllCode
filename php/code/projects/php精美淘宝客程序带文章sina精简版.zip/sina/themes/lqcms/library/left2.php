<div id="tlir">

<div id="lrct"> 
<h2>促销分类</h2>
<ul>
<?php if(!empty($tk_cat)){ foreach($tk_cat as $val){?> 	
<li ><a href="{$val['url']}">{$val['name']}</a></li>
<?php } } ?>
<div style="clear:both;"></div>
</ul>
</div>

<div id="lrgt">
<h2>橱窗推荐</h2>
<ul>
<?php if(!empty($tjgoods2['item'])){ foreach($tjgoods2['item'] as $val){?> 	
<li>
<a href="{$val['url']}" style="display:inline; padding:0px;"><img src="{$val['pic_url']}" alt="{$val['title']}" /></a>
<a href="{$val['url']}">{$val['title']}</a>
</li>
<?php } } ?>
</ul>
</div>

<div id="lrat">
<h2>推荐阅读</h2>
<ul>
<?php if(!empty($tjarticle)){ foreach($tjarticle as $val){?> 	
<li><a href="{$val['url']}">{$val['title']}</a></li>
<?php } } ?>
</ul>
</div>

<div id="lract">
<h2>资讯分类</h2>
<ul>
<?php if(!empty($art_cat)){ foreach($art_cat as $val){?> 	
<li ><a href="{$val['url']}">{$val['title']}</a></li>
<?php } } ?>
<div style="clear:both;"></div>
</ul>
</div>

</div>
