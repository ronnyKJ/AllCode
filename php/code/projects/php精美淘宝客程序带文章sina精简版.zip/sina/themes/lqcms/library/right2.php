<div id="tlil2">
<div class="postn" style="width:733px; border:none; border-bottom:1px solid #cccccc;"> 图文推荐</div>
<ul>
<?php if(!empty($twarticle)){ foreach($twarticle as $val){?> 	
<li><a href="{$val['url']}"><img src="{$val['pic']}" alt="{$val['title']}" /></a><br />
<a href="{$val['url']}" class="itw"><?php echo msubstr($val['title'],0,12); ?></a></li>
<?php }} ?>
</ul>
</div>
