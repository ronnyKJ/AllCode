<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{$tstil['name']}_第{$curpage}页 - {$site['name']}</title>
<link href="{$themes}/styles/basic.css" type="text/css" rel="stylesheet"/>
<link href="{$themes}/styles/common.css" type="text/css" rel="stylesheet">
<script src="{$themes}/js/jquery.js" type="text/javascript"></script>
<script src="{$themes}/js/lazyload.js" type="text/javascript"></script>
<script src="{$themes}/js/jquery.masonry.min.js" type="text/javascript"></script> 
<script src="{$themes}/js/tooltip.js" type="text/javascript"></script>
</head>

<body>
{include file="library/header"} 
<script type="text/javascript">
$(document).ready(function()
{
$("#container .pic img").lazyload({
	placeholder : "{$themes}/images/grey.gif",
	effect : "fadeIn"
});
});
</script>


<div id="content" style="margin-top:12px;">
<div id="tlil">
<div class="postn" style="width:725px;"> 
当前位置：<a href="{$site['siteurl']}">网站首页</a> <span>>></span> 
<a href="{$tstil['url']}">{$tstil['name']}</a>
</div>
<div id="container">
<?php if(!empty($list)){ foreach($list as $val){?> 	
<div class="col">
<div class="pic">
<a href="{$val['url']}" rel="{$val['pic_url']}" class="tooltip" title="{$val['title']}" target="_blank">                
<img src="{$themes}/images/grey.gif" original="{$val['pic_url']}" alt="{$val['title']}" /></a>
</div>
<h3>
<a href="{$val['url']}" target="_blank">{$val['title']}</a>
</h3>
<div class="mallprice">
<div class="left">
<div>优惠价 <strong>{$val['price']}</strong>元</div>
<div class="malltitle">          
<a href="javascript:void(0);" onclick= "window.open ('{$val['shop_click_url']}');">淘宝：{$val['nick']}</a>
有售</div>
</div>
<div class="right">
<a href="javascript:void(0);" onclick= "window.open ('{$val['click_url']}');"></a>
</div>
</div>
</div>
<?php } } ?>
</div>

<script type="text/javascript">
$(function(){
  $('#container').masonry({
    itemSelector : '.col',
    columnWidth : 250
  });
});
</script>
<div id="page">{$page}</div>
</div>
{include file="library/left"}
</div>
<!--[if gt IE 6]>
<script src="js/scrolltop.js" type="text/javascript"></script>
<div style="DISPLAY: none" id=goTopBtn><IMG border=0 src="images/up.gif"></div>
<![endif]-->
<script type="text/javascript">goTopEx();</script>
{include file="library/footer"}
</body>
</html>
