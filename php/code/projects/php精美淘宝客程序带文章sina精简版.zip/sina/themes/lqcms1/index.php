<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="{$theme}css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./ueditor/editor_config.js"></script>
<script type="text/javascript" src="./ueditor/editor_all.js"></script>
<link rel="stylesheet" href="./ueditor/themes/default/ueditor.css"/>
</head>

<body>
<form action="__APP__/index/add" method="post">
{$name}
<!--<div id="myEditor"></div>

-->
<script type="text/plain" id="myEditor">初始内容</script>
<script type="text/javascript">
    var editor = new baidu.editor.ui.Editor();
    editor.render("myEditor");
</script>
<input name="" type="submit" />
</form>
</body>
</html>
