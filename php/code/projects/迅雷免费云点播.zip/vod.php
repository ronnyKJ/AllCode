<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>龙口电影院|龙口云点播|迅雷云点播破解版|免费迅雷播放特权|破解云点播</title>
<meta name="keywords" content="龙口电影院,迅雷云点播破解,龙口华艺影城,迅雷云点播,云点播破解版,龙口星美国际影城,迅雷云点播破解版">
<meta name="description" content="想要免费迅雷播放特权？迅雷云点播要会员吗？bbs.longkou.de提供的迅雷云点播破解版，龙口免费迅雷云播放。">
<style type="text/css"> 
body{background:#111;text-align:center;margin:0;padding:0;}
</style>
</head>
<body>
<!-- 龙口播放器 start -->
<div style="clear:both;overflow:hidden;width:848px; height:480px;position:relative;margin:0 auto;" id="wpppp">
<div id="XL_CLOUD_VOD_PLAYER"  style="width:848px;height:480px;overflow:hidden;text-align:center">
	<img style="width:848px;height:480px;" src="/img/player_startup.jpg"/>
<a autoplay="no" href="<?php echo trim($_GET["str"]); ?>"></a></div>
</div>
<!-- 龙口播放器 end -->
<div>
<form method="get" action="">
<input name="str" type="text" id=" " style="width:765px;height: 18px;" value="在这里添加视频地址，支持http、ftp、ed2k、thunder、magnet开头的链接" onFocus="if(value=='在这里添加视频地址，支持http、ftp、ed2k、thunder、magnet开头的链接') {value=''}" onBlur="if 
(value=='') {value='在这里添加视频地址，支持http、ftp、ed2k、thunder、magnet开头的链接'}" value="在这里添加视频地址，支持http、ftp、ed2k、thunder、magnet开头的链接"/>
<input type="submit" value="点击播放" style="cursor: pointer;" />
</form>
</div>
<!-- Baidu Button BEGIN -->
<div>
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare" style="color:#fff;float:none;width:660px;overflow:hidden;margin:10px auto 0;">
        <a class="bds_qzone">QQ空间</a>
        <a class="bds_tsina">新浪微博</a>
        <a class="bds_tqq">腾讯微博</a>
        <a class="bds_renren">人人网</a>
        <a class="bds_douban">豆瓣网</a>
        <a class="bds_baidu">百度搜藏</a>
        <a class="bds_qq">QQ收藏</a>
        <a class="bds_kaixin001">开心网</a>
        <a class="bds_copy">复制</a>
        <span class="bds_more">更多</span>
		<a class="shareCount"></a>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=533431" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript"> 
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();
google_ad_client = "ca-pub-2006512290696014";
google_ad_slot = "6662313368";
google_ad_width = 468;
google_ad_height = 60;
</script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
</div>
<!-- Baidu Button END -->
 
<script src="js/player.js" charset="utf-8" type="text/javascript"></script>
<div style="display:none"><script language="javascript" type="text/javascript" src="http://js.users.51.la/3729735.js"></script></div>
</body>
</html>
