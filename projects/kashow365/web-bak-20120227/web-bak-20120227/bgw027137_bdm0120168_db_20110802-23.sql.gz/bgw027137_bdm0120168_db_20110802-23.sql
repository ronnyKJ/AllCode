-- MySQL dump 10.13  Distrib 5.1.48, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: bdm0120168_db
-- ------------------------------------------------------
-- Server version	5.1.48

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TAdministrator`
--

DROP TABLE IF EXISTS `TAdministrator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TAdministrator` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mail` varchar(200) DEFAULT NULL,
  `loginName` varchar(200) DEFAULT NULL COMMENT '登录名。',
  `loginPassword` varchar(200) DEFAULT NULL COMMENT '登录密码。',
  `remark` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Index_1` (`loginName`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAdministrator`
--

LOCK TABLES `TAdministrator` WRITE;
/*!40000 ALTER TABLE `TAdministrator` DISABLE KEYS */;
INSERT INTO `TAdministrator` VALUES (1,'pct_zhang@163.com','pct','e10adc3949ba59abbe56e057f20f883e','管理员'),(2,'','fur','e10adc3949ba59abbe56e057f20f883e','管理员'),(3,'','zhuhr','e10adc3949ba59abbe56e057f20f883e','管理员'),(4,'','zix','e10adc3949ba59abbe56e057f20f883e','管理员');
/*!40000 ALTER TABLE `TAdministrator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKAreaDistrict`
--

DROP TABLE IF EXISTS `TKAreaDistrict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKAreaDistrict` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parentId` bigint(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `orderNum` decimal(5,2) DEFAULT '0.00' COMMENT '显示排序',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`parentId`,`orderNum`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKAreaDistrict`
--

LOCK TABLES `TKAreaDistrict` WRITE;
/*!40000 ALTER TABLE `TKAreaDistrict` DISABLE KEYS */;
INSERT INTO `TKAreaDistrict` VALUES (1,0,'全北京','0.00'),(2,0,'海淀','0.00'),(3,0,'朝阳','0.00'),(4,0,'东城','0.00'),(5,0,'西城','0.00'),(6,0,'崇文','0.00'),(7,0,'宣武','0.00'),(8,0,'丰台','0.00'),(9,0,'石景山','0.00'),(10,0,'昌平','0.00'),(11,0,'通州','0.00'),(12,0,'大兴','0.00'),(13,0,'顺义','0.00'),(14,0,'房山','0.00'),(15,0,'密云','0.00'),(16,0,'门头沟','0.00'),(17,0,'怀柔','0.00'),(18,0,'平谷','0.00'),(19,0,'延庆','0.00'),(20,0,'燕郊','0.00');
/*!40000 ALTER TABLE `TKAreaDistrict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKAreaUrban`
--

DROP TABLE IF EXISTS `TKAreaUrban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKAreaUrban` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parentId` bigint(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `orderNum` decimal(5,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`parentId`,`orderNum`)
) ENGINE=MyISAM AUTO_INCREMENT=351 DEFAULT CHARSET=utf8 COMMENT='市区内区域';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKAreaUrban`
--

LOCK TABLES `TKAreaUrban` WRITE;
/*!40000 ALTER TABLE `TKAreaUrban` DISABLE KEYS */;
INSERT INTO `TKAreaUrban` VALUES (1,1,'全北京','0.00'),(2,2,'清河','0.00'),(3,2,'小营','0.00'),(4,2,'西三旗','0.00'),(5,2,'西二旗','0.00'),(6,2,'上地','0.00'),(7,2,'西北旺','0.00'),(8,2,'马连洼','0.00'),(9,2,'西苑','0.00'),(10,2,'万泉河','0.00'),(11,2,'苏州街','0.00'),(12,2,'中关村','0.00'),(13,2,'北大清华','0.00'),(14,2,'五道口','0.00'),(15,2,'学院路','0.00'),(16,2,'二里庄','0.00'),(17,2,'牡丹园','0.00'),(18,2,'北太平庄','0.00'),(19,2,'马甸','0.00'),(20,2,'蓟门桥','0.00'),(21,2,'大钟寺','0.00'),(22,2,'知春路','0.00'),(23,2,'双榆树','0.00'),(24,2,'人民大学','0.00'),(25,2,'万柳','0.00'),(26,2,'世纪城','0.00'),(27,2,'魏公村','0.00'),(28,2,'皂君庙','0.00'),(29,2,'交通大学','0.00'),(30,2,'西直门','0.00'),(31,2,'白石桥','0.00'),(32,2,'紫竹桥','0.00'),(33,2,'万寿寺','0.00'),(34,2,'车道沟','0.00'),(35,2,'北洼路','0.00'),(36,2,'花园桥','0.00'),(37,2,'航天桥','0.00'),(38,2,'增光路','0.00'),(39,2,'甘家口','0.00'),(40,2,'军博','0.00'),(41,2,'公主坟','0.00'),(42,2,'万寿路','0.00'),(43,2,'五棵松','0.00'),(44,2,'永定路','0.00'),(45,2,'定慧寺','0.00'),(46,2,'田村','0.00'),(47,2,'四季青','0.00'),(48,2,'香山','0.00'),(49,2,'其他','0.00'),(50,3,'北苑','0.00'),(51,3,'来广营','0.00'),(52,3,'望京','0.00'),(53,3,'花家地','0.00'),(54,3,'酒仙桥','0.00'),(55,3,'大山子','0.00'),(56,3,'北沙滩','0.00'),(57,3,'健翔桥','0.00'),(58,3,'亚运村','0.00'),(59,3,'奥运村','0.00'),(60,3,'大屯','0.00'),(61,3,'小营','0.00'),(62,3,'小关','0.00'),(63,3,'安贞','0.00'),(64,3,'和平街','0.00'),(65,3,'惠新里','0.00'),(66,3,'芍药居','0.00'),(67,3,'太阳宫','0.00'),(68,3,'西坝河','0.00'),(69,3,'柳芳','0.00'),(70,3,'国展','0.00'),(71,3,'左家庄','0.00'),(72,3,'三元桥','0.00'),(73,3,'燕莎','0.00'),(74,3,'朝阳公园','0.00'),(75,3,'甜水园','0.00'),(76,3,'水碓子','0.00'),(77,3,'团结湖','0.00'),(78,3,'三里屯','0.00'),(79,3,'工体','0.00'),(80,3,'朝外','0.00'),(81,3,'东大桥','0.00'),(82,3,'CBD','0.00'),(83,3,'呼家楼','0.00'),(84,3,'国贸','0.00'),(85,3,'双井','0.00'),(86,3,'劲松','0.00'),(87,3,'潘家园','0.00'),(88,3,'南磨房','0.00'),(89,3,'西大望路','0.00'),(90,3,'百子湾','0.00'),(91,3,'四惠','0.00'),(92,3,'红庙','0.00'),(93,3,'八里庄','0.00'),(94,3,'石佛营','0.00'),(95,3,'十里堡','0.00'),(96,3,'甘露园','0.00'),(97,3,'高碑店','0.00'),(98,3,'朝青板块','0.00'),(99,3,'姚家园','0.00'),(100,3,'东坝','0.00'),(101,3,'定福庄','0.00'),(102,3,'双桥','0.00'),(103,3,'管庄','0.00'),(104,3,'常营','0.00'),(105,3,'豆各庄','0.00'),(106,3,'垡头','0.00'),(107,3,'十八里店','0.00'),(108,3,'小红门','0.00'),(109,3,'其他','0.00'),(110,4,'东直门','0.00'),(111,4,'和平里','0.00'),(112,4,'雍和宫','0.00'),(113,4,'安定门','0.00'),(114,4,'交道口','0.00'),(115,4,'北新桥','0.00'),(116,4,'海运仓','0.00'),(117,4,'东四十条','0.00'),(118,4,'东四','0.00'),(119,4,'朝阳门','0.00'),(120,4,'建国门','0.00'),(121,4,'东单','0.00'),(122,4,'王府井','0.00'),(123,4,'灯市口','0.00'),(124,4,'景山','0.00'),(125,4,'沙滩','0.00'),(126,4,'其他','0.00'),(127,5,'西直门','0.00'),(128,5,'新街口','0.00'),(129,5,'积水潭','0.00'),(130,5,'小西天','0.00'),(131,5,'德胜门','0.00'),(132,5,'六铺炕','0.00'),(133,5,'后海','0.00'),(134,5,'什刹海','0.00'),(135,5,'西四','0.00'),(136,5,'西单','0.00'),(137,5,'复兴门','0.00'),(138,5,'金融街','0.00'),(139,5,'阜成门','0.00'),(140,5,'官园','0.00'),(141,5,'车公庄','0.00'),(142,5,'百万庄','0.00'),(143,5,'展览路','0.00'),(144,5,'月坛','0.00'),(145,5,'南礼士路','0.00'),(146,5,'三里河','0.00'),(147,5,'木樨地','0.00'),(148,5,'西便门','0.00'),(149,5,'其他','0.00'),(150,6,'前门','0.00'),(151,6,'崇文门','0.00'),(152,6,'花市','0.00'),(153,6,'广渠门','0.00'),(154,6,'光明楼','0.00'),(155,6,'法华寺','0.00'),(156,6,'体育馆路','0.00'),(157,6,'龙潭湖','0.00'),(158,6,'天坛','0.00'),(159,6,'永定门','0.00'),(160,6,'沙子口','0.00'),(161,6,'其他','0.00'),(162,7,'广安门','0.00'),(163,7,'西客站','0.00'),(164,7,'马连道','0.00'),(165,7,'红莲','0.00'),(166,7,'白纸坊','0.00'),(167,7,'南菜园','0.00'),(168,7,'右安门','0.00'),(169,7,'白广路','0.00'),(170,7,'牛街','0.00'),(171,7,'长椿街','0.00'),(172,7,'宣武门','0.00'),(173,7,'菜市口','0.00'),(174,7,'陶然亭','0.00'),(175,7,'虎坊桥','0.00'),(176,7,'天桥','0.00'),(177,7,'前门','0.00'),(178,7,'和平门','0.00'),(179,7,'其他','0.00'),(180,8,'六里桥','0.00'),(181,8,'西客站','0.00'),(182,8,'马连道','0.00'),(183,8,'丽泽桥','0.00'),(184,8,'菜户营','0.00'),(185,8,'玉泉营','0.00'),(186,8,'草桥','0.00'),(187,8,'右安门','0.00'),(188,8,'马家堡','0.00'),(189,8,'角门','0.00'),(190,8,'洋桥','0.00'),(191,8,'西罗园','0.00'),(192,8,'木樨园','0.00'),(193,8,'赵公口','0.00'),(194,8,'刘家窑','0.00'),(195,8,'蒲黄榆','0.00'),(196,8,'方庄','0.00'),(197,8,'左安门','0.00'),(198,8,'成寿寺','0.00'),(199,8,'宋家庄','0.00'),(200,8,'大红门','0.00'),(201,8,'南苑','0.00'),(202,8,'和义','0.00'),(203,8,'东高地','0.00'),(204,8,'新发地','0.00'),(205,8,'花乡','0.00'),(206,8,'世界公园','0.00'),(207,8,'科技园区','0.00'),(208,8,'北大地','0.00'),(209,8,'七里庄','0.00'),(210,8,'丰台路','0.00'),(211,8,'丰台体育馆','0.00'),(212,8,'嘉园','0.00'),(213,8,'岳各庄','0.00'),(214,8,'青塔','0.00'),(215,8,'五里店','0.00'),(216,8,'卢沟桥','0.00'),(217,8,'长辛店','0.00'),(218,8,'云岗','0.00'),(219,8,'其他','0.00'),(220,9,'玉泉路','0.00'),(221,9,'老山','0.00'),(222,9,'八宝山','0.00'),(223,9,'鲁谷','0.00'),(224,9,'衙门口','0.00'),(225,9,'八角','0.00'),(226,9,'古城','0.00'),(227,9,'杨庄','0.00'),(228,9,'苹果园','0.00'),(229,9,'金顶街','0.00'),(230,9,'模式口','0.00'),(231,9,'西山','0.00'),(232,9,'八大处','0.00'),(233,9,'五里坨','0.00'),(234,9,'广宁','0.00'),(235,9,'其他','0.00'),(236,10,'龙泽','0.00'),(237,10,'回龙观','0.00'),(238,10,'霍营','0.00'),(239,10,'立水桥','0.00'),(240,10,'天通苑','0.00'),(241,10,'北七家','0.00'),(242,10,'沙河镇','0.00'),(243,10,'昌平县城','0.00'),(244,10,'城北','0.00'),(245,10,'城南','0.00'),(246,10,'南口','0.00'),(247,10,'马池口','0.00'),(248,10,'阳坊','0.00'),(249,10,'百善','0.00'),(250,10,'小汤山','0.00'),(251,10,'兴寿','0.00'),(252,10,'南邵','0.00'),(253,10,'十三陵','0.00'),(254,10,'长陵','0.00'),(255,10,'其他','0.00'),(256,11,'北关环岛','0.00'),(257,11,'新华大街','0.00'),(258,11,'北苑','0.00'),(259,11,'果园','0.00'),(260,11,'九棵树','0.00'),(261,11,'梨园','0.00'),(262,11,'梨园城铁','0.00'),(263,11,'临河里','0.00'),(264,11,'土桥','0.00'),(265,11,'玉桥','0.00'),(266,11,'乔庄','0.00'),(267,11,'武夷花园','0.00'),(268,11,'潞城','0.00'),(269,11,'马驹桥','0.00'),(270,11,'其他','0.00'),(271,12,'黄村','0.00'),(272,12,'西红门','0.00'),(273,12,'旧宫','0.00'),(274,12,'亦庄','0.00'),(275,12,'庞各庄','0.00'),(276,12,'其他','0.00'),(277,13,'后沙峪','0.00'),(278,13,'胜利','0.00'),(279,13,'光明','0.00'),(280,13,'石园','0.00'),(281,13,'仁和','0.00'),(282,13,'李桥','0.00'),(283,13,'机场','0.00'),(284,13,'天竺','0.00'),(285,13,'新国展','0.00'),(286,13,'马坡','0.00'),(287,13,'南彩','0.00'),(288,13,'杨镇','0.00'),(289,13,'其他','0.00'),(290,14,'长阳','0.00'),(291,14,'良乡','0.00'),(292,14,'阎村','0.00'),(293,14,'窦店','0.00'),(294,14,'房山城关','0.00'),(295,14,'迎风','0.00'),(296,14,'韩村河','0.00'),(297,14,'其他','0.00'),(298,15,'密云','0.00'),(299,15,'十里堡','0.00'),(300,15,'溪翁庄','0.00'),(301,15,'穆家峪','0.00'),(302,15,'太师屯','0.00'),(303,15,'北庄','0.00'),(304,15,'新城子','0.00'),(305,15,'古北口','0.00'),(306,15,'不老屯','0.00'),(307,15,'其他','0.00'),(308,16,'大峪','0.00'),(309,16,'城子街道','0.00'),(310,16,'东辛房','0.00'),(311,16,'龙泉','0.00'),(312,16,'永定','0.00'),(313,16,'潭柘寺','0.00'),(314,16,'军庄','0.00'),(315,16,'妙峰山','0.00'),(316,16,'清水','0.00'),(317,16,'其他','0.00'),(318,17,'怀柔','0.00'),(319,17,'泉河','0.00'),(320,17,'庙城','0.00'),(321,17,'杨宋','0.00'),(322,17,'北房','0.00'),(323,17,'雁栖','0.00'),(324,17,'怀北','0.00'),(325,17,'渤海镇','0.00'),(326,17,'桥梓','0.00'),(327,17,'九渡河','0.00'),(328,17,'汤河口','0.00'),(329,17,'其他','0.00'),(330,18,'平谷镇','0.00'),(331,18,'滨河','0.00'),(332,18,'兴谷','0.00'),(333,18,'渔阳','0.00'),(334,18,'王辛庄','0.00'),(335,18,'东高村','0.00'),(336,18,'马昌营','0.00'),(337,18,'峪口','0.00'),(338,18,'刘家店','0.00'),(339,18,'金海湖','0.00'),(340,18,'黄松峪','0.00'),(341,18,'熊儿寨','0.00'),(342,18,'镇罗营','0.00'),(343,18,'其他','0.00'),(344,19,'延庆','0.00'),(345,19,'康庄','0.00'),(346,19,'八达岭','0.00'),(347,19,'大榆树','0.00'),(348,19,'永宁','0.00'),(349,19,'其他','0.00'),(350,20,'燕郊','0.00');
/*!40000 ALTER TABLE `TKAreaUrban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKCardActivityRegistration`
--

DROP TABLE IF EXISTS `TKCardActivityRegistration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKCardActivityRegistration` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cardId` bigint(20) DEFAULT NULL,
  `regUserId` bigint(20) DEFAULT NULL,
  `regDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `regExitDateTime` datetime DEFAULT NULL,
  `state` int(11) DEFAULT '1' COMMENT '会员报名状态\r\n            0 - 退出\r\n            1 - 已报名',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`cardId`,`regUserId`,`state`,`regDateTime`),
  KEY `FK_UserInfo_CardActivityReg` (`regUserId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKCardActivityRegistration`
--

LOCK TABLES `TKCardActivityRegistration` WRITE;
/*!40000 ALTER TABLE `TKCardActivityRegistration` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKCardActivityRegistration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKCardExchLog`
--

DROP TABLE IF EXISTS `TKCardExchLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKCardExchLog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `cardId` bigint(20) DEFAULT NULL,
  `exchDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usePoint` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`,`cardId`,`exchDateTime`),
  KEY `FK_CardExchange_CardId` (`cardId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员卡竞换记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKCardExchLog`
--

LOCK TABLES `TKCardExchLog` WRITE;
/*!40000 ALTER TABLE `TKCardExchLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKCardExchLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKCardForActivity`
--

DROP TABLE IF EXISTS `TKCardForActivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKCardForActivity` (
  `id` bigint(20) NOT NULL,
  `matter` varchar(100) DEFAULT NULL COMMENT '备注',
  `characteristic` varchar(200) DEFAULT NULL COMMENT '活动特点',
  `detail` varchar(500) DEFAULT NULL COMMENT '具体细则',
  `tel` varchar(20) DEFAULT NULL,
  `QQ` varchar(15) DEFAULT NULL,
  `state` int(11) DEFAULT NULL COMMENT '活动状态\r\n            0 - 人数未满\r\n            1 - 人数已满\r\n            2 - 活动结束\r\n            3 - 注销',
  `cardImagePath` varchar(50) DEFAULT NULL,
  `startDate` datetime DEFAULT NULL COMMENT '发起时间',
  `endDate` datetime DEFAULT NULL,
  `limitUser` int(11) DEFAULT '0',
  `closeDate` datetime DEFAULT NULL,
  `areaDistrictId` bigint(20) DEFAULT NULL,
  `areaUrbanId` bigint(20) DEFAULT NULL,
  `areaIdPath` varchar(500) DEFAULT NULL COMMENT '地点路径',
  `areaNamePath` varchar(500) DEFAULT NULL COMMENT '地点路径',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='卡拼卡活动卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKCardForActivity`
--

LOCK TABLES `TKCardForActivity` WRITE;
/*!40000 ALTER TABLE `TKCardForActivity` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKCardForActivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKCardForExchange`
--

DROP TABLE IF EXISTS `TKCardForExchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKCardForExchange` (
  `id` bigint(20) NOT NULL,
  `cardType` varchar(50) DEFAULT NULL COMMENT '卡的种类\r\n            1 - 餐饮\r\n            2 - 购物\r\n            3 - 丽人\r\n            4 - 休闲\r\n            5 - 运动\r\n            6 - 旅游',
  `cardUse` varchar(50) DEFAULT NULL COMMENT '卡的用途\r\n            1 - 打折\r\n            2 - 会员\r\n            3 - 提货卡\r\n            4 - 储值\r\n            5 - 积分\r\n            6 - 体验卡\r\n            7 - VIP会员卡',
  `cardTtransactions` varchar(50) DEFAULT NULL COMMENT '卡的交易\r\n            1 - 储值卡\r\n            2 - 提货卡\r\n            3 - 礼品卡\r\n            ',
  `areaDistrictId` bigint(20) DEFAULT NULL,
  `areaUrbanId` bigint(20) DEFAULT NULL,
  `areaIdPath` varchar(500) DEFAULT NULL COMMENT '地点路径',
  `areaNamePath` varchar(500) DEFAULT NULL COMMENT '地点路径',
  `period` datetime DEFAULT NULL COMMENT '有效期',
  `wayFight` varchar(50) DEFAULT NULL COMMENT '拼卡方式\r\n            1 - 打折\r\n            2 - 积分 \r\n            ',
  `remarks` varchar(500) DEFAULT NULL COMMENT '备注',
  `exchangPoint` int(11) DEFAULT '0' COMMENT '兑换卡消费积分值',
  `surplusCount` int(11) DEFAULT '0' COMMENT 'v',
  `isSponsors` int(11) DEFAULT '0' COMMENT '是否在赞助商区域\r\n            1 - 是\r\n            0 - 不是',
  `cardImagePath` varchar(50) DEFAULT NULL,
  `state` int(11) DEFAULT '1' COMMENT '是否发布\r\n            0 - 不发布\r\n            1 - 已发布',
  `orderNum` decimal(7,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='卡兑换卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKCardForExchange`
--

LOCK TABLES `TKCardForExchange` WRITE;
/*!40000 ALTER TABLE `TKCardForExchange` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKCardForExchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKCardForSale`
--

DROP TABLE IF EXISTS `TKCardForSale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKCardForSale` (
  `id` bigint(20) NOT NULL,
  `cardType` varchar(50) DEFAULT NULL COMMENT '卡的种类\r\n            1 - 餐饮\r\n            2 - 购物\r\n            3 - 丽人\r\n            4 - 休闲\r\n            5 - 运动\r\n            6 - 旅游',
  `cardUse` varchar(50) DEFAULT NULL COMMENT '卡的用途\r\n            1 - 打折\r\n            2 - 会员\r\n            3 - 提货卡\r\n            4 - 储值\r\n            5 - 积分\r\n            6 - 体验卡\r\n            7 - VIP会员卡',
  `cardTtransactions` varchar(50) DEFAULT NULL COMMENT '卡的交易\r\n            1 - 储值卡\r\n            2 - 提货卡\r\n            3 - 礼品卡\r\n            ',
  `areaDistrictId` bigint(20) DEFAULT NULL,
  `areaUrbanId` bigint(20) DEFAULT NULL,
  `areaIdPath` varchar(500) DEFAULT NULL COMMENT '地点路径',
  `areaNamePath` varchar(500) DEFAULT NULL COMMENT '地点路径',
  `period` datetime DEFAULT NULL COMMENT '有效期',
  `wayFight` varchar(50) DEFAULT NULL COMMENT '拼卡方式\r\n            1 - 打折\r\n            2 - 积分 \r\n            ',
  `remarks` varchar(500) DEFAULT NULL COMMENT '备注',
  `cardImagePath` varchar(50) DEFAULT NULL,
  `price` decimal(6,2) DEFAULT '0.00',
  `sellingPrice` decimal(6,2) DEFAULT '0.00',
  `state` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='卡买卖类卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKCardForSale`
--

LOCK TABLES `TKCardForSale` WRITE;
/*!40000 ALTER TABLE `TKCardForSale` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKCardForSale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKCardForShow`
--

DROP TABLE IF EXISTS `TKCardForShow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKCardForShow` (
  `id` bigint(20) NOT NULL,
  `cardType` varchar(50) DEFAULT NULL COMMENT '卡的种类\r\n            1 - 餐饮\r\n            2 - 购物\r\n            3 - 丽人\r\n            4 - 休闲\r\n            5 - 运动\r\n            6 - 旅游',
  `cardUse` varchar(50) DEFAULT NULL COMMENT '卡的用途\r\n            1 - 打折\r\n            2 - 会员\r\n            3 - 提货卡\r\n            4 - 储值\r\n            5 - 积分\r\n            6 - 体验卡\r\n            7 - VIP会员卡',
  `cardTtransactions` varchar(50) DEFAULT NULL COMMENT '卡的交易\r\n            1 - 储值卡\r\n            2 - 提货卡\r\n            3 - 礼品卡\r\n            ',
  `areaDistrictId` bigint(20) DEFAULT NULL,
  `areaUrbanId` bigint(20) DEFAULT NULL,
  `areaIdPath` varchar(500) DEFAULT NULL COMMENT '地点路径',
  `areaNamePath` varchar(500) DEFAULT NULL COMMENT '地点路径',
  `period` datetime DEFAULT NULL COMMENT '有效期',
  `wayFight` varchar(50) DEFAULT NULL COMMENT '拼卡方式\r\n            1 - 打折\r\n            2 - 积分 \r\n            ',
  `remarks` varchar(500) DEFAULT NULL COMMENT '备注',
  `cardImagePath` varchar(50) DEFAULT NULL,
  `price` decimal(6,2) DEFAULT '0.00',
  `sellingPrice` decimal(6,2) DEFAULT '0.00',
  `state` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='卡买展示卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKCardForShow`
--

LOCK TABLES `TKCardForShow` WRITE;
/*!40000 ALTER TABLE `TKCardForShow` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKCardForShow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKCardIndex`
--

DROP TABLE IF EXISTS `TKCardIndex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKCardIndex` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `addDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userId` bigint(20) DEFAULT NULL,
  `operatorFrom` int(11) DEFAULT NULL COMMENT '添加人来自\r\n            1 - 会员\r\n            2 - 网站管理员',
  `cardSetType` int(11) DEFAULT NULL COMMENT '卡秀种类\r\n            1 - 卡买卖类\r\n            2 - 卡展示类\r\n            3 - 卡活动类\r\n            4 - 卡兑换类',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`name`,`addDateTime`,`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='卡索引表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKCardIndex`
--

LOCK TABLES `TKCardIndex` WRITE;
/*!40000 ALTER TABLE `TKCardIndex` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKCardIndex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKCardUserMessage`
--

DROP TABLE IF EXISTS `TKCardUserMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKCardUserMessage` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `cardId` bigint(20) DEFAULT NULL,
  `content` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `addDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` int(11) DEFAULT '1' COMMENT '留言状态\r\n            1 - 正常\r\n            0 - 注销',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`,`cardId`,`addDateTime`,`state`),
  KEY `FK_CardMessage_Card` (`cardId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKCardUserMessage`
--

LOCK TABLES `TKCardUserMessage` WRITE;
/*!40000 ALTER TABLE `TKCardUserMessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKCardUserMessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKShopping`
--

DROP TABLE IF EXISTS `TKShopping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKShopping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `shopName` varchar(50) DEFAULT NULL,
  `urbanId` bigint(20) DEFAULT NULL,
  `reActivityOrderNum` decimal(4,0) DEFAULT '0' COMMENT '最新活动中推荐排序\r\n            0 - 不是推荐\r\n            非0 - 是推荐，又是排序值',
  `reDiscountOrderNum` decimal(4,0) DEFAULT '0' COMMENT '打折快报中推荐排序\r\n            0 - 不是推荐\r\n            非0 - 是推荐，又是排序值',
  `reConversionOrderNum` decimal(4,0) DEFAULT '0' COMMENT '兑换通知中推荐排序\r\n            0 - 不是推荐\r\n            非0 - 是推荐，又是排序值',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`urbanId`,`reActivityOrderNum`,`reDiscountOrderNum`,`reConversionOrderNum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商场列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKShopping`
--

LOCK TABLES `TKShopping` WRITE;
/*!40000 ALTER TABLE `TKShopping` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKShopping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKShoppingNews`
--

DROP TABLE IF EXISTS `TKShoppingNews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKShoppingNews` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `newsTitle` varchar(100) DEFAULT NULL,
  `newsContent` text,
  `newsSummary` varchar(500) DEFAULT NULL,
  `shopId` bigint(20) DEFAULT NULL,
  `urbanId` bigint(20) DEFAULT NULL,
  `state` int(11) DEFAULT NULL COMMENT '新闻状态\r\n            0 - 注销\r\n            1 - 启用',
  `orderNum` decimal(5,2) DEFAULT '0.00',
  `adminId` bigint(20) DEFAULT NULL,
  `addDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `newsType` int(11) DEFAULT NULL COMMENT '新闻类型\r\n            1 - 最新活动\r\n            2 - 打折快报\r\n            3 - 兑换通知',
  `startDate` datetime DEFAULT NULL COMMENT '活动开始时间',
  `endDate` datetime DEFAULT NULL COMMENT '活动结束时间',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`newsTitle`,`state`,`newsType`,`orderNum`),
  KEY `FK_ShopNews_Admin` (`adminId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='新闻信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKShoppingNews`
--

LOCK TABLES `TKShoppingNews` WRITE;
/*!40000 ALTER TABLE `TKShoppingNews` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKShoppingNews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserBlogMessages`
--

DROP TABLE IF EXISTS `TKUserBlogMessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserBlogMessages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `addDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` int(11) DEFAULT '1' COMMENT '审核状态\r\n            0 - 注销\r\n            1 - 启用',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`,`addDateTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员微博消息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserBlogMessages`
--

LOCK TABLES `TKUserBlogMessages` WRITE;
/*!40000 ALTER TABLE `TKUserBlogMessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKUserBlogMessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserFriends`
--

DROP TABLE IF EXISTS `TKUserFriends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserFriends` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `friendUserId` bigint(20) DEFAULT NULL,
  `addDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`,`friendUserId`),
  KEY `FK_User_Friends_Friends` (`friendUserId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员好友';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserFriends`
--

LOCK TABLES `TKUserFriends` WRITE;
/*!40000 ALTER TABLE `TKUserFriends` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKUserFriends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserGrade`
--

DROP TABLE IF EXISTS `TKUserGrade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserGrade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_bin NOT NULL,
  `accumulativePoint` int(11) NOT NULL DEFAULT '0',
  `updateDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_1` (`id`,`name`,`accumulativePoint`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserGrade`
--

LOCK TABLES `TKUserGrade` WRITE;
/*!40000 ALTER TABLE `TKUserGrade` DISABLE KEYS */;
INSERT INTO `TKUserGrade` VALUES (1,'会员级',0,'2011-08-02 15:49:00'),(2,'VIP级',1000,'2011-08-02 15:49:00'),(3,'翡翠级',10000,'2011-08-02 15:49:00'),(4,'钻石级',100000,'2011-08-02 15:49:00'),(5,'至尊级',1000000,'2011-08-02 15:49:00'),(6,'KASHOW级',10000000,'2011-08-02 15:49:00');
/*!40000 ALTER TABLE `TKUserGrade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserInfo`
--

DROP TABLE IF EXISTS `TKUserInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserInfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '会员编号',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称',
  `kLoginName` varchar(50) NOT NULL COMMENT '会员用户名',
  `kPWD` varchar(200) DEFAULT NULL,
  `kMail` varchar(50) DEFAULT NULL,
  `kTel` varchar(50) DEFAULT NULL,
  `kPointsAccumulative` int(11) DEFAULT '0' COMMENT '会员累计积分',
  `kPoints` int(11) DEFAULT '0',
  `gradeId` int(11) DEFAULT NULL COMMENT '会员当前等级',
  `kState` int(11) DEFAULT '0' COMMENT '会员状态\r\n            0 - 已注册未验证\r\n            1 - 已注册已验证\r\n            2 - 注销',
  `reUserId` bigint(20) DEFAULT NULL,
  `reUserLoginName` varchar(50) DEFAULT NULL COMMENT '推荐人用户名',
  `registrationDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `loginDateTime` datetime DEFAULT NULL COMMENT '登录时间',
  `exitDateTime` datetime DEFAULT NULL COMMENT '退出时间',
  `verifyDateTime` datetime DEFAULT NULL,
  `verifyEncode` varchar(40) DEFAULT NULL COMMENT '注册时生成的邮件验证码\r\n            验证通过后，清空该验证码',
  `birthday` datetime DEFAULT NULL COMMENT '生日',
  `area` varchar(200) DEFAULT NULL COMMENT '所在地区',
  `QQ` varchar(15) DEFAULT NULL,
  `kAvatarImage` varchar(50) DEFAULT NULL COMMENT '会员头像',
  `MSN` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_1` (`kLoginName`),
  UNIQUE KEY `Index_2` (`nickname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserInfo`
--

LOCK TABLES `TKUserInfo` WRITE;
/*!40000 ALTER TABLE `TKUserInfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKUserInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserMessages`
--

DROP TABLE IF EXISTS `TKUserMessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserMessages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `toUserId` bigint(20) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `addDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` int(11) DEFAULT '1' COMMENT '审核状态\r\n            0 - 注销\r\n            1 - 启用',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`,`toUserId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员站内消息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserMessages`
--

LOCK TABLES `TKUserMessages` WRITE;
/*!40000 ALTER TABLE `TKUserMessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKUserMessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserNews`
--

DROP TABLE IF EXISTS `TKUserNews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserNews` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `newsContent` varchar(100) DEFAULT NULL,
  `addDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`,`addDateTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员最新动态';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserNews`
--

LOCK TABLES `TKUserNews` WRITE;
/*!40000 ALTER TABLE `TKUserNews` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKUserNews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserOperLog`
--

DROP TABLE IF EXISTS `TKUserOperLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserOperLog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `operType` int(11) DEFAULT NULL,
  `operDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tid` bigint(20) DEFAULT NULL,
  `tname` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`,`operDateTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员网站操作日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserOperLog`
--

LOCK TABLES `TKUserOperLog` WRITE;
/*!40000 ALTER TABLE `TKUserOperLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKUserOperLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserOperType`
--

DROP TABLE IF EXISTS `TKUserOperType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserOperType` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cname` varchar(50) DEFAULT NULL,
  `gradeId` int(11) NOT NULL COMMENT '会员等级编号',
  `operType` int(11) NOT NULL COMMENT '以下是具体操作\r\n            =',
  `plannedPoints` int(11) DEFAULT '0' COMMENT '计划增减积分值\r\n            有正有负',
  `updateDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`gradeId`,`operType`)
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 COMMENT='网站操作分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserOperType`
--

LOCK TABLES `TKUserOperType` WRITE;
/*!40000 ALTER TABLE `TKUserOperType` DISABLE KEYS */;
INSERT INTO `TKUserOperType` VALUES (1,'注册',1,1,10,'2011-08-02 15:49:00'),(2,'注册',2,1,10,'2011-08-02 15:49:00'),(3,'注册',3,1,10,'2011-08-02 15:49:00'),(4,'注册',4,1,10,'2011-08-02 15:49:00'),(5,'注册',5,1,10,'2011-08-02 15:49:00'),(6,'注册',6,1,10,'2011-08-02 15:49:00'),(7,'验证未通过',1,2,0,'2011-08-02 15:49:00'),(8,'验证未通过',2,2,0,'2011-08-02 15:49:00'),(9,'验证未通过',3,2,0,'2011-08-02 15:49:00'),(10,'验证未通过',4,2,0,'2011-08-02 15:49:00'),(11,'验证未通过',5,2,0,'2011-08-02 15:49:00'),(12,'验证未通过',6,2,0,'2011-08-02 15:49:00'),(13,'验证通过',1,3,20,'2011-08-02 15:49:00'),(14,'验证通过',2,3,20,'2011-08-02 15:49:00'),(15,'验证通过',3,3,20,'2011-08-02 15:49:00'),(16,'验证通过',4,3,20,'2011-08-02 15:49:00'),(17,'验证通过',5,3,20,'2011-08-02 15:49:00'),(18,'验证通过',6,3,20,'2011-08-02 15:49:00'),(19,'成功登录',1,4,0,'2011-08-02 15:49:00'),(20,'成功登录',2,4,0,'2011-08-02 15:49:00'),(21,'成功登录',3,4,0,'2011-08-02 15:49:00'),(22,'成功登录',4,4,0,'2011-08-02 15:49:00'),(23,'成功登录',5,4,0,'2011-08-02 15:49:00'),(24,'成功登录',6,4,0,'2011-08-02 15:49:00'),(25,'退出网站',1,5,0,'2011-08-02 15:49:00'),(26,'退出网站',2,5,0,'2011-08-02 15:49:00'),(27,'退出网站',3,5,0,'2011-08-02 15:49:00'),(28,'退出网站',4,5,0,'2011-08-02 15:49:00'),(29,'退出网站',5,5,0,'2011-08-02 15:49:00'),(30,'退出网站',6,5,0,'2011-08-02 15:49:00'),(31,'上传头像',1,6,0,'2011-08-02 15:49:00'),(32,'上传头像',2,6,0,'2011-08-02 15:49:00'),(33,'上传头像',3,6,0,'2011-08-02 15:49:00'),(34,'上传头像',4,6,0,'2011-08-02 15:49:00'),(35,'上传头像',5,6,0,'2011-08-02 15:49:00'),(36,'上传头像',6,6,0,'2011-08-02 15:49:00'),(37,'发送站内消息',1,7,0,'2011-08-02 15:49:00'),(38,'发送站内消息',2,7,0,'2011-08-02 15:49:00'),(39,'发送站内消息',3,7,0,'2011-08-02 15:49:00'),(40,'发送站内消息',4,7,0,'2011-08-02 15:49:00'),(41,'发送站内消息',5,7,0,'2011-08-02 15:49:00'),(42,'发送站内消息',6,7,0,'2011-08-02 15:49:00'),(43,'加好友关注',1,8,0,'2011-08-02 15:49:00'),(44,'加好友关注',2,8,0,'2011-08-02 15:49:00'),(45,'加好友关注',3,8,0,'2011-08-02 15:49:00'),(46,'加好友关注',4,8,0,'2011-08-02 15:49:00'),(47,'加好友关注',5,8,0,'2011-08-02 15:49:00'),(48,'加好友关注',6,8,0,'2011-08-02 15:49:00'),(49,'添加新卡',1,9,0,'2011-08-02 15:49:00'),(50,'添加新卡',2,9,0,'2011-08-02 15:49:00'),(51,'添加新卡',3,9,0,'2011-08-02 15:49:00'),(52,'添加新卡',4,9,0,'2011-08-02 15:49:00'),(53,'添加新卡',5,9,0,'2011-08-02 15:49:00'),(54,'添加新卡',6,9,0,'2011-08-02 15:49:00'),(55,'发起活动',1,10,0,'2011-08-02 15:49:00'),(56,'发起活动',2,10,0,'2011-08-02 15:49:00'),(57,'发起活动',3,10,0,'2011-08-02 15:49:00'),(58,'发起活动',4,10,0,'2011-08-02 15:49:00'),(59,'发起活动',5,10,0,'2011-08-02 15:49:00'),(60,'发起活动',6,10,0,'2011-08-02 15:49:00'),(61,'参与活动',1,11,0,'2011-08-02 15:49:00'),(62,'参与活动',2,11,0,'2011-08-02 15:49:00'),(63,'参与活动',3,11,0,'2011-08-02 15:49:00'),(64,'参与活动',4,11,0,'2011-08-02 15:49:00'),(65,'参与活动',5,11,0,'2011-08-02 15:49:00'),(66,'参与活动',6,11,0,'2011-08-02 15:49:00'),(67,'退出活动',1,12,0,'2011-08-02 15:49:00'),(68,'退出活动',2,12,0,'2011-08-02 15:49:00'),(69,'退出活动',3,12,0,'2011-08-02 15:49:00'),(70,'退出活动',4,12,0,'2011-08-02 15:49:00'),(71,'退出活动',5,12,0,'2011-08-02 15:49:00'),(72,'退出活动',6,12,0,'2011-08-02 15:49:00'),(73,'成功买卡',1,13,0,'2011-08-02 15:49:00'),(74,'成功买卡',2,13,0,'2011-08-02 15:49:00'),(75,'成功买卡',3,13,0,'2011-08-02 15:49:00'),(76,'成功买卡',4,13,0,'2011-08-02 15:49:00'),(77,'成功买卡',5,13,0,'2011-08-02 15:49:00'),(78,'成功买卡',6,13,0,'2011-08-02 15:49:00'),(79,'对卡发表评论',1,14,0,'2011-08-02 15:49:00'),(80,'对卡发表评论',2,14,0,'2011-08-02 15:49:00'),(81,'对卡发表评论',3,14,0,'2011-08-02 15:49:00'),(82,'对卡发表评论',4,14,0,'2011-08-02 15:49:00'),(83,'对卡发表评论',5,14,0,'2011-08-02 15:49:00'),(84,'对卡发表评论',6,14,0,'2011-08-02 15:49:00'),(85,'积分兑换卡',1,15,0,'2011-08-02 15:49:00'),(86,'积分兑换卡',2,15,0,'2011-08-02 15:49:00'),(87,'积分兑换卡',3,15,0,'2011-08-02 15:49:00'),(88,'积分兑换卡',4,15,0,'2011-08-02 15:49:00'),(89,'积分兑换卡',5,15,0,'2011-08-02 15:49:00'),(90,'积分兑换卡',6,15,0,'2011-08-02 15:49:00'),(91,'发微博',1,16,0,'2011-08-02 15:49:00'),(92,'发微博',2,16,0,'2011-08-02 15:49:00'),(93,'发微博',3,16,0,'2011-08-02 15:49:00'),(94,'发微博',4,16,0,'2011-08-02 15:49:00'),(95,'发微博',5,16,0,'2011-08-02 15:49:00'),(96,'发微博',6,16,0,'2011-08-02 15:49:00'),(97,'分享拼卡活动给全部好友',1,17,0,'2011-08-02 15:49:00'),(98,'分享拼卡活动给全部好友',2,17,0,'2011-08-02 15:49:00'),(99,'分享拼卡活动给全部好友',3,17,0,'2011-08-02 15:49:00'),(100,'分享拼卡活动给全部好友',4,17,0,'2011-08-02 15:49:00'),(101,'分享拼卡活动给全部好友',5,17,0,'2011-08-02 15:49:00'),(102,'分享拼卡活动给全部好友',6,17,0,'2011-08-02 15:49:00'),(103,'分享拼卡活动给某个好友',1,18,0,'2011-08-02 15:49:00'),(104,'分享拼卡活动给某个好友',2,18,0,'2011-08-02 15:49:00'),(105,'分享拼卡活动给某个好友',3,18,0,'2011-08-02 15:49:00'),(106,'分享拼卡活动给某个好友',4,18,0,'2011-08-02 15:49:00'),(107,'分享拼卡活动给某个好友',5,18,0,'2011-08-02 15:49:00'),(108,'分享拼卡活动给某个好友',6,18,0,'2011-08-02 15:49:00');
/*!40000 ALTER TABLE `TKUserOperType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserPointsChanges`
--

DROP TABLE IF EXISTS `TKUserPointsChanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserPointsChanges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `pointChange` int(11) DEFAULT NULL,
  `changeDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operTypeId` int(11) DEFAULT NULL,
  `operTypeName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员积分变更表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserPointsChanges`
--

LOCK TABLES `TKUserPointsChanges` WRITE;
/*!40000 ALTER TABLE `TKUserPointsChanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKUserPointsChanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKUserStatistics`
--

DROP TABLE IF EXISTS `TKUserStatistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKUserStatistics` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) DEFAULT NULL,
  `statisticType` int(11) DEFAULT NULL COMMENT '统计名称类别\r\n            0 - 拥有卡的数量\r\n            1 - 拥有卡的种类\r\n            2 - 交易记录数\r\n            3 - 拼卡发起记录\r\n            4 - 兑换记录\r\n            5 - 关注我\r\n            6 - 我关注\r\n            7 - 拼卡活动正在进行数\r\n            8 - 拼卡活动报名人数\r\n            9 - 微博数',
  `staticValue` int(11) DEFAULT '0',
  `updateDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `Index_1` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员网站统计记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKUserStatistics`
--

LOCK TABLES `TKUserStatistics` WRITE;
/*!40000 ALTER TABLE `TKUserStatistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKUserStatistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKWebAnnouncement`
--

DROP TABLE IF EXISTS `TKWebAnnouncement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKWebAnnouncement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `adminId` bigint(20) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `updateDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` int(11) DEFAULT '1' COMMENT '1 - 启用\r\n            0 - 注销（历史公告）',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`adminId`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='网站公告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKWebAnnouncement`
--

LOCK TABLES `TKWebAnnouncement` WRITE;
/*!40000 ALTER TABLE `TKWebAnnouncement` DISABLE KEYS */;
/*!40000 ALTER TABLE `TKWebAnnouncement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TKWebBaseInfo`
--

DROP TABLE IF EXISTS `TKWebBaseInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TKWebBaseInfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `infoType` varchar(40) DEFAULT NULL,
  `count` int(11) DEFAULT '0' COMMENT '存储数字类值',
  `value1` varchar(100) DEFAULT NULL,
  `value2` varchar(100) DEFAULT NULL COMMENT '存储字符类值',
  `value3` varchar(100) DEFAULT NULL,
  `updateDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `orderNum` decimal(5,2) DEFAULT NULL,
  `remark` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='存储网站自定义数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TKWebBaseInfo`
--

LOCK TABLES `TKWebBaseInfo` WRITE;
/*!40000 ALTER TABLE `TKWebBaseInfo` DISABLE KEYS */;
INSERT INTO `TKWebBaseInfo` VALUES (1,'WebTotcalCZ',0,NULL,NULL,NULL,'2011-07-16 16:00:00','0.00','储值卡数'),(2,'WebTotcalJF',0,NULL,NULL,NULL,'2011-07-16 16:00:00','0.00','积分卡数'),(3,'WebTotcalHY',0,NULL,NULL,NULL,'2011-07-16 16:00:00','0.00','会员卡数'),(4,'WebTotcalTY',0,NULL,NULL,NULL,'2011-07-16 16:00:00','0.00','体验卡数'),(5,'WebTotcalTH',0,NULL,NULL,NULL,'2011-07-16 16:00:00','0.00','提货卡数'),(6,'WebTotcalUser',0,NULL,NULL,NULL,'2011-07-16 16:00:00','0.00','网站注册会员数'),(7,'WebTotcalVerifiedUser',0,NULL,NULL,NULL,'2011-07-16 16:00:00','0.00','网站已验证会员数'),(8,'AdSitesIndex',0,NULL,NULL,NULL,'2011-07-16 16:00:00','1.00','首页FLASH'),(9,'AdSitesIndex',0,NULL,NULL,NULL,'2011-07-16 16:00:00','2.00','首页FLASH'),(10,'AdSitesIndex',0,NULL,NULL,NULL,'2011-07-16 16:00:00','3.00','首页FLASH'),(11,'IndexFlashTop1',0,NULL,NULL,NULL,'2011-07-16 16:00:00','0.00','广告位1');
/*!40000 ALTER TABLE `TKWebBaseInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TPermissionDataPurview`
--

DROP TABLE IF EXISTS `TPermissionDataPurview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TPermissionDataPurview` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '员工数据权限编码。',
  `adminId` varchar(50) NOT NULL COMMENT '员工编码。',
  `operationTypeId` bigint(20) NOT NULL COMMENT '操作类型编码。',
  `resourceId` varchar(50) NOT NULL COMMENT '资源编码。',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_1` (`adminId`,`operationTypeId`,`resourceId`),
  KEY `FK_OperationType_DataPurview` (`operationTypeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员数据权限。';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TPermissionDataPurview`
--

LOCK TABLES `TPermissionDataPurview` WRITE;
/*!40000 ALTER TABLE `TPermissionDataPurview` DISABLE KEYS */;
/*!40000 ALTER TABLE `TPermissionDataPurview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TPermissionManagement_Purview`
--

DROP TABLE IF EXISTS `TPermissionManagement_Purview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TPermissionManagement_Purview` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '权限编码。',
  `code` varchar(50) NOT NULL COMMENT '权限标识。',
  `name` varchar(50) NOT NULL COMMENT '权限名称。',
  `parentId` bigint(20) NOT NULL DEFAULT '1' COMMENT '上级权限编码。',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注。',
  PRIMARY KEY (`id`),
  KEY `Index_1` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='权限表。';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TPermissionManagement_Purview`
--

LOCK TABLES `TPermissionManagement_Purview` WRITE;
/*!40000 ALTER TABLE `TPermissionManagement_Purview` DISABLE KEYS */;
/*!40000 ALTER TABLE `TPermissionManagement_Purview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TPermissionManagement_Role`
--

DROP TABLE IF EXISTS `TPermissionManagement_Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TPermissionManagement_Role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色编码。',
  `name` varchar(50) NOT NULL COMMENT '角色名称。',
  `relegationObj` varchar(50) NOT NULL COMMENT '所属对象。',
  `enabled` int(11) NOT NULL DEFAULT '1' COMMENT '是否可用。\r\n            0 - 不可用;\r\n            1 - 可用;',
  `remark` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_1` (`name`,`relegationObj`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='角色表。';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TPermissionManagement_Role`
--

LOCK TABLES `TPermissionManagement_Role` WRITE;
/*!40000 ALTER TABLE `TPermissionManagement_Role` DISABLE KEYS */;
/*!40000 ALTER TABLE `TPermissionManagement_Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TPermissionManagement_RoleAssign`
--

DROP TABLE IF EXISTS `TPermissionManagement_RoleAssign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TPermissionManagement_RoleAssign` (
  `id` varchar(50) NOT NULL COMMENT '编码。',
  `roleId` bigint(20) NOT NULL COMMENT '角色编码。',
  `accessId` varchar(50) NOT NULL,
  `accessType` int(11) NOT NULL COMMENT '1 - 代表员工, accessId记录员工ID;\r\n            2 - 代表职位, accessId记录职位ID;\r\n            ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_1` (`roleId`,`accessId`,`accessType`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='角色分配。';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TPermissionManagement_RoleAssign`
--

LOCK TABLES `TPermissionManagement_RoleAssign` WRITE;
/*!40000 ALTER TABLE `TPermissionManagement_RoleAssign` DISABLE KEYS */;
/*!40000 ALTER TABLE `TPermissionManagement_RoleAssign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TPermissionManagement_RolePurview`
--

DROP TABLE IF EXISTS `TPermissionManagement_RolePurview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TPermissionManagement_RolePurview` (
  `purviewId` bigint(20) NOT NULL COMMENT '权限编码。',
  `roleId` bigint(20) NOT NULL COMMENT '角色编码。',
  PRIMARY KEY (`purviewId`,`roleId`),
  UNIQUE KEY `Index_1` (`purviewId`,`roleId`),
  KEY `FK_TPERMISS_REFERENCE_TPERMISS3` (`roleId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='角色权限表。';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TPermissionManagement_RolePurview`
--

LOCK TABLES `TPermissionManagement_RolePurview` WRITE;
/*!40000 ALTER TABLE `TPermissionManagement_RolePurview` DISABLE KEYS */;
/*!40000 ALTER TABLE `TPermissionManagement_RolePurview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TPermissionOperationType`
--

DROP TABLE IF EXISTS `TPermissionOperationType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TPermissionOperationType` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '操作类型编码。',
  `name` varchar(50) NOT NULL COMMENT '操作类型名称。',
  `purviewId` bigint(20) NOT NULL COMMENT '权限编码。',
  `showMode` int(11) NOT NULL,
  `resourceType` int(11) NOT NULL COMMENT '资源类型。\r\n            1为机构编码。\r\n            2为法人公司编码。',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_1` (`name`,`resourceType`),
  KEY `FK_Purview_OperationType` (`purviewId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='操作类型。\r\n0为显示全部。\r\n1为只显示事业部。';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TPermissionOperationType`
--

LOCK TABLES `TPermissionOperationType` WRITE;
/*!40000 ALTER TABLE `TPermissionOperationType` DISABLE KEYS */;
/*!40000 ALTER TABLE `TPermissionOperationType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `View_ShopArea`
--

DROP TABLE IF EXISTS `View_ShopArea`;
/*!50001 DROP VIEW IF EXISTS `View_ShopArea`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_ShopArea` (
  `id` bigint(20),
  `shopName` varchar(50),
  `reActivityOrderNum` decimal(4,0),
  `reDiscountOrderNum` decimal(4,0),
  `reConversionOrderNum` decimal(4,0),
  `urbanId` bigint(20),
  `urbanName` varchar(20),
  `orderNumUrban` decimal(5,2),
  `districtId` bigint(20),
  `districtName` varchar(20),
  `orderNumDistrict` decimal(5,2)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_ShopNews`
--

DROP TABLE IF EXISTS `View_ShopNews`;
/*!50001 DROP VIEW IF EXISTS `View_ShopNews`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_ShopNews` (
  `id` bigint(20),
  `newsTitle` varchar(100),
  `newsContent` text,
  `addDateTime` timestamp,
  `adminId` bigint(20),
  `state` int(11),
  `newsType` int(11),
  `orderNum` decimal(5,2),
  `newsSummary` varchar(500),
  `startDate` datetime,
  `endDate` datetime,
  `shopId` bigint(20),
  `shopName` varchar(50),
  `reActivityOrderNum` decimal(4,0),
  `reDiscountOrderNum` decimal(4,0),
  `reConversionOrderNum` decimal(4,0),
  `urbanId` bigint(20),
  `urbanName` varchar(20),
  `orderNumUrban` decimal(5,2),
  `districtId` bigint(20),
  `districtName` varchar(20),
  `orderNumDistrict` decimal(5,2)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKCard`
--

DROP TABLE IF EXISTS `View_TKCard`;
/*!50001 DROP VIEW IF EXISTS `View_TKCard`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKCard` (
  `id` bigint(20),
  `name` varchar(200),
  `addDateTime` timestamp,
  `cardSetType` int(11),
  `areaDistrictId` bigint(20),
  `areaUrbanId` bigint(20),
  `districtName` varchar(20),
  `urbanIdName` varchar(20),
  `cardImagePath` varchar(50),
  `state` int(11),
  `value1` decimal(12,2),
  `value2` varbinary(19)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKCardActivityRegistration`
--

DROP TABLE IF EXISTS `View_TKCardActivityRegistration`;
/*!50001 DROP VIEW IF EXISTS `View_TKCardActivityRegistration`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKCardActivityRegistration` (
  `id` bigint(20),
  `cardId` bigint(20),
  `regUserId` bigint(20),
  `regDateTime` timestamp,
  `state` int(11),
  `kLoginName` varchar(50),
  `kPWD` varchar(200),
  `kMail` varchar(50),
  `kTel` varchar(50),
  `kPoints` int(11),
  `kState` int(11),
  `reUserId` bigint(20),
  `reUserLoginName` varchar(50),
  `registrationDateTime` timestamp,
  `loginDateTime` datetime,
  `exitDateTime` datetime,
  `nickname` varchar(50),
  `birthday` datetime,
  `area` varchar(200),
  `QQ` varchar(15),
  `kPointsAccumulative` int(11),
  `kAvatarImage` varchar(50),
  `gradeId` int(11),
  `gradeName` varchar(20),
  `accumulativePoint` int(11),
  `updateDateTime` timestamp
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKCardForActivity`
--

DROP TABLE IF EXISTS `View_TKCardForActivity`;
/*!50001 DROP VIEW IF EXISTS `View_TKCardForActivity`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKCardForActivity` (
  `id` bigint(20),
  `name` varchar(200),
  `addDateTime` timestamp,
  `userId` bigint(20),
  `operatorFrom` int(11),
  `cardSetType` int(11),
  `matter` varchar(100),
  `characteristic` varchar(200),
  `detail` varchar(500),
  `tel` varchar(20),
  `QQ` varchar(15),
  `state` int(11),
  `cardImagePath` varchar(50),
  `startDate` datetime,
  `endDate` datetime,
  `limitUser` int(11),
  `nickname` varchar(50),
  `kAvatarImage` varchar(50),
  `regCount` bigint(21)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKCardForExchange`
--

DROP TABLE IF EXISTS `View_TKCardForExchange`;
/*!50001 DROP VIEW IF EXISTS `View_TKCardForExchange`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKCardForExchange` (
  `id` bigint(20),
  `name` varchar(200),
  `addDateTime` timestamp,
  `userId` bigint(20),
  `operatorFrom` int(11),
  `cardSetType` int(11),
  `cardType` varchar(50),
  `cardUse` varchar(50),
  `cardTtransactions` varchar(50),
  `areaDistrictId` bigint(20),
  `areaUrbanId` bigint(20),
  `areaIdPath` varchar(500),
  `areaNamePath` varchar(500),
  `period` datetime,
  `wayFight` varchar(50),
  `remarks` varchar(500),
  `exchangPoint` int(11),
  `surplusCount` int(11),
  `isSponsors` int(11),
  `cardImagePath` varchar(50),
  `state` int(11),
  `orderNum` decimal(7,2),
  `districtName` varchar(20),
  `urbanName` varchar(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKCardForSale`
--

DROP TABLE IF EXISTS `View_TKCardForSale`;
/*!50001 DROP VIEW IF EXISTS `View_TKCardForSale`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKCardForSale` (
  `id` bigint(20),
  `name` varchar(200),
  `addDateTime` timestamp,
  `userId` bigint(20),
  `operatorFrom` int(11),
  `cardSetType` int(11),
  `cardType` varchar(50),
  `cardUse` varchar(50),
  `cardTtransactions` varchar(50),
  `areaDistrictId` bigint(20),
  `areaUrbanId` bigint(20),
  `areaIdPath` varchar(500),
  `areaNamePath` varchar(500),
  `period` datetime,
  `wayFight` varchar(50),
  `remarks` varchar(500),
  `cardImagePath` varchar(50),
  `price` decimal(6,2),
  `sellingPrice` decimal(6,2),
  `state` int(11),
  `districtName` varchar(20),
  `urbanIdName` varchar(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKCardForShow`
--

DROP TABLE IF EXISTS `View_TKCardForShow`;
/*!50001 DROP VIEW IF EXISTS `View_TKCardForShow`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKCardForShow` (
  `id` bigint(20),
  `name` varchar(200),
  `addDateTime` timestamp,
  `userId` bigint(20),
  `operatorFrom` int(11),
  `cardSetType` int(11),
  `cardType` varchar(50),
  `cardUse` varchar(50),
  `cardTtransactions` varchar(50),
  `areaDistrictId` bigint(20),
  `areaUrbanId` bigint(20),
  `areaIdPath` varchar(500),
  `areaNamePath` varchar(500),
  `period` datetime,
  `wayFight` varchar(50),
  `remarks` varchar(500),
  `cardImagePath` varchar(50),
  `price` decimal(6,2),
  `sellingPrice` decimal(6,2),
  `state` int(11),
  `districtName` varchar(20),
  `urbanIdName` varchar(20)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKCardUserMessage`
--

DROP TABLE IF EXISTS `View_TKCardUserMessage`;
/*!50001 DROP VIEW IF EXISTS `View_TKCardUserMessage`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKCardUserMessage` (
  `id` bigint(20),
  `userId` bigint(20),
  `cardId` bigint(20),
  `content` varchar(500),
  `addDateTime` timestamp,
  `state` int(11),
  `nickname` varchar(50),
  `kAvatarImage` varchar(50)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKUserBlogMessages`
--

DROP TABLE IF EXISTS `View_TKUserBlogMessages`;
/*!50001 DROP VIEW IF EXISTS `View_TKUserBlogMessages`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKUserBlogMessages` (
  `id` bigint(20),
  `userId` bigint(20),
  `content` varchar(500),
  `addDateTime` timestamp,
  `state` int(11),
  `nickname` varchar(50),
  `kAvatarImage` varchar(50)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKUserFriends`
--

DROP TABLE IF EXISTS `View_TKUserFriends`;
/*!50001 DROP VIEW IF EXISTS `View_TKUserFriends`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKUserFriends` (
  `id` bigint(20),
  `userId` bigint(20),
  `friendUserId` bigint(20),
  `addDateTime` timestamp,
  `nickname` varchar(50),
  `kAvatarImage` varchar(50)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKUserOperLog`
--

DROP TABLE IF EXISTS `View_TKUserOperLog`;
/*!50001 DROP VIEW IF EXISTS `View_TKUserOperLog`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKUserOperLog` (
  `id` bigint(20),
  `userId` bigint(20),
  `operType` int(11),
  `operDateTime` timestamp,
  `tid` bigint(20),
  `tname` varchar(500),
  `nickname` varchar(50),
  `kAvatarImage` varchar(50)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_TKUserStatistics`
--

DROP TABLE IF EXISTS `View_TKUserStatistics`;
/*!50001 DROP VIEW IF EXISTS `View_TKUserStatistics`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_TKUserStatistics` (
  `id` bigint(20),
  `userId` bigint(20),
  `statisticType` int(11),
  `staticValue` int(11),
  `updateDateTime` timestamp,
  `nickname` varchar(50),
  `kAvatarImage` varchar(50)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_User`
--

DROP TABLE IF EXISTS `View_User`;
/*!50001 DROP VIEW IF EXISTS `View_User`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_User` (
  `id` bigint(20),
  `kLoginName` varchar(50),
  `kPWD` varchar(200),
  `kMail` varchar(50),
  `kTel` varchar(50),
  `kPoints` int(11),
  `kState` int(11),
  `reUserId` bigint(20),
  `reUserLoginName` varchar(50),
  `registrationDateTime` timestamp,
  `loginDateTime` datetime,
  `exitDateTime` datetime,
  `nickname` varchar(50),
  `birthday` datetime,
  `area` varchar(200),
  `QQ` varchar(15),
  `kPointsAccumulative` int(11),
  `kAvatarImage` varchar(50),
  `MSN` varchar(50),
  `verifyDateTime` datetime,
  `gradeId` int(11),
  `gradeName` varchar(20),
  `accumulativePoint` int(11),
  `updateDateTime` timestamp
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_UserMessages`
--

DROP TABLE IF EXISTS `View_UserMessages`;
/*!50001 DROP VIEW IF EXISTS `View_UserMessages`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_UserMessages` (
  `id` bigint(20),
  `userId` bigint(20),
  `toUserId` bigint(20),
  `content` varchar(500),
  `addDateTime` timestamp,
  `state` int(11),
  `nickname` varchar(50)
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `View_UserPointsChanges`
--

DROP TABLE IF EXISTS `View_UserPointsChanges`;
/*!50001 DROP VIEW IF EXISTS `View_UserPointsChanges`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `View_UserPointsChanges` (
  `id` int(11),
  `userId` bigint(20),
  `pointChange` int(11),
  `changeDateTime` timestamp,
  `operTypeId` int(11),
  `operTypeName` varchar(50),
  `kLoginName` varchar(50),
  `kPWD` varchar(200),
  `kMail` varchar(50),
  `kTel` varchar(50),
  `kPoints` int(11),
  `kState` int(11),
  `reUserId` bigint(20),
  `reUserLoginName` varchar(50),
  `registrationDateTime` timestamp,
  `loginDateTime` datetime,
  `exitDateTime` datetime,
  `nickname` varchar(50),
  `birthday` datetime,
  `area` varchar(200),
  `QQ` varchar(15),
  `kPointsAccumulative` int(11),
  `kAvatarImage` varchar(50),
  `gradeId` int(11),
  `gradeName` varchar(20),
  `accumulativePoint` int(11),
  `updateDateTime` timestamp
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `View_ShopArea`
--

/*!50001 DROP TABLE IF EXISTS `View_ShopArea`*/;
/*!50001 DROP VIEW IF EXISTS `View_ShopArea`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_ShopArea` AS select `sp`.`id` AS `id`,`sp`.`shopName` AS `shopName`,`sp`.`reActivityOrderNum` AS `reActivityOrderNum`,`sp`.`reDiscountOrderNum` AS `reDiscountOrderNum`,`sp`.`reConversionOrderNum` AS `reConversionOrderNum`,`au`.`id` AS `urbanId`,`au`.`name` AS `urbanName`,`au`.`orderNum` AS `orderNumUrban`,`ad`.`id` AS `districtId`,`ad`.`name` AS `districtName`,`ad`.`orderNum` AS `orderNumDistrict` from ((`TKShopping` `sp` join `TKAreaUrban` `au` on((`au`.`id` = `sp`.`urbanId`))) join `TKAreaDistrict` `ad` on((`ad`.`id` = `au`.`parentId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_ShopNews`
--

/*!50001 DROP TABLE IF EXISTS `View_ShopNews`*/;
/*!50001 DROP VIEW IF EXISTS `View_ShopNews`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_ShopNews` AS select `sn`.`id` AS `id`,`sn`.`newsTitle` AS `newsTitle`,`sn`.`newsContent` AS `newsContent`,`sn`.`addDateTime` AS `addDateTime`,`sn`.`adminId` AS `adminId`,`sn`.`state` AS `state`,`sn`.`newsType` AS `newsType`,`sn`.`orderNum` AS `orderNum`,`sn`.`newsSummary` AS `newsSummary`,`sn`.`startDate` AS `startDate`,`sn`.`endDate` AS `endDate`,`sp`.`id` AS `shopId`,`sp`.`shopName` AS `shopName`,`sp`.`reActivityOrderNum` AS `reActivityOrderNum`,`sp`.`reDiscountOrderNum` AS `reDiscountOrderNum`,`sp`.`reConversionOrderNum` AS `reConversionOrderNum`,`au`.`id` AS `urbanId`,`au`.`name` AS `urbanName`,`au`.`orderNum` AS `orderNumUrban`,`ad`.`id` AS `districtId`,`ad`.`name` AS `districtName`,`ad`.`orderNum` AS `orderNumDistrict` from (((`TKShoppingNews` `sn` left join `TKShopping` `sp` on((`sp`.`id` = `sn`.`shopId`))) left join `TKAreaUrban` `au` on((`au`.`id` = `sn`.`urbanId`))) left join `TKAreaDistrict` `ad` on((`ad`.`id` = `au`.`parentId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKCard`
--

/*!50001 DROP TABLE IF EXISTS `View_TKCard`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKCard`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKCard` AS select `ci`.`id` AS `id`,`ci`.`name` AS `name`,`ci`.`addDateTime` AS `addDateTime`,`ci`.`cardSetType` AS `cardSetType`,`cs`.`areaDistrictId` AS `areaDistrictId`,`cs`.`areaUrbanId` AS `areaUrbanId`,`ad`.`name` AS `districtName`,`au`.`name` AS `urbanIdName`,`cs`.`cardImagePath` AS `cardImagePath`,`cs`.`state` AS `state`,`cs`.`price` AS `value1`,`cs`.`sellingPrice` AS `value2` from (((`TKCardIndex` `ci` left join `TKCardForSale` `cs` on((`cs`.`id` = `ci`.`id`))) left join `TKAreaDistrict` `ad` on((`ad`.`id` = `cs`.`areaDistrictId`))) left join `TKAreaUrban` `au` on((`au`.`id` = `cs`.`areaUrbanId`))) where (`ci`.`cardSetType` = 1) union select `ci`.`id` AS `id`,`ci`.`name` AS `name`,`ci`.`addDateTime` AS `addDateTime`,`ci`.`cardSetType` AS `cardSetType`,`cs`.`areaDistrictId` AS `areaDistrictId`,`cs`.`areaUrbanId` AS `areaUrbanId`,`ad`.`name` AS `districtName`,`au`.`name` AS `urbanIdName`,`cs`.`cardImagePath` AS `cardImagePath`,`cs`.`state` AS `state`,`cs`.`price` AS `value1`,`cs`.`sellingPrice` AS `value2` from (((`TKCardIndex` `ci` left join `TKCardForShow` `cs` on((`cs`.`id` = `ci`.`id`))) left join `TKAreaDistrict` `ad` on((`ad`.`id` = `cs`.`areaDistrictId`))) left join `TKAreaUrban` `au` on((`au`.`id` = `cs`.`areaUrbanId`))) where (`ci`.`cardSetType` = 2) union select `ci`.`id` AS `id`,`ci`.`name` AS `name`,`ci`.`addDateTime` AS `addDateTime`,`ci`.`cardSetType` AS `cardSetType`,`ca`.`areaDistrictId` AS `areaDistrictId`,`ca`.`areaUrbanId` AS `areaUrbanId`,`ad`.`name` AS `districtName`,`au`.`name` AS `urbanIdName`,`ca`.`cardImagePath` AS `cardImagePath`,`ca`.`state` AS `state`,`ca`.`limitUser` AS `value1`,`ca`.`endDate` AS `value2` from (((`TKCardIndex` `ci` left join `TKCardForActivity` `ca` on((`ca`.`id` = `ci`.`id`))) left join `TKAreaDistrict` `ad` on((`ad`.`id` = `ca`.`areaDistrictId`))) left join `TKAreaUrban` `au` on((`au`.`id` = `ca`.`areaUrbanId`))) where (`ci`.`cardSetType` = 3) union select `ci`.`id` AS `id`,`ci`.`name` AS `name`,`ci`.`addDateTime` AS `addDateTime`,`ci`.`cardSetType` AS `cardSetType`,`cfe`.`areaDistrictId` AS `areaDistrictId`,`cfe`.`areaUrbanId` AS `areaUrbanId`,`ad`.`name` AS `districtName`,`au`.`name` AS `urbanIdName`,`cfe`.`cardImagePath` AS `cardImagePath`,`cfe`.`state` AS `state`,`cfe`.`surplusCount` AS `value1`,`cfe`.`exchangPoint` AS `value2` from (((`TKCardIndex` `ci` left join `TKCardForExchange` `cfe` on((`cfe`.`id` = `ci`.`id`))) left join `TKAreaDistrict` `ad` on((`ad`.`id` = `cfe`.`areaDistrictId`))) left join `TKAreaUrban` `au` on((`au`.`id` = `cfe`.`areaUrbanId`))) where (`ci`.`cardSetType` = 4) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKCardActivityRegistration`
--

/*!50001 DROP TABLE IF EXISTS `View_TKCardActivityRegistration`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKCardActivityRegistration`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKCardActivityRegistration` AS select `car`.`id` AS `id`,`car`.`cardId` AS `cardId`,`car`.`regUserId` AS `regUserId`,`car`.`regDateTime` AS `regDateTime`,`car`.`state` AS `state`,`ui`.`kLoginName` AS `kLoginName`,`ui`.`kPWD` AS `kPWD`,`ui`.`kMail` AS `kMail`,`ui`.`kTel` AS `kTel`,`ui`.`kPoints` AS `kPoints`,`ui`.`kState` AS `kState`,`ui`.`reUserId` AS `reUserId`,`ui`.`reUserLoginName` AS `reUserLoginName`,`ui`.`registrationDateTime` AS `registrationDateTime`,`ui`.`loginDateTime` AS `loginDateTime`,`ui`.`exitDateTime` AS `exitDateTime`,`ui`.`nickname` AS `nickname`,`ui`.`birthday` AS `birthday`,`ui`.`area` AS `area`,`ui`.`QQ` AS `QQ`,`ui`.`kPointsAccumulative` AS `kPointsAccumulative`,`ui`.`kAvatarImage` AS `kAvatarImage`,`ug`.`id` AS `gradeId`,`ug`.`name` AS `gradeName`,`ug`.`accumulativePoint` AS `accumulativePoint`,`ug`.`updateDateTime` AS `updateDateTime` from ((`TKCardActivityRegistration` `car` left join `TKUserInfo` `ui` on((`ui`.`id` = `car`.`regUserId`))) left join `TKUserGrade` `ug` on((`ug`.`id` = `ui`.`gradeId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKCardForActivity`
--

/*!50001 DROP TABLE IF EXISTS `View_TKCardForActivity`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKCardForActivity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKCardForActivity` AS select `ci`.`id` AS `id`,`ci`.`name` AS `name`,`ci`.`addDateTime` AS `addDateTime`,`ci`.`userId` AS `userId`,`ci`.`operatorFrom` AS `operatorFrom`,`ci`.`cardSetType` AS `cardSetType`,`ca`.`matter` AS `matter`,`ca`.`characteristic` AS `characteristic`,`ca`.`detail` AS `detail`,`ca`.`tel` AS `tel`,`ca`.`QQ` AS `QQ`,`ca`.`state` AS `state`,`ca`.`cardImagePath` AS `cardImagePath`,`ca`.`startDate` AS `startDate`,`ca`.`endDate` AS `endDate`,`ca`.`limitUser` AS `limitUser`,`ui`.`nickname` AS `nickname`,`ui`.`kAvatarImage` AS `kAvatarImage`,(select count(0) from `TKCardActivityRegistration` where ((`TKCardActivityRegistration`.`cardId` = `ci`.`id`) and (`TKCardActivityRegistration`.`state` = 1))) AS `regCount` from ((`TKCardIndex` `ci` left join `TKCardForActivity` `ca` on((`ca`.`id` = `ci`.`id`))) left join `TKUserInfo` `ui` on((`ui`.`id` = `ci`.`userId`))) where (`ci`.`cardSetType` = 3) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKCardForExchange`
--

/*!50001 DROP TABLE IF EXISTS `View_TKCardForExchange`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKCardForExchange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKCardForExchange` AS select `ci`.`id` AS `id`,`ci`.`name` AS `name`,`ci`.`addDateTime` AS `addDateTime`,`ci`.`userId` AS `userId`,`ci`.`operatorFrom` AS `operatorFrom`,`ci`.`cardSetType` AS `cardSetType`,`cfe`.`cardType` AS `cardType`,`cfe`.`cardUse` AS `cardUse`,`cfe`.`cardTtransactions` AS `cardTtransactions`,`cfe`.`areaDistrictId` AS `areaDistrictId`,`cfe`.`areaUrbanId` AS `areaUrbanId`,`cfe`.`areaIdPath` AS `areaIdPath`,`cfe`.`areaNamePath` AS `areaNamePath`,`cfe`.`period` AS `period`,`cfe`.`wayFight` AS `wayFight`,`cfe`.`remarks` AS `remarks`,`cfe`.`exchangPoint` AS `exchangPoint`,`cfe`.`surplusCount` AS `surplusCount`,`cfe`.`isSponsors` AS `isSponsors`,`cfe`.`cardImagePath` AS `cardImagePath`,`cfe`.`state` AS `state`,`cfe`.`orderNum` AS `orderNum`,`ad`.`name` AS `districtName`,`au`.`name` AS `urbanName` from (((`TKCardIndex` `ci` left join `TKCardForExchange` `cfe` on((`cfe`.`id` = `ci`.`id`))) left join `TKAreaDistrict` `ad` on((`ad`.`id` = `cfe`.`areaDistrictId`))) left join `TKAreaUrban` `au` on((`au`.`id` = `cfe`.`areaUrbanId`))) where (`ci`.`cardSetType` = 4) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKCardForSale`
--

/*!50001 DROP TABLE IF EXISTS `View_TKCardForSale`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKCardForSale`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKCardForSale` AS select `ci`.`id` AS `id`,`ci`.`name` AS `name`,`ci`.`addDateTime` AS `addDateTime`,`ci`.`userId` AS `userId`,`ci`.`operatorFrom` AS `operatorFrom`,`ci`.`cardSetType` AS `cardSetType`,`cs`.`cardType` AS `cardType`,`cs`.`cardUse` AS `cardUse`,`cs`.`cardTtransactions` AS `cardTtransactions`,`cs`.`areaDistrictId` AS `areaDistrictId`,`cs`.`areaUrbanId` AS `areaUrbanId`,`cs`.`areaIdPath` AS `areaIdPath`,`cs`.`areaNamePath` AS `areaNamePath`,`cs`.`period` AS `period`,`cs`.`wayFight` AS `wayFight`,`cs`.`remarks` AS `remarks`,`cs`.`cardImagePath` AS `cardImagePath`,`cs`.`price` AS `price`,`cs`.`sellingPrice` AS `sellingPrice`,`cs`.`state` AS `state`,`ad`.`name` AS `districtName`,`au`.`name` AS `urbanIdName` from (((`TKCardIndex` `ci` left join `TKCardForSale` `cs` on((`cs`.`id` = `ci`.`id`))) left join `TKAreaDistrict` `ad` on((`ad`.`id` = `cs`.`areaDistrictId`))) left join `TKAreaUrban` `au` on((`au`.`id` = `cs`.`areaUrbanId`))) where (`ci`.`cardSetType` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKCardForShow`
--

/*!50001 DROP TABLE IF EXISTS `View_TKCardForShow`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKCardForShow`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKCardForShow` AS select `ci`.`id` AS `id`,`ci`.`name` AS `name`,`ci`.`addDateTime` AS `addDateTime`,`ci`.`userId` AS `userId`,`ci`.`operatorFrom` AS `operatorFrom`,`ci`.`cardSetType` AS `cardSetType`,`cs`.`cardType` AS `cardType`,`cs`.`cardUse` AS `cardUse`,`cs`.`cardTtransactions` AS `cardTtransactions`,`cs`.`areaDistrictId` AS `areaDistrictId`,`cs`.`areaUrbanId` AS `areaUrbanId`,`cs`.`areaIdPath` AS `areaIdPath`,`cs`.`areaNamePath` AS `areaNamePath`,`cs`.`period` AS `period`,`cs`.`wayFight` AS `wayFight`,`cs`.`remarks` AS `remarks`,`cs`.`cardImagePath` AS `cardImagePath`,`cs`.`price` AS `price`,`cs`.`sellingPrice` AS `sellingPrice`,`cs`.`state` AS `state`,`ad`.`name` AS `districtName`,`au`.`name` AS `urbanIdName` from (((`TKCardIndex` `ci` left join `TKCardForShow` `cs` on((`cs`.`id` = `ci`.`id`))) left join `TKAreaDistrict` `ad` on((`ad`.`id` = `cs`.`areaDistrictId`))) left join `TKAreaUrban` `au` on((`au`.`id` = `cs`.`areaUrbanId`))) where (`ci`.`cardSetType` = 2) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKCardUserMessage`
--

/*!50001 DROP TABLE IF EXISTS `View_TKCardUserMessage`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKCardUserMessage`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKCardUserMessage` AS select `cm`.`id` AS `id`,`cm`.`userId` AS `userId`,`cm`.`cardId` AS `cardId`,`cm`.`content` AS `content`,`cm`.`addDateTime` AS `addDateTime`,`cm`.`state` AS `state`,`ui`.`nickname` AS `nickname`,`ui`.`kAvatarImage` AS `kAvatarImage` from (`TKCardUserMessage` `cm` left join `TKUserInfo` `ui` on((`ui`.`id` = `cm`.`userId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKUserBlogMessages`
--

/*!50001 DROP TABLE IF EXISTS `View_TKUserBlogMessages`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKUserBlogMessages`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKUserBlogMessages` AS select `ub`.`id` AS `id`,`ub`.`userId` AS `userId`,`ub`.`content` AS `content`,`ub`.`addDateTime` AS `addDateTime`,`ub`.`state` AS `state`,`ui`.`nickname` AS `nickname`,`ui`.`kAvatarImage` AS `kAvatarImage` from (`TKUserBlogMessages` `ub` left join `TKUserInfo` `ui` on((`ui`.`id` = `ub`.`userId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKUserFriends`
--

/*!50001 DROP TABLE IF EXISTS `View_TKUserFriends`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKUserFriends`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKUserFriends` AS select `uf`.`id` AS `id`,`uf`.`userId` AS `userId`,`uf`.`friendUserId` AS `friendUserId`,`uf`.`addDateTime` AS `addDateTime`,`ui`.`nickname` AS `nickname`,`ui`.`kAvatarImage` AS `kAvatarImage` from (`TKUserFriends` `uf` left join `TKUserInfo` `ui` on((`ui`.`id` = `uf`.`friendUserId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKUserOperLog`
--

/*!50001 DROP TABLE IF EXISTS `View_TKUserOperLog`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKUserOperLog`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKUserOperLog` AS select `ol`.`id` AS `id`,`ol`.`userId` AS `userId`,`ol`.`operType` AS `operType`,`ol`.`operDateTime` AS `operDateTime`,`ol`.`tid` AS `tid`,`ol`.`tname` AS `tname`,`ui`.`nickname` AS `nickname`,`ui`.`kAvatarImage` AS `kAvatarImage` from (`TKUserOperLog` `ol` left join `TKUserInfo` `ui` on((`ui`.`id` = `ol`.`userId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_TKUserStatistics`
--

/*!50001 DROP TABLE IF EXISTS `View_TKUserStatistics`*/;
/*!50001 DROP VIEW IF EXISTS `View_TKUserStatistics`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_TKUserStatistics` AS select `us`.`id` AS `id`,`us`.`userId` AS `userId`,`us`.`statisticType` AS `statisticType`,`us`.`staticValue` AS `staticValue`,`us`.`updateDateTime` AS `updateDateTime`,`ui`.`nickname` AS `nickname`,`ui`.`kAvatarImage` AS `kAvatarImage` from (`TKUserStatistics` `us` left join `TKUserInfo` `ui` on((`ui`.`id` = `us`.`userId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_User`
--

/*!50001 DROP TABLE IF EXISTS `View_User`*/;
/*!50001 DROP VIEW IF EXISTS `View_User`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_User` AS select `ui`.`id` AS `id`,`ui`.`kLoginName` AS `kLoginName`,`ui`.`kPWD` AS `kPWD`,`ui`.`kMail` AS `kMail`,`ui`.`kTel` AS `kTel`,`ui`.`kPoints` AS `kPoints`,`ui`.`kState` AS `kState`,`ui`.`reUserId` AS `reUserId`,`ui`.`reUserLoginName` AS `reUserLoginName`,`ui`.`registrationDateTime` AS `registrationDateTime`,`ui`.`loginDateTime` AS `loginDateTime`,`ui`.`exitDateTime` AS `exitDateTime`,`ui`.`nickname` AS `nickname`,`ui`.`birthday` AS `birthday`,`ui`.`area` AS `area`,`ui`.`QQ` AS `QQ`,`ui`.`kPointsAccumulative` AS `kPointsAccumulative`,`ui`.`kAvatarImage` AS `kAvatarImage`,`ui`.`MSN` AS `MSN`,`ui`.`verifyDateTime` AS `verifyDateTime`,`ug`.`id` AS `gradeId`,`ug`.`name` AS `gradeName`,`ug`.`accumulativePoint` AS `accumulativePoint`,`ug`.`updateDateTime` AS `updateDateTime` from (`TKUserInfo` `ui` left join `TKUserGrade` `ug` on((`ug`.`id` = `ui`.`gradeId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_UserMessages`
--

/*!50001 DROP TABLE IF EXISTS `View_UserMessages`*/;
/*!50001 DROP VIEW IF EXISTS `View_UserMessages`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_UserMessages` AS select `um`.`id` AS `id`,`um`.`userId` AS `userId`,`um`.`toUserId` AS `toUserId`,`um`.`content` AS `content`,`um`.`addDateTime` AS `addDateTime`,`um`.`state` AS `state`,`ui`.`nickname` AS `nickname` from (`TKUserMessages` `um` left join `TKUserInfo` `ui` on((`ui`.`id` = `um`.`userId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `View_UserPointsChanges`
--

/*!50001 DROP TABLE IF EXISTS `View_UserPointsChanges`*/;
/*!50001 DROP VIEW IF EXISTS `View_UserPointsChanges`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bdm0120168`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `View_UserPointsChanges` AS select `upc`.`id` AS `id`,`upc`.`userId` AS `userId`,`upc`.`pointChange` AS `pointChange`,`upc`.`changeDateTime` AS `changeDateTime`,`upc`.`operTypeId` AS `operTypeId`,`upc`.`operTypeName` AS `operTypeName`,`ui`.`kLoginName` AS `kLoginName`,`ui`.`kPWD` AS `kPWD`,`ui`.`kMail` AS `kMail`,`ui`.`kTel` AS `kTel`,`ui`.`kPoints` AS `kPoints`,`ui`.`kState` AS `kState`,`ui`.`reUserId` AS `reUserId`,`ui`.`reUserLoginName` AS `reUserLoginName`,`ui`.`registrationDateTime` AS `registrationDateTime`,`ui`.`loginDateTime` AS `loginDateTime`,`ui`.`exitDateTime` AS `exitDateTime`,`ui`.`nickname` AS `nickname`,`ui`.`birthday` AS `birthday`,`ui`.`area` AS `area`,`ui`.`QQ` AS `QQ`,`ui`.`kPointsAccumulative` AS `kPointsAccumulative`,`ui`.`kAvatarImage` AS `kAvatarImage`,`ug`.`id` AS `gradeId`,`ug`.`name` AS `gradeName`,`ug`.`accumulativePoint` AS `accumulativePoint`,`ug`.`updateDateTime` AS `updateDateTime` from ((`TKUserPointsChanges` `upc` left join `TKUserInfo` `ui` on((`ui`.`id` = `upc`.`userId`))) left join `TKUserGrade` `ug` on((`ug`.`id` = `ui`.`gradeId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-08-02 23:50:11
